import Foundation

struct VocabularyMembership: Codable, Equatable, Sendable {
    var collection: String
    var unit: Int?
    var segment: Int?
    var position: Int
    var priority: String
    var sourceOccurrenceID: String

    var isNormal: Bool { ["required", "basic"].contains(collection) && priority == "normal" }
    var deck: String {
        let names = ["required": "必考词", "basic": "基础词", "basic_simple": "简单基础词（低优先）", "extra": "超纲词（低优先）"]
        return "红宝书 · " + (names[collection] ?? collection) + (unit.map { String(format: " · Unit %02d", $0) } ?? "")
    }
    var orderKey: String {
        let rank = ["required": 0, "basic": 1, "basic_simple": 2, "extra": 3][collection] ?? 9
        return String(format: "%d-%04d-%04d-%05d", rank, unit ?? 0, segment ?? 0, position)
    }
}

struct PrivateVocabularyMetadata: Codable, Equatable, Sendable {
    var release: String
    var word: String
    var displayWord: String
    var coreMeaning: String?
    var dictionaryMeaning: String?
    var pos: String?
    var phonetic: String?
    var phoneticStatus: String
    var memberships: [VocabularyMembership]
    var relations: [String: [String]]
    // Preserve extra fields and provenance on the user's device, never in bundled resources.
    var sourceRecord: Data
    var hasNormalMembership: Bool { memberships.contains(where: \.isNormal) }
    var decks: [String] { Array(Set(memberships.map(\.deck))).sorted() }
    var primaryDeck: String { memberships.sorted { $0.orderKey < $1.orderKey }.first?.deck ?? "红宝书" }
    var answerText: String {
        if let value = coreMeaning, !value.isEmpty { return value }
        if let value = dictionaryMeaning, !value.isEmpty { return "词典底稿（尚未精简）\n" + value }
        return "释义待补充"
    }
}

struct PrivateVocabularyPack {
    var release: String
    var normal: Bool
    var entries: [(id: String, metadata: PrivateVocabularyMetadata)]
    var relationGroups: Data?

    static func recognizes(_ data: Data) -> Bool {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let schema = object["schema_version"] as? String else { return false }
        return schema.hasPrefix("yanxi.private-import.")
    }

    static func decode(_ data: Data) throws -> Self {
        func invalid(_ reason: String) -> StudyFailure { .message("私人词库格式不正确：" + reason) }
        guard data.count <= 25 * 1024 * 1024,
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              object["schema_version"] as? String == "yanxi.private-import.v2-stage1",
              let release = object["release"] as? String, !release.isEmpty,
              let scope = object["file_scope"] as? String,
              let rows = object["cards"] as? [[String: Any]], !rows.isEmpty, rows.count <= 10000 else { throw invalid("版本或词卡列表不受支持") }
        let normal = scope == "normal_56_units"
        guard normal || ["optional_low_priority", "optional_low_priority_collections", "optional"].contains(scope) else { throw invalid("无法识别导入分组 " + scope) }
        let collections = Set(normal ? ["required", "basic"] : ["basic_simple", "extra"])
        var ids = Set<String>()
        var entries: [(id: String, metadata: PrivateVocabularyMetadata)] = []
        for row in rows {
            guard let id = row["id"] as? String, !id.isEmpty, ids.insert(id).inserted,
                  let word = row["word"] as? String, !word.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  let places = row["unit_order"] as? [[String: Any]] else { throw invalid("ID重复或缺少单词、单元信息") }
            var memberships: [VocabularyMembership] = []
            for place in places {
                guard let collection = place["collection"] as? String,
                      ["required", "basic", "basic_simple", "extra"].contains(collection),
                      let position = place["position"] as? Int, position > 0,
                      let priority = place["priority"] as? String,
                      let occurrence = place["source_occurrence_id"] as? String, !occurrence.isEmpty else { throw invalid("单元顺序信息缺失") }
                guard collections.contains(collection) else { continue }
                let unit = place["unit"] as? Int
                guard (collection == "extra" && unit == nil)
                    || (collection == "required" && (1...26).contains(unit ?? 0))
                    || (collection == "basic" && (1...30).contains(unit ?? 0))
                    || (collection == "basic_simple" && unit == 31) else { throw invalid("单元编号超出范围") }
                memberships.append(VocabularyMembership(collection: collection, unit: unit, segment: place["segment"] as? Int,
                                                        position: position, priority: priority, sourceOccurrenceID: occurrence))
            }
            guard !memberships.isEmpty else { throw invalid("词卡不属于此包的分组") }
            let phonetic = row["phonetic"] as? String
            if let phonetic, !phonetic.isEmpty {
                guard phonetic.hasPrefix("/"), phonetic.hasSuffix("/") else { throw invalid("音标不是声明的标准IPA格式") }
            }
            let metadata = PrivateVocabularyMetadata(release: release, word: word, displayWord: (row["display_word"] as? String) ?? word,
                coreMeaning: row["core_meaning"] as? String, dictionaryMeaning: row["translation_zh"] as? String,
                pos: (row["pos"] as? String) ?? (row["pos"] as? [String])?.joined(separator: "; "), phonetic: phonetic, phoneticStatus: (row["phonetic_status"] as? String) ?? "pending",
                memberships: memberships, relations: (row["relations"] as? [String: [String]]) ?? [:],
                sourceRecord: try JSONSerialization.data(withJSONObject: row, options: [.sortedKeys]))
            entries.append((id, metadata))
        }
        let groups = try object["relation_groups"].flatMap { value -> Data? in
            guard !(value is NSNull), JSONSerialization.isValidJSONObject(value) else { return nil }
            return try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        }
        return Self(release: release, normal: normal, entries: entries, relationGroups: groups)
    }
}

struct PrivateVocabularyImportResult { var inserted = 0; var updated = 0 }

extension StudySnapshot {
    mutating func importPrivateVocabulary(_ data: Data) throws -> PrivateVocabularyImportResult {
        let pack = try PrivateVocabularyPack.decode(data)
        var next = self
        var index = Dictionary(uniqueKeysWithValues: next.cards.enumerated().map { ($0.element.id, $0.offset) })
        var result = PrivateVocabularyImportResult()
        for entry in pack.entries {
            var metadata = entry.metadata
            if let i = index[entry.id] {
                guard next.cards[i].subject == .english else {
                    throw StudyFailure.message("词库ID与已有其他卡片冲突，未导入任何修改。")
                }
                if let old = next.cards[i].privateVocabulary {
                    let replacedCollections = Set(metadata.memberships.map(\.collection))
                    metadata.memberships += old.memberships.filter { !replacedCollections.contains($0.collection) }
                    if metadata.coreMeaning?.isEmpty != false { metadata.coreMeaning = old.coreMeaning }
                    if metadata.phonetic == nil, old.phonetic != nil {
                        metadata.phonetic = old.phonetic; metadata.phoneticStatus = old.phoneticStatus
                    }
                    for (kind, related) in old.relations {
                        metadata.relations[kind] = Array(Set((metadata.relations[kind] ?? []) + related)).sorted()
                    }
                }
                // Updating content never resets notes, FSRS state, due dates, events or review logs.
                next.cards[i].front = metadata.displayWord
                next.cards[i].back = metadata.answerText
                next.cards[i].deck = metadata.primaryDeck
                next.cards[i].phonetic = metadata.phonetic ?? ""
                next.cards[i].privateVocabulary = metadata
                result.updated += 1
            } else {
                var card = StudyCard(id: entry.id, front: metadata.displayWord, back: metadata.answerText, subject: .english,
                                     deck: metadata.primaryDeck, source: "个人导入 · 红宝书照片词表", phonetic: metadata.phonetic ?? "")
                card.privateVocabulary = metadata
                index[entry.id] = next.cards.count; next.cards.append(card); result.inserted += 1
            }
        }
        if pack.normal { next.privateVocabularyIsPrimary = true }
        if let groups = pack.relationGroups {
            var stored = next.privateVocabularyRelationGroups ?? [:]
            stored[pack.normal ? "normal" : "optional"] = groups
            next.privateVocabularyRelationGroups = stored
        }
        try next.validate()
        self = next
        return result
    }

    func vocabularyCandidates(subject: StudySubject?, deck: String?, onlyIDs: Set<String>?) -> [StudyCard] {
        let filtered = cards.filter { card in
            guard subject == nil || card.subject == subject, onlyIDs == nil || onlyIDs!.contains(card.id) else { return false }
            if let deck { return card.belongsToDeck(deck) }
            if onlyIDs != nil { return true }
            if let vocabulary = card.privateVocabulary { return vocabulary.hasNormalMembership }
            return !(privateVocabularyIsPrimary == true && card.subject == .english)
        }
        return filtered.enumerated().sorted { a, b in
            func key(_ card: StudyCard) -> String {
                guard let value = card.privateVocabulary else { return "z" }
                return value.memberships.filter { deck == nil ? $0.isNormal : $0.deck == deck }.map(\.orderKey).min() ?? "9"
            }
            let ak = key(a.element), bk = key(b.element)
            return ak == bk ? a.offset < b.offset : ak < bk
        }.map(\.element)
    }

    func vocabularyDecks(subject: StudySubject) -> [String] {
        Array(Set(cards.filter { $0.subject == subject }.flatMap { $0.privateVocabulary?.decks ?? [$0.deck] }))
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    func unresolvedVocabularyRelations(for id: String) -> [String] {
        guard let record = cards.first(where: { $0.id == id })?.privateVocabulary else { return [] }
        let available = Set(cards.map(\.id))
        return Array(Set(record.relations.values.flatMap { $0 })).filter { !available.contains($0) }.sorted()
    }
}

extension StudyCard {
    func belongsToDeck(_ value: String) -> Bool { privateVocabulary?.decks.contains(value) ?? (deck == value) }
}
