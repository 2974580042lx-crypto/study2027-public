import SwiftUI
import AVFoundation

@MainActor
struct SubjectHub: View {
    @EnvironmentObject private var learning: LearningStore
    let subject: StudySubject
    @State private var showNewCard = false
    private var decks: [String] { learning.state.vocabularyDecks(subject: subject) }
    private var groups: [String] { Array(Set(learning.state.questions.filter { $0.subject == subject }.map(\.group))).sorted { a, b in
        if subject == .politics {
            let ay = Int(a.prefix(4)) ?? 0, by = Int(b.prefix(4)) ?? 0
            if ay != by { return ay > by }
        }
        return a < b
    } }
    var body: some View {
        StudyPage {
            VStack(alignment: .leading, spacing: 24) {
                Text(subject == .english ? "词汇与阅读" : subject == .history ? "历史与史料" : "知识与练习").font(.custom("NotoSerifSC-Regular", size: 28)).padding(.vertical, 14)
                if subject == .english {
                    NavigationLink { ReadingLibraryView() } label: {
                        StudyPanel { HStack { Label("英语阅读", systemImage: "text.book.closed"); Spacer(); Image(systemName: "chevron.right") } }
                    }.buttonStyle(.plain).accessibilityIdentifier("english-reading-library")
                    NavigationLink { ReadingWordListView() } label: {
                        StudyPanel { HStack { Label("阅读生词本", systemImage: "character.book.closed"); Spacer(); Text("\(learning.readingWords.count)").foregroundStyle(.secondary); Image(systemName: "chevron.right") } }
                    }.buttonStyle(.plain).accessibilityIdentifier("reading-word-list")
                }
                VStack(alignment: .leading, spacing: 12) {
                    Text(subject == .english ? "背单词" : "知识卡").font(.headline)
                    ForEach(decks, id: \.self) { deck in
                        NavigationLink { DeckDetailView(subject: subject, deck: deck) } label: {
                            StudyPanel {
                                HStack { VStack(alignment: .leading, spacing: 7) {
                                    Text(deck).font(.title3)
                                    Text("\(learning.state.cards.filter { $0.subject == subject && $0.belongsToDeck(deck) }.count) 张 · 到期 \(learning.queue(subject: subject, deck: deck, reviewsOnly: true).count) 张")
                                        .font(.caption).foregroundStyle(.secondary)
                                }; Spacer(); Image(systemName: "chevron.right").font(.caption) }
                            }
                        }.buttonStyle(.plain)
                    }
                    Button { showNewCard = true } label: { Label("添加自己的知识卡", systemImage: "plus") }.buttonStyle(.glass)
                }
                VStack(alignment: .leading, spacing: 12) {
                    Text("练习").font(.headline)
                    ForEach(groups, id: \.self) { group in
                        NavigationLink { QuestionPracticeView(questions: learning.state.questions.filter { $0.subject == subject && $0.group == group }) } label: {
                            StudyPanel { HStack { Text(group); Spacer(); Text("\(learning.state.questions.filter { $0.subject == subject && $0.group == group }.count) 题").font(.caption).foregroundStyle(.secondary); Image(systemName: "chevron.right").font(.caption) } }
                        }.buttonStyle(.plain)
                    }
                    Text(subject == .politics ? "历年题按最近年份优先排列。公开整理题尚待原卷逐题校核；已发现跨来源答案差异的题暂未收录。2025—2026 年仍在补齐。" : "基础练习和导入真题分别保留来源与年份。").font(.caption).foregroundStyle(.secondary)
                }
                NavigationLink { StudyLibrary(initialSubject: subject) } label: { Label("\(subject.title)资料与真题来源", systemImage: "books.vertical").frame(maxWidth: .infinity).padding(8) }.buttonStyle(.glass)
            }
        }.navigationTitle(subject.title).navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showNewCard) { CardEditor(subject: subject) }
    }
}

@MainActor
struct DeckDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    let subject: StudySubject
    let deck: String
    @State private var search = ""
    private var cards: [StudyCard] { learning.state.vocabularyCandidates(subject: subject, deck: deck, onlyIDs: nil).filter { search.isEmpty || $0.front.localizedCaseInsensitiveContains(search) || $0.back.localizedCaseInsensitiveContains(search) } }
    var body: some View {
        List {
            Section {
                NavigationLink { CardReviewView(subject: subject, deck: deck) } label: { Label("开始学习", systemImage: "play.fill") }.accessibilityIdentifier("start-word-review")
                NavigationLink { CardReviewView(subject: subject, deck: deck, reviewsOnly: true) } label: { Label("只复习到期内容", systemImage: "arrow.clockwise") }
                if subject == .english {
                    Text("每日新词目标 \(learning.state.preferences.dailyWords) 个；先复习，再学习新词。到达目标后可以在设置中调整。").font(.caption).foregroundStyle(.secondary)
                }
            }
            Section("词条与卡片 · \(cards.count)") {
                ForEach(cards) { card in
                    NavigationLink { CardDetailView(cardID: card.id) } label: {
                        HStack { VStack(alignment: .leading, spacing: 5) { Text(card.front).font(.headline); Text(card.reviews == 0 ? "未学习" : "复习 \(card.reviews) 次").font(.caption).foregroundStyle(.secondary) }; Spacer(); if card.reviews > 0 { Image(systemName: card.due <= Date() ? "clock" : "checkmark").foregroundStyle(.secondary) } }
                    }
                }
            }
        }.scrollContentBackground(.hidden).background(AppBackground()).searchable(text: $search, prompt: "搜索单词或释义")
            .navigationTitle(deck).navigationBarTitleDisplayMode(.inline)
    }
}

@MainActor
struct CardReviewView: View {
    @EnvironmentObject private var learning: LearningStore
    var subject: StudySubject? = nil
    var deck: String? = nil
    var reviewsOnly = false
    var onlyIDs: Set<String>? = nil
    @State private var ids: [String] = []
    @State private var index = 0
    @State private var revealed = false
    @State private var initialized = false
    @State private var askContext: StudyAskContext?
    @State private var speech = AVSpeechSynthesizer()
    private var current: StudyCard? { guard ids.indices.contains(index) else { return nil }; return learning.state.cards.first { $0.id == ids[index] } }
    var body: some View {
        StudyPage {
            VStack(spacing: 25) {
                if let card = current {
                    HStack { Text("\(index + 1) / \(ids.count)").monospacedDigit(); Spacer(); Text(card.reviews == 0 ? "新学" : "复习") }.font(.caption).foregroundStyle(.secondary)
                    ProgressView(value: Double(index), total: Double(max(1, ids.count))).tint(.white)
                    Text(card.front).font(card.subject == .english ? .system(size: 38, weight: .medium, design: .serif) : .custom("NotoSerifSC-Regular", size: 27))
                        .multilineTextAlignment(.center).padding(.top, 45).textSelection(.enabled).accessibilityIdentifier("review-front")
                    if card.subject == .english {
                        HStack { Text(card.phonetic).foregroundStyle(.secondary); Button { pronounce(card.privateVocabulary?.word ?? card.front, using: speech) } label: { Image(systemName: "speaker.wave.2") }.accessibilityLabel("朗读单词") }
                    }
                    if revealed {
                        StudyPanel {
                            VStack(alignment: .leading, spacing: 14) {
                                SelectableStudyText(text: card.back, identifier: "review-answer") { quote in ask(card, quote: quote) }
                                if !card.note.isEmpty { Divider(); Text(card.note).font(.subheadline) }
                                Text(card.source).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        HStack(spacing: 12) {
                            ForEach(RecallGrade.allCases, id: \.self) { grade in
                                Button(grade.title) { learning.review(id: card.id, grade: grade); index += 1; revealed = false; UISelectionFeedbackGenerator().selectionChanged() }
                                    .frame(maxWidth: .infinity).buttonStyle(.glass).accessibilityIdentifier("grade-\(grade.rawValue)")
                            }
                        }
                    } else {
                        Button("查看释义与答案") { revealed = true }.buttonStyle(.glassProminent).padding(.top, 28).accessibilityIdentifier("reveal-card")
                        Text("先在心里回忆，再展开答案。").font(.caption).foregroundStyle(.secondary)
                    }
                } else {
                    ContentUnavailableView(index > 0 ? "这一轮完成了" : "暂时没有待复习内容", systemImage: "checkmark.circle", description: Text(index > 0 ? "已完成 \(index) 张卡片，学习记录已保存。" : "到期内容会自动出现；新词数量可在学习设置中调整。"))
                }
            }
        }.navigationTitle(subject == .english ? "背单词" : "回忆与复习").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { if let card = current { Button { ask(card, quote: card.front) } label: { Image(systemName: "sparkles") }.accessibilityLabel("问这个单词或知识点") } } }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .onAppear { if !initialized { ids = learning.queue(subject: subject, deck: deck, reviewsOnly: reviewsOnly, onlyIDs: onlyIDs).map(\.id); initialized = true } }
            .onDisappear { speech.stopSpeaking(at: .immediate) }
    }
    private func ask(_ card: StudyCard, quote: String) {
        askContext = StudyAskContext(referenceID: "card:" + card.id, subject: card.subject, title: card.front, quote: quote,
                                     background: card.front + "\n" + card.back, source: card.source, mode: card.subject == .english ? .vocabulary : .explain)
    }
}

@MainActor
private func pronounce(_ word: String, using speech: AVSpeechSynthesizer) {
    speech.stopSpeaking(at: .immediate); let utterance = AVSpeechUtterance(string: word)
    utterance.voice = AVSpeechSynthesisVoice(language: "en-US"); utterance.rate = 0.42; speech.speak(utterance)
}

@MainActor
struct CardDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let cardID: String
    @State private var editing = false
    @State private var assistant = false
    @State private var askContext: StudyAskContext?
    @State private var speech = AVSpeechSynthesizer()
    private var card: StudyCard? { learning.state.cards.first { $0.id == cardID } }
    var body: some View {
        StudyPage {
            if let card {
                VStack(alignment: .leading, spacing: 22) {
                    Text(card.front).font(.system(size: 32, weight: .medium, design: .serif)).textSelection(.enabled)
                    if card.subject == .english { Button { pronounce(card.front, using: speech) } label: { Label(card.phonetic.isEmpty ? "朗读" : card.phonetic, systemImage: "speaker.wave.2") }.buttonStyle(.glass) }
                    SelectableStudyText(text: card.back) { quote in askContext = cardContext(card, quote: quote) }
                    if !card.note.isEmpty { StudyPanel { Text(card.note).readingStyle().textSelection(.enabled) } }
                    Text(card.source).font(.caption).foregroundStyle(.secondary)
                    if card.reviews > 0 { Text("复习 \(card.reviews) 次 · 下次 \(card.due.formatted(date: .abbreviated, time: .shortened))").font(.caption).foregroundStyle(.secondary) }
                    Button("问 AI") { askContext = cardContext(card, quote: card.front) }.buttonStyle(.glass)
                }
            }
        }.navigationTitle("学习卡").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("编辑") { editing = true } } }
            .sheet(isPresented: $editing) { if let card { CardEditor(subject: card.subject, existing: card) } }
            .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .onDisappear { speech.stopSpeaking(at: .immediate) }
    }
    private func cardContext(_ card: StudyCard, quote: String) -> StudyAskContext {
        StudyAskContext(referenceID: "card:" + card.id, subject: card.subject, title: card.front, quote: quote,
                        background: card.front + "\n" + card.back, source: card.source, mode: card.subject == .english ? .vocabulary : .explain)
    }
}

@MainActor
struct CardEditor: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    let subject: StudySubject
    var existing: StudyCard? = nil
    @State private var front = ""
    @State private var back = ""
    @State private var note = ""
    @State private var deck = "我的卡片"
    var body: some View {
        NavigationStack { Form {
            Section("正面") { TextField("单词或问题", text: $front, axis: .vertical) }
            Section("背面") { TextEditor(text: $back).frame(minHeight: 130) }
            Section("我的笔记") { TextEditor(text: $note).frame(minHeight: 80) }
            Section("分组") { TextField("例如：红宝书 2027 · 第 1 单元", text: $deck) }
        }.navigationTitle(existing == nil ? "新建卡片" : "编辑卡片").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") {
                var card = existing ?? StudyCard(front: front, back: back, subject: subject, deck: deck, source: "个人整理")
                card.front = front; card.back = back; card.note = note; card.deck = deck
                if existing != nil && existing?.back != back { card.source += " · 个人修订" }
                learning.updateCard(card); dismiss()
            }.disabled(front.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || back.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        } }.onAppear { if let card = existing { front = card.front; back = card.back; note = card.note; deck = card.deck } }
    }
}

@MainActor
struct QuestionPracticeView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let questions: [StudyQuestion]
    @State private var index = 0
    @State private var selected: Set<Int> = []
    @State private var submitted = false
    @State private var assistant = false
    @State private var askContext: StudyAskContext?
    var body: some View {
        StudyPage {
            VStack(alignment: .leading, spacing: 22) {
                if questions.indices.contains(index) {
                    let q = questions[index]
                    HStack { Text("\(index+1) / \(questions.count)"); Spacer(); Text(q.multiple ? "多选题" : "单选题") }.font(.caption).foregroundStyle(.secondary)
                    SelectableStudyText(text: q.stem, identifier: "selectable-question-stem") { quote in ask(q, quote: quote) }
                    ForEach(q.options.indices, id: \.self) { i in
                        Button {
                            guard !submitted else { return }
                            if q.multiple { if selected.contains(i) { selected.remove(i) } else { selected.insert(i) } }
                            else { selected = [i] }
                        } label: {
                            HStack(alignment: .top, spacing: 14) {
                                Text(String(UnicodeScalar(65+i)!)).font(.headline).frame(width: 25)
                                Text(q.options[i]).font(.body).multilineTextAlignment(.leading).frame(maxWidth: .infinity, alignment: .leading)
                                if selected.contains(i) { Image(systemName: "checkmark.circle.fill") }
                            }.padding(18).background(.white.opacity(selected.contains(i) ? 0.16 : 0.04), in: RoundedRectangle(cornerRadius: 22))
                                .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(selected.contains(i) ? 0.4 : 0.08), lineWidth: 1))
                        }.buttonStyle(.plain).accessibilityIdentifier("option-\(i)")
                            .contextMenu { Button("问这个选项", systemImage: "sparkles") { ask(q, quote: String(UnicodeScalar(65+i)!) + ". " + q.options[i]) } }
                    }
                    if submitted {
                        StudyPanel { VStack(alignment: .leading, spacing: 13) {
                            Label(q.isCorrect(selected) ? "答对了" : "已记录到错题本", systemImage: q.isCorrect(selected) ? "checkmark.circle" : "arrow.uturn.backward")
                            Text("正确答案：" + q.answers.map { String(UnicodeScalar(65+$0)!) }.joined(separator: "、")).font(.headline)
                            SelectableStudyText(text: q.explanation) { quote in ask(q, quote: quote) }
                        } }.accessibilityIdentifier("question-result")
                        HStack {
                            Button("问 AI") { ask(q, quote: q.stem) }.buttonStyle(.glass)
                            Spacer()
                            Button(index + 1 == questions.count ? "完成本组" : "下一题") { index += 1; submitted = false; selected = [] }.buttonStyle(.glassProminent)
                        }
                    } else {
                        Button("提交答案") { learning.recordAnswer(q, selected: selected); submitted = true }.buttonStyle(.glassProminent).disabled(selected.isEmpty).accessibilityIdentifier("submit-question")
                    }
                    Text(q.source).font(.caption2).foregroundStyle(.secondary)
                    if let raw = q.sourceURL, let url = URL(string: raw), url.scheme == "https" { Link("查看资料来源", destination: url).font(.caption) }
                } else { ContentUnavailableView("本组练习完成", systemImage: "checkmark.circle", description: Text("答案与错题已保存，可在复习页继续。")) }
            }
        }.navigationTitle("练习").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { if questions.indices.contains(index) {
                Button { ask(questions[index], quote: questions[index].stem) } label: { Label("问整题", systemImage: "sparkles") }.accessibilityIdentifier("ask-current-question")
            } } }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
    }
    private func ask(_ q: StudyQuestion, quote: String) {
        askContext = .question(q, quote: quote, submitted: submitted, selected: selected)
    }
}

@MainActor
struct ReviewHub: View {
    @EnvironmentObject private var learning: LearningStore
    var body: some View {
        StudyPage { VStack(alignment: .leading, spacing: 22) {
            Text("今日复习").font(.custom("NotoSerifSC-Regular", size: 29)).padding(.vertical, 20)
            NavigationLink { CardReviewView(reviewsOnly: true) } label: {
                StudyPanel { HStack { VStack(alignment: .leading, spacing: 8) { Text("到期复习").font(.title2); Text("\(learning.queue(reviewsOnly: true).count) 张卡片等待回忆").font(.subheadline).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "arrow.clockwise") } }
            }.buttonStyle(.plain)
            NavigationLink { QuestionPracticeView(questions: learning.wrongQuestions) } label: {
                StudyPanel { HStack { VStack(alignment: .leading, spacing: 8) { Text("错题重做").font(.title2); Text("\(learning.wrongQuestions.count) 道题待巩固").font(.subheadline).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "pencil.and.list.clipboard") } }
            }.buttonStyle(.plain)
            Text("答对后会退出待重做列表，原来的作答记录仍保留在学习时间轴。").font(.caption).foregroundStyle(.secondary)
            ForEach(StudySubject.allCases) { subject in
                NavigationLink { SubjectHub(subject: subject) } label: { Label(subject.title, systemImage: subject.symbol).frame(maxWidth: .infinity, alignment: .leading).padding(18) }.buttonStyle(.glass)
            }
        } }.navigationTitle("复习").navigationBarTitleDisplayMode(.inline)
    }
}
