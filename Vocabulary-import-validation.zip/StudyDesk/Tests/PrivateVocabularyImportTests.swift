import XCTest
@testable import DeepSeekCore

final class PrivateVocabularyImportTests: XCTestCase {
    // Synthetic fixtures only. No private vocabulary, source IDs, or book text are included.
    private func place(_ collection: String = "required", unit: Int? = 1, position: Int = 1) -> [String: Any] {
        ["collection": collection, "unit": unit.map { $0 as Any } ?? NSNull(), "segment": 1, "position": position,
         "priority": ["required", "basic"].contains(collection) ? "normal" : "low", "source": "synthetic",
         "source_occurrence_id": "demo-\(collection)-\(unit ?? 0)-\(position)"]
    }
    private func entry(_ id: String, word: String = "example", places: [[String: Any]]? = nil) -> [String: Any] {
        ["id": id, "word": word, "display_word": word, "translation_zh": "合成词典释义", "core_meaning": NSNull(),
         "pos": ["n."], "phonetic": NSNull(), "phonetic_status": "pending", "phonetic_variants": [],
         "unit_order": places ?? [place()], "relations": ["word_family_ids": [String](), "confusable_word_ids": [String]()], "relation_group_ids": []]
    }
    private func pack(_ rows: [[String: Any]], normal: Bool = true) throws -> Data {
        try JSONSerialization.data(withJSONObject: ["schema_version": "yanxi.private-import.v2-stage1", "release": "synthetic-v1",
            "file_scope": normal ? "normal_56_units" : "optional_low_priority_collections", "cards": rows,
            "relation_groups": [["id": "demo-group", "members": ["demo-1", "demo-missing"]]]], options: [.sortedKeys])
    }
    func testUpsertKeepsFixedIDAndAllReviewStateAfterSpellingCorrection() throws {
        var state = StudySnapshot()
        _ = try state.importPrivateVocabulary(pack([entry("demo-1", word: "exampl")]))
        let now = Date(timeIntervalSince1970: 1700000000)
        try state.cards[0].review(.good, at: now)
        state.cards[0].note = "用户笔记"
        state.events = [LearningEvent(subject: .english, kind: .newWord, title: "exampl", detail: "", start: now, end: now, referenceID: "demo-1")]
        let before = state.cards[0]
        var corrected = entry("demo-1", word: "example"); corrected["core_meaning"] = "精简核心词义"
        let result = try state.importPrivateVocabulary(pack([corrected]))
        XCTAssertEqual(result.inserted, 0); XCTAssertEqual(result.updated, 1); XCTAssertEqual(state.cards.count, 1)
        let after = state.cards[0]
        XCTAssertEqual(after.id, before.id); XCTAssertEqual(after.front, "example"); XCTAssertEqual(after.back, "精简核心词义")
        XCTAssertEqual(after.due, before.due); XCTAssertEqual(after.reviewedAt, before.reviewedAt)
        XCTAssertEqual(after.memory, before.memory); XCTAssertEqual(after.reviewLogs, before.reviewLogs)
        XCTAssertEqual(after.reviews, before.reviews); XCTAssertEqual(after.lapses, before.lapses)
        XCTAssertEqual(after.intervalDays, before.intervalDays); XCTAssertEqual(after.note, before.note)
        XCTAssertEqual(state.events.count, 1); XCTAssertEqual(state.events[0].referenceID, "demo-1")
        _ = try state.importPrivateVocabulary(pack([corrected]))
        XCTAssertEqual(state.cards.count, 1); XCTAssertEqual(state.cards[0].reviewLogs, before.reviewLogs)
    }
    func testLegacyFixedIDCardCanBeUpdatedWithoutResettingProgress() throws {
        var state = StudySnapshot()
        var existing = StudyCard(id: "demo-1", front: "old", back: "old", subject: .english, deck: "legacy", source: "private")
        try existing.review(.hard, at: Date(timeIntervalSince1970: 1700000000))
        state.cards = [existing]
        _ = try state.importPrivateVocabulary(pack([entry("demo-1")]))
        XCTAssertEqual(state.cards.count, 1); XCTAssertEqual(state.cards[0].memory, existing.memory)
    }
    func testOptionalImportDoesNotEnrollSharedNormalMembershipPrematurely() throws {
        let shared = entry("demo-shared", places: [place(), place("extra", unit: nil)])
        var state = StudySnapshot()
        _ = try state.importPrivateVocabulary(pack([shared], normal: false))
        XCTAssertTrue(state.vocabularyCandidates(subject: .english, deck: nil, onlyIDs: nil).isEmpty)
        XCTAssertNil(state.privateVocabularyIsPrimary)
        XCTAssertEqual(state.vocabularyDecks(subject: .english).count, 1)
        _ = try state.importPrivateVocabulary(pack([shared]))
        XCTAssertEqual(state.cards.count, 1)
        XCTAssertEqual(state.vocabularyCandidates(subject: .english, deck: nil, onlyIDs: nil).count, 1)
        XCTAssertEqual(state.vocabularyDecks(subject: .english).count, 2)
    }
    func testThreeSharedIDsMergeInEitherOrderWithExpectedScale() throws {
        let core = (0..<4356).map { entry("demo-\($0)", places: [place(position: $0 + 1)]) }
        let optional = (0..<2237).map { i in entry("demo-\(i < 3 ? i : 4356 + i - 3)", places: [place("extra", unit: nil, position: i + 1)]) }
        for reverse in [false, true] {
            var state = StudySnapshot()
            _ = try state.importPrivateVocabulary(pack(reverse ? optional : core, normal: !reverse))
            _ = try state.importPrivateVocabulary(pack(reverse ? core : optional, normal: reverse))
            XCTAssertEqual(state.cards.count, 6590)
            XCTAssertEqual(state.vocabularyCandidates(subject: .english, deck: nil, onlyIDs: nil).count, 4356)
            _ = try state.importPrivateVocabulary(pack(optional, normal: false))
            XCTAssertEqual(state.cards.count, 6590)
        }
    }
    func testUnitOrderingIsNumericAndDuplicateSpellingsAreNotIDs() throws {
        var state = StudySnapshot()
        _ = try state.importPrivateVocabulary(pack([entry("demo-10", places: [place(unit: 10)]), entry("demo-2", places: [place(unit: 2)]), entry("demo-1", places: [place(unit: 1)])]))
        XCTAssertEqual(state.vocabularyCandidates(subject: .english, deck: nil, onlyIDs: nil).map(\.id), ["demo-1", "demo-2", "demo-10"])
        XCTAssertEqual(state.vocabularyDecks(subject: .english).count, 3)
    }
    func testMissingRelatedCardRemainsUnresolvedWithoutCreatingOrEnrollingIt() throws {
        var row = entry("demo-1"); row["relations"] = ["word_family_ids": ["demo-not-imported"]]
        var state = StudySnapshot(); _ = try state.importPrivateVocabulary(pack([row]))
        XCTAssertEqual(state.unresolvedVocabularyRelations(for: "demo-1"), ["demo-not-imported"])
        XCTAssertEqual(state.cards.count, 1)
        _ = try state.importPrivateVocabulary(pack([entry("demo-not-imported", places: [place("extra", unit: nil)])], normal: false))
        XCTAssertTrue(state.unresolvedVocabularyRelations(for: "demo-1").isEmpty)
        XCTAssertEqual(state.vocabularyCandidates(subject: .english, deck: nil, onlyIDs: nil).count, 1)
    }
    func testNullPhoneticAndMeaningAreNotFabricatedAndPOSArrayIsPreserved() throws {
        var state = StudySnapshot(); _ = try state.importPrivateVocabulary(pack([entry("demo-1")]))
        XCTAssertEqual(state.cards[0].phonetic, "")
        XCTAssertEqual(state.cards[0].privateVocabulary?.phoneticStatus, "pending")
        XCTAssertEqual(state.cards[0].privateVocabulary?.pos, "n.")
        XCTAssertTrue(state.cards[0].back.hasPrefix("词典底稿"))
        var row = entry("demo-2"); row["translation_zh"] = NSNull()
        _ = try state.importPrivateVocabulary(pack([row]))
        XCTAssertEqual(state.cards[1].back, "释义待补充")
    }
    func testMalformedPackIsAtomicAndOtherSubjectsCannotBeOverwritten() throws {
        var state = StudySnapshot()
        state.cards = [StudyCard(id: "demo-collision", front: "history", back: "answer", subject: .history, deck: "test", source: "test")]
        let before = state.cards
        XCTAssertThrowsError(try state.importPrivateVocabulary(pack([entry("demo-new"), entry("demo-collision")])))
        XCTAssertEqual(state.cards, before)
        XCTAssertThrowsError(try state.importPrivateVocabulary(pack([entry("demo-x"), entry("demo-x")])))
        XCTAssertEqual(state.cards, before)
    }
    func testBackupRoundTripAndOrdinaryDeckStillAvailableAfterSelectingPrivateBook() throws {
        var state = StudySnapshot()
        state.cards = [StudyCard(id: "legacy", front: "old", back: "old", subject: .english, deck: "ECDICT", source: "test")]
        _ = try state.importPrivateVocabulary(pack([entry("demo-1")]))
        let restored = try StudySnapshot.decode(state.encoded())
        XCTAssertEqual(restored.cards, state.cards)
        XCTAssertEqual(restored.privateVocabularyRelationGroups, state.privateVocabularyRelationGroups)
        XCTAssertEqual(restored.vocabularyCandidates(subject: .english, deck: nil, onlyIDs: nil).map(\.id), ["demo-1"])
        XCTAssertEqual(restored.vocabularyCandidates(subject: .english, deck: "ECDICT", onlyIDs: nil).map(\.id), ["legacy"])
    }
}
