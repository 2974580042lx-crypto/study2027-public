#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$PROJECT_ROOT/build"
SOURCE_PACKAGES="$BUILD_DIR/SourcePackages"
mkdir -p "$BUILD_DIR/previews"
cd "$PROJECT_ROOT"
xcrun simctl list devices available -j > "$BUILD_DIR/previews/devices.json"
UDID="$(python3 - "$BUILD_DIR/previews/devices.json" <<'PY'
import json,sys,re
data=json.load(open(sys.argv[1]))['devices']
for runtime,devices in sorted(data.items(),reverse=True):
    match=re.search(r'iOS-(\d+)',runtime)
    if not match or int(match.group(1))<26:continue
    phones=[d for d in devices if d.get('isAvailable') and d['name'].startswith('iPhone')]
    phones.sort(key=lambda d:(d['name']!='iPhone 17 Pro',d['name']!='iPhone 16 Pro',d['name']))
    if phones:
        print(phones[0]['udid'])
        break
else:raise SystemExit('No iOS 26+ simulator available')
PY
)"
xcrun simctl boot "$UDID" || true
PHASE_START=$SECONDS
xcrun simctl bootstatus "$UDID" -b
echo "STUDYDESK_TIMING_SIMULATOR_BOOT_SECONDS=$((SECONDS - PHASE_START))"
xcrun simctl spawn "$UDID" defaults write com.apple.keyboard.preferences DidShowContinuousPathIntroduction -bool true
PHASE_START=$SECONDS
xcodebuild -quiet -project StudyDesk.xcodeproj -scheme StudyDesk -configuration Release \
  -sdk iphonesimulator -destination "platform=iOS Simulator,id=$UDID" \
  -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" \
  -clonedSourcePackagesDirPath "$SOURCE_PACKAGES" \
  -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO ARCHS=arm64 ONLY_ACTIVE_ARCH=YES build-for-testing
echo "STUDYDESK_SIMULATOR_BUILD_SUCCEEDED"
echo "STUDYDESK_TIMING_SIMULATOR_BUILD_FOR_TESTING_SECONDS=$((SECONDS - PHASE_START))"
APP_PATH="$BUILD_DIR/SimulatorDerivedData/Build/Products/Release-iphonesimulator/StudyDesk.app"
if [[ ! -d "$APP_PATH" ]]; then
  echo "模拟器构建没有生成预期的 App。" >&2
  exit 1
fi
xcrun simctl ui "$UDID" appearance light
xcrun simctl status_bar "$UDID" override --time '9:41' --batteryState charged --batteryLevel 100
xcrun simctl install "$UDID" "$APP_PATH"

PHASE_START=$SECONDS
for screen in home sidebar review library; do
  args=(--study-preview)
  if [[ "$screen" != home ]]; then args+=("--study-$screen"); fi
  xcrun simctl launch --terminate-running-process --stdout="$BUILD_DIR/previews/$screen.log" \
    "$UDID" com.xiaolong.study2027 "${args[@]}" -AppleLanguages '(zh-Hans)' -AppleLocale zh_CN
  sleep 2
  xcrun simctl io "$UDID" screenshot "$BUILD_DIR/previews/$screen.png"
done

# Preserve a compact dark-mode comparison without doubling the interaction suite.
xcrun simctl ui "$UDID" appearance dark
for screen in home sidebar review library; do
  args=(--study-preview)
  if [[ "$screen" != home ]]; then args+=("--study-$screen"); fi
  xcrun simctl launch --terminate-running-process --stdout="$BUILD_DIR/previews/$screen-dark.log" \
    "$UDID" com.xiaolong.study2027 "${args[@]}" -AppleLanguages '(zh-Hans)' -AppleLocale zh_CN
  sleep 2
  xcrun simctl io "$UDID" screenshot "$BUILD_DIR/previews/$screen-dark.png"
done
echo "STUDYDESK_TIMING_STATIC_PREVIEWS_SECONDS=$((SECONDS - PHASE_START))"

# UI-test attachments are the detailed review set; capture them in light mode.
xcrun simctl ui "$UDID" appearance light

echo "UI previews captured from the actual simulator app."
set +e
PHASE_START=$SECONDS
xcodebuild -project StudyDesk.xcodeproj -scheme StudyDesk -configuration Release \
  -sdk iphonesimulator -destination "platform=iOS Simulator,id=$UDID" \
  -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" -resultBundlePath "$BUILD_DIR/UIInteractionTests.xcresult" \
  -clonedSourcePackagesDirPath "$SOURCE_PACKAGES" \
  -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO ARCHS=arm64 ONLY_ACTIVE_ARCH=YES test-without-building
UI_TEST_STATUS=$?
set -e
echo "STUDYDESK_TIMING_UI_TEST_SECONDS=$((SECONDS - PHASE_START))"
xcrun xcresulttool export attachments --path "$BUILD_DIR/UIInteractionTests.xcresult" \
  --output-path "$BUILD_DIR/previews/interaction-tests" || true
xcrun xcresulttool get test-results summary --path "$BUILD_DIR/UIInteractionTests.xcresult" \
  > "$BUILD_DIR/previews/interaction-tests-summary.json" || true
exit "$UI_TEST_STATUS"
