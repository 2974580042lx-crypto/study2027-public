#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$PROJECT_ROOT/build"
mkdir -p "$BUILD_DIR/previews"
cd "$PROJECT_ROOT"
xcodebuild -quiet -project StudyDesk.xcodeproj -scheme StudyDesk -configuration Release \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" CODE_SIGNING_ALLOWED=NO ARCHS=arm64 build
echo "STUDYDESK_SIMULATOR_BUILD_SUCCEEDED"
APP_PATH="$BUILD_DIR/SimulatorDerivedData/Build/Products/Release-iphonesimulator/StudyDesk.app"
xcrun simctl list devices available -j > "$BUILD_DIR/previews/devices.json"
UDID="$(python3 - "$BUILD_DIR/previews/devices.json" <<'PY'
import json,sys,re
data=json.load(open(sys.argv[1]))['devices']
for runtime,devices in sorted(data.items(),reverse=True):
    match=re.search(r'iOS-(\d+)',runtime)
    if not match or int(match.group(1))<26:continue
    phones=[d for d in devices if d.get('isAvailable') and d['name'].startswith('iPhone')]
    phones.sort(key=lambda d:(d['name']!='iPhone 17 Pro',d['name']!='iPhone 16 Pro',d['name']))
    if phones:
        print(phones[0]['udid'])
        break
else:raise SystemExit('No iOS 26+ simulator available')
PY
)"
xcrun simctl boot "$UDID" || true
xcrun simctl bootstatus "$UDID" -b
xcrun simctl spawn "$UDID" defaults write com.apple.keyboard.preferences DidShowContinuousPathIntroduction -bool true
xcrun simctl ui "$UDID" appearance light
xcrun simctl status_bar "$UDID" override --time '9:41' --batteryState charged --batteryLevel 100
xcrun simctl install "$UDID" "$APP_PATH"

for screen in home review library; do
  args=(--study-preview)
  if [[ "$screen" != home ]]; then args+=("--study-$screen"); fi
  xcrun simctl launch --terminate-running-process --stdout="$BUILD_DIR/previews/$screen.log" \
    "$UDID" com.xiaolong.study2027 "${args[@]}" -AppleLanguages '(zh-Hans)' -AppleLocale zh_CN
  sleep 2
  xcrun simctl io "$UDID" screenshot "$BUILD_DIR/previews/$screen.png"
done

# Preserve a compact dark-mode comparison without doubling the interaction suite.
xcrun simctl ui "$UDID" appearance dark
for screen in home review library; do
  args=(--study-preview)
  if [[ "$screen" != home ]]; then args+=("--study-$screen"); fi
  xcrun simctl launch --terminate-running-process --stdout="$BUILD_DIR/previews/$screen-dark.log" \
    "$UDID" com.xiaolong.study2027 "${args[@]}" -AppleLanguages '(zh-Hans)' -AppleLocale zh_CN
  sleep 2
  xcrun simctl io "$UDID" screenshot "$BUILD_DIR/previews/$screen-dark.png"
done

# UI-test attachments are the detailed review set; capture them in light mode.
xcrun simctl ui "$UDID" appearance light

echo "UI previews captured from the actual simulator app."
set +e
xcodebuild -project StudyDesk.xcodeproj -scheme StudyDesk -configuration Release \
  -sdk iphonesimulator -destination "platform=iOS Simulator,id=$UDID" \
  -derivedDataPath "$BUILD_DIR/SimulatorDerivedData" -resultBundlePath "$BUILD_DIR/UIInteractionTests.xcresult" \
  -parallel-testing-enabled NO CODE_SIGNING_ALLOWED=NO ARCHS=arm64 ONLY_ACTIVE_ARCH=YES test
UI_TEST_STATUS=$?
set -e
xcrun xcresulttool export attachments --path "$BUILD_DIR/UIInteractionTests.xcresult" \
  --output-path "$BUILD_DIR/previews/interaction-tests" || true
xcrun xcresulttool get test-results summary --path "$BUILD_DIR/UIInteractionTests.xcresult" \
  > "$BUILD_DIR/previews/interaction-tests-summary.json" || true
exit "$UI_TEST_STATUS"
