#!/usr/bin/env python3
"""Generate a dependency-free Xcode project using stable object identifiers."""
from pathlib import Path
import os
import hashlib
import json
import plistlib

ROOT = Path(__file__).resolve().parents[1]

def ident(label):
    return hashlib.sha256(label.encode()).hexdigest()[:24].upper()

def quoted(text):
    return json.dumps(text, ensure_ascii=False)

def render(value):
    if isinstance(value, dict):
        return "{ " + " ".join(f"{k} = {render(v)};" for k, v in value.items()) + " }"
    if isinstance(value, list):
        return "( " + ", ".join(render(v) for v in value) + ("," if value else "") + " )"
    if isinstance(value, int):
        return str(value)
    return quoted(value)

objects = {}

def add(label, isa, **fields):
    key = ident(label)
    objects[key] = {"isa": isa, **fields}
    return key

swift_paths = sorted(p.relative_to(ROOT).as_posix() for p in (ROOT / "StudyDesk").rglob("*.swift"))
file_refs, source_builds = [], []
for path in swift_paths:
    ref = add("file:" + path, "PBXFileReference", lastKnownFileType="sourcecode.swift", path=path, sourceTree="SOURCE_ROOT")
    file_refs.append(ref)
    source_builds.append(add("build:" + path, "PBXBuildFile", fileRef=ref))
info_ref = add("Info.plist", "PBXFileReference", lastKnownFileType="text.plist.xml", path="StudyDesk/Info.plist", sourceTree="SOURCE_ROOT")
asset_ref = add("Assets", "PBXFileReference", lastKnownFileType="folder.assetcatalog", path="StudyDesk/Assets.xcassets", sourceTree="SOURCE_ROOT")
asset_build = add("AssetBuild", "PBXBuildFile", fileRef=asset_ref)
extra_resource_refs, extra_resource_builds = [], []
for file in sorted((ROOT / "StudyDesk/Resources").glob("*")):
    if not file.is_file(): continue
    path = file.relative_to(ROOT).as_posix()
    ref = add("resource:" + path, "PBXFileReference", lastKnownFileType="file", path=path, sourceTree="SOURCE_ROOT")
    extra_resource_refs.append(ref)
    extra_resource_builds.append(add("resource-build:" + path, "PBXBuildFile", fileRef=ref))
product_ref = add("Product", "PBXFileReference", explicitFileType="wrapper.application", includeInIndex=0, path="StudyDesk.app", sourceTree="BUILT_PRODUCTS_DIR")
source_phase = add("Sources", "PBXSourcesBuildPhase", buildActionMask=2147483647, files=source_builds, runOnlyForDeploymentPostprocessing=0)
resource_phase = add("Resources", "PBXResourcesBuildPhase", buildActionMask=2147483647, files=[asset_build] + extra_resource_builds, runOnlyForDeploymentPostprocessing=0)
framework_phase = add("Frameworks", "PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
product_group = add("Products", "PBXGroup", children=[product_ref], name="Products", sourceTree="<group>")
source_group = add("AppSources", "PBXGroup", children=file_refs + [info_ref, asset_ref] + extra_resource_refs, name="App", sourceTree="<group>")
main_group = add("MainGroup", "PBXGroup", children=[source_group, product_group], sourceTree="<group>")

project_configs, target_configs = [], []
for name in ["Debug", "Release"]:
    project_settings = {
        "CLANG_ENABLE_MODULES": "YES",
        "CLANG_ENABLE_OBJC_ARC": "YES",
        "IPHONEOS_DEPLOYMENT_TARGET": "26.0",
        "SDKROOT": "iphoneos",
        "SWIFT_VERSION": "5.0",
        "SWIFT_STRICT_CONCURRENCY": "targeted",
        "ENABLE_USER_SCRIPT_SANDBOXING": "YES",
        "DEBUG_INFORMATION_FORMAT": "dwarf" if name == "Debug" else "dwarf-with-dsym",
        "SWIFT_OPTIMIZATION_LEVEL": "-Onone" if name == "Debug" else "-O",
        "GCC_PREPROCESSOR_DEFINITIONS": ["$(inherited)", "DEBUG=1"] if name == "Debug" else ["$(inherited)"],
    }
    if name == "Debug":
        project_settings["ENABLE_TESTABILITY"] = "YES"
        project_settings["SWIFT_ACTIVE_COMPILATION_CONDITIONS"] = "DEBUG"
    target_settings = {
        "PRODUCT_BUNDLE_IDENTIFIER": "com.xiaolong.study2027",
        "PRODUCT_NAME": "StudyDesk",
        "INFOPLIST_FILE": "StudyDesk/Info.plist",
        "GENERATE_INFOPLIST_FILE": "NO",
        "MARKETING_VERSION": "1.4.0",
        "CURRENT_PROJECT_VERSION": "5",
        "ASSETCATALOG_COMPILER_APPICON_NAME": "AppIcon",
        "ASSETCATALOG_COMPILER_GLOBAL_ACCENT_COLOR_NAME": "AccentColor",
        "TARGETED_DEVICE_FAMILY": "1,2",
        "CODE_SIGN_STYLE": "Automatic",
        "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks"],
        "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator",
        "SUPPORTS_MACCATALYST": "NO",
        "SWIFT_EMIT_LOC_STRINGS": "YES",
    }
    project_configs.append(add("ProjectConfig:" + name, "XCBuildConfiguration", buildSettings=project_settings, name=name))
    target_configs.append(add("TargetConfig:" + name, "XCBuildConfiguration", buildSettings=target_settings, name=name))
project_list = add("ProjectConfigs", "XCConfigurationList", buildConfigurations=project_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")
target_list = add("TargetConfigs", "XCConfigurationList", buildConfigurations=target_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")
target = add("Target", "PBXNativeTarget", buildConfigurationList=target_list,
             buildPhases=[source_phase, framework_phase, resource_phase], buildRules=[], dependencies=[],
             name="StudyDesk", productName="StudyDesk", productReference=product_ref,
             productType="com.apple.product-type.application")
# ---- 灵动岛 / 锁屏计时扩展（WidgetKit Live Activity）----
# 扩展需要描述文件覆盖 com.xiaolong.study2027.widgets（通配符描述文件）。
# 只有单一 App ID 的描述文件签不了扩展，所以默认不带；设 STUDY_WIDGETS=1 再生成即可加回来。
WITH_WIDGETS = os.environ.get("STUDY_WIDGETS") == "1"
widget_target = None
if WITH_WIDGETS:
    widget_paths = sorted(p.relative_to(ROOT).as_posix() for p in (ROOT / "StudyDeskWidgets").rglob("*.swift"))
    widget_refs, widget_builds = [], []
    for path in widget_paths:
        ref = add("widget-file:" + path, "PBXFileReference", lastKnownFileType="sourcecode.swift", path=path, sourceTree="SOURCE_ROOT")
        widget_refs.append(ref)
        widget_builds.append(add("widget-build:" + path, "PBXBuildFile", fileRef=ref))
    # 共享的计时数据定义：同一个文件也编进扩展
    for path in sorted(p.relative_to(ROOT).as_posix() for p in (ROOT / "StudyDesk/Shared").rglob("*.swift")):
        widget_builds.append(add("widget-shared-build:" + path, "PBXBuildFile", fileRef=ident("file:" + path)))
    widget_info_ref = add("WidgetInfo", "PBXFileReference", lastKnownFileType="text.plist.xml", path="StudyDeskWidgets/Info.plist", sourceTree="SOURCE_ROOT")
    widget_product = add("WidgetProduct", "PBXFileReference", explicitFileType="wrapper.app-extension", includeInIndex=0, path="StudyDeskWidgets.appex", sourceTree="BUILT_PRODUCTS_DIR")
    widget_sources = add("WidgetSources", "PBXSourcesBuildPhase", buildActionMask=2147483647, files=widget_builds, runOnlyForDeploymentPostprocessing=0)
    widget_frameworks = add("WidgetFrameworks", "PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
    widget_resources = add("WidgetResources", "PBXResourcesBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
    widget_configs = []
    for name in ["Debug", "Release"]:
        app_settings = objects[ident("TargetConfig:" + name)]["buildSettings"]
        widget_configs.append(add("WidgetConfig:" + name, "XCBuildConfiguration", name=name, buildSettings={
            "PRODUCT_BUNDLE_IDENTIFIER": "com.xiaolong.study2027.widgets", "PRODUCT_NAME": "StudyDeskWidgets",
            "INFOPLIST_FILE": "StudyDeskWidgets/Info.plist", "GENERATE_INFOPLIST_FILE": "NO",
            "MARKETING_VERSION": app_settings["MARKETING_VERSION"], "CURRENT_PROJECT_VERSION": app_settings["CURRENT_PROJECT_VERSION"],
            "TARGETED_DEVICE_FAMILY": "1,2", "SKIP_INSTALL": "YES", "APPLICATION_EXTENSION_API_ONLY": "YES",
            "CODE_SIGN_STYLE": "Automatic", "SWIFT_EMIT_LOC_STRINGS": "YES",
            "SUPPORTED_PLATFORMS": "iphoneos iphonesimulator", "SUPPORTS_MACCATALYST": "NO",
            "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks", "@executable_path/../../Frameworks"]}))
    widget_config_list = add("WidgetConfigs", "XCConfigurationList", buildConfigurations=widget_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Release")
    widget_target = add("WidgetTarget", "PBXNativeTarget", buildConfigurationList=widget_config_list,
                        buildPhases=[widget_sources, widget_frameworks, widget_resources], buildRules=[], dependencies=[],
                        name="StudyDeskWidgets", productName="StudyDeskWidgets", productReference=widget_product,
                        productType="com.apple.product-type.app-extension")
    widget_proxy = add("WidgetProxy", "PBXContainerItemProxy", containerPortal=ident("Project"), proxyType=1, remoteGlobalIDString=widget_target, remoteInfo="StudyDeskWidgets")
    widget_dependency = add("WidgetDependency", "PBXTargetDependency", target=widget_target, targetProxy=widget_proxy)
    widget_embed_build = add("WidgetEmbedBuild", "PBXBuildFile", fileRef=widget_product, settings={"ATTRIBUTES": ["RemoveHeadersOnCopy"]})
    widget_embed = add("WidgetEmbed", "PBXCopyFilesBuildPhase", buildActionMask=2147483647, dstPath="", dstSubfolderSpec=13,
                       files=[widget_embed_build], name="Embed App Extensions", runOnlyForDeploymentPostprocessing=0)
    objects[target]["buildPhases"].append(widget_embed)
    objects[target]["dependencies"].append(widget_dependency)
    widget_group = add("WidgetGroup", "PBXGroup", children=widget_refs + [widget_info_ref], name="Widgets", sourceTree="<group>")
    objects[main_group]["children"].insert(1, widget_group)
    objects[product_group]["children"].append(widget_product)

ui_ref = add("UITestSource", "PBXFileReference", lastKnownFileType="sourcecode.swift", path="UITests/NavigationUITests.swift", sourceTree="SOURCE_ROOT")
ui_build = add("UITestBuild", "PBXBuildFile", fileRef=ui_ref)
ui_sources = add("UITestSources", "PBXSourcesBuildPhase", buildActionMask=2147483647, files=[ui_build], runOnlyForDeploymentPostprocessing=0)
ui_frameworks = add("UITestFrameworks", "PBXFrameworksBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
ui_resources = add("UITestResources", "PBXResourcesBuildPhase", buildActionMask=2147483647, files=[], runOnlyForDeploymentPostprocessing=0)
ui_product = add("UITestProduct", "PBXFileReference", explicitFileType="wrapper.cfbundle", includeInIndex=0, path="StudyDeskUITests.xctest", sourceTree="BUILT_PRODUCTS_DIR")
ui_configs = []
for name in ["Debug", "Release"]:
    ui_configs.append(add("UITestConfig:" + name, "XCBuildConfiguration", name=name, buildSettings={
        "PRODUCT_BUNDLE_IDENTIFIER": "com.xiaolong.study2027.uitests", "PRODUCT_NAME": "StudyDeskUITests",
        "GENERATE_INFOPLIST_FILE": "YES", "TEST_TARGET_NAME": "StudyDesk", "TARGETED_DEVICE_FAMILY": "1,2",
        "CODE_SIGNING_ALLOWED": "NO", "LD_RUNPATH_SEARCH_PATHS": ["$(inherited)", "@executable_path/Frameworks", "@loader_path/Frameworks"]}))
ui_config_list = add("UITestConfigs", "XCConfigurationList", buildConfigurations=ui_configs, defaultConfigurationIsVisible=0, defaultConfigurationName="Debug")
proxy = add("UITestProxy", "PBXContainerItemProxy", containerPortal=ident("Project"), proxyType=1, remoteGlobalIDString=target, remoteInfo="StudyDesk")
dependency = add("UITestDependency", "PBXTargetDependency", target=target, targetProxy=proxy)
ui_target = add("UITestTarget", "PBXNativeTarget", buildConfigurationList=ui_config_list, buildPhases=[ui_sources, ui_frameworks, ui_resources],
                buildRules=[], dependencies=[dependency], name="StudyDeskUITests", productName="StudyDeskUITests",
                productReference=ui_product, productType="com.apple.product-type.bundle.ui-testing")
objects[source_group]["children"].append(ui_ref)
objects[product_group]["children"].append(ui_product)
project = add("Project", "PBXProject", attributes={"LastUpgradeCheck": "1600", "LastSwiftUpdateCheck": "1600", "TargetAttributes": {target: {"CreatedOnToolsVersion": "16.0"}}},
              buildConfigurationList=project_list, compatibilityVersion="Xcode 14.0", developmentRegion="zh_CN",
              hasScannedForEncodings=0, knownRegions=["zh_CN", "en", "Base"], mainGroup=main_group,
              productRefGroup=product_group, projectDirPath="", projectRoot="", targets=[t for t in (target, widget_target, ui_target) if t])
objects[project]["attributes"]["TargetAttributes"][ui_target] = {"CreatedOnToolsVersion": "26.0", "TestTargetID": target}
if widget_target:
    objects[project]["attributes"]["TargetAttributes"][widget_target] = {"CreatedOnToolsVersion": "26.0"}

DEPENDENCIES = [('FSRS', 'https://github.com/open-spaced-repetition/swift-fsrs.git', '4fbaf20184d62f82a9f44f343337c61a2c5483e9'), ('SwiftCSV', 'https://github.com/swiftcsv/SwiftCSV.git', '324d583f2e6eb587c62bcd8574693d5c4f9b6eff'), ('JWTKit', 'https://github.com/vapor/jwt-kit.git', '13e7513b3ba0afa13967daf77af2fb4ad087306c')]
# Pinned upstream packages; keep algorithms and parsing outside the app glue.
package_refs, products = [], []
for product, url, revision in DEPENDENCIES:
    package = add("package:" + product, "XCRemoteSwiftPackageReference", repositoryURL=url,
                  requirement={"kind": "revision", "revision": revision})
    dependency = add("package-product:" + product, "XCSwiftPackageProductDependency", package=package, productName=product)
    build = add("package-build:" + product, "PBXBuildFile", productRef=dependency)
    package_refs.append(package); products.append(dependency)
    objects[framework_phase]["files"].append(build)
objects[target]["packageProductDependencies"] = products
objects[project]["packageReferences"] = package_refs

project_dir = ROOT / "StudyDesk.xcodeproj"
project_dir.mkdir(parents=True, exist_ok=True)
body = "\n".join(f"\t\t{key} = {render(value)};" for key, value in sorted(objects.items()))
(project_dir / "project.pbxproj").write_text("// !$*UTF8*$!\n{\n\tarchiveVersion = 1;\n\tclasses = {};\n\tobjectVersion = 56;\n\tobjects = {\n" + body + "\n\t};\n\trootObject = " + project + ";\n}\n", encoding="utf-8")
scheme_dir = project_dir / "xcshareddata" / "xcschemes"
scheme_dir.mkdir(parents=True, exist_ok=True)
reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="StudyDesk.app" BlueprintName="StudyDesk" ReferencedContainer="container:StudyDesk.xcodeproj"/>'
ui_reference = f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{ui_target}" BuildableName="StudyDeskUITests.xctest" BlueprintName="StudyDeskUITests" ReferencedContainer="container:StudyDesk.xcodeproj"/>'
(scheme_dir / "StudyDesk.xcscheme").write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3">
  <BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES">
    <BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{reference}</BuildActionEntry><BuildActionEntry buildForTesting="YES" buildForRunning="NO" buildForProfiling="NO" buildForArchiving="NO" buildForAnalyzing="NO">{ui_reference}</BuildActionEntry></BuildActionEntries>
  </BuildAction>
  <TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO">{ui_reference}</TestableReference></Testables></TestAction>
  <LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></LaunchAction>
  <ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{reference}</BuildableProductRunnable></ProfileAction>
  <AnalyzeAction buildConfiguration="Debug"/>
  <ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>
''', encoding="utf-8")
print(f"Generated Xcode project for {len(swift_paths)} Swift source files.")
