#!/usr/bin/env python3
"""把 content/history/*.txt 转成 App 内置的史事词典 StudyDesk/Resources/history-entries.json。

每条首行：名称 | 年份 | 类别 | 别名（逗号分隔），下一行起是正文，空行结束；@章节ID 开始一节。
脚本会检查章节 ID、年份格式、重名，并把正文中提到的其他条目标成链接。
"""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "content/history"
OUTPUT = ROOT / "StudyDesk/Resources/history-entries.json"
PLAN = ROOT / "StudyDesk/LearningCore/StudyPlanModels.swift"


def node_ids():
    """从 SyllabusSeed 里读出所有历史章节 ID，保证词典挂得上考纲。"""
    text = PLAN.read_text(encoding="utf-8")
    ids = set()
    for prefix, titles in re.findall(r'add\(\.history, "([^"]+)", "[^"]+", \[([^\]]*)\]\)', text):
        count = len(re.findall(r'"[^"]*"', titles))
        ids.update(f"{prefix}-{i + 1:02d}" for i in range(count))
    return ids


def parse_year(raw, where):
    raw = raw.strip()
    if not raw:
        return None, None
    m = re.fullmatch(r"(-?\d{1,4})(?:~(-?\d{1,4}))?", raw)
    if not m:
        sys.exit(f"{where}: 年份格式不对：{raw}")
    start = int(m.group(1))
    end = int(m.group(2)) if m.group(2) else None
    if end is not None and end < start:
        sys.exit(f"{where}: 结束年份早于开始年份：{raw}")
    return start, end


def parse():
    valid = node_ids()
    entries, node = [], None
    for path in sorted(SOURCE.glob("*.txt")):
        lines = path.read_text(encoding="utf-8").splitlines() + [""]
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            where = f"{path.name}:{i + 1}"
            if not line or line.startswith("#"):
                i += 1
                continue
            if line.startswith("@"):
                node = line[1:].strip()
                if node not in valid:
                    sys.exit(f"{where}: 考纲里没有这个章节：{node}")
                i += 1
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) != 4 or not parts[0]:
                sys.exit(f"{where}: 首行要有 4 段（名称 | 年份 | 类别 | 别名）：{line}")
            if node is None:
                sys.exit(f"{where}: 条目前缺少 @章节ID")
            body = []
            i += 1
            while i < len(lines) and lines[i].strip():
                body.append(lines[i].strip())
                i += 1
            if not body:
                sys.exit(f"{where}: {parts[0]} 没有正文")
            start, end = parse_year(parts[1], where)
            entries.append({
                "id": f"{node}:{len([e for e in entries if e['nodeID'] == node]) + 1:02d}",
                "title": parts[0],
                "aliases": [a.strip() for a in parts[3].replace("，", ",").split(",") if a.strip()],
                "kind": parts[2] or "概念",
                "nodeID": node,
                "year": start,
                "endYear": end,
                "text": "\n".join(body),
            })
    return entries


def bare(name):
    return name.strip("《》")


def add_links(entries):
    """正文里出现别的条目的名称或别名，就记成链接；每个目标只链第一次。"""
    owner = {}
    for e in entries:
        for term in [e["title"], bare(e["title"])] + e["aliases"]:
            if len(term) < 2:
                continue
            if term in owner and owner[term] != e["id"]:
                # 同名的别名只给第一个条目，避免点出去跳错
                continue
            owner[term] = e["id"]
    terms = sorted(owner, key=len, reverse=True)
    for e in entries:
        text = e["text"]
        taken = [False] * len(text)
        own = {e["title"], bare(e["title"]), *e["aliases"]}
        # 先占住本条自己的名字，避免「联合国家宣言」里的「联合国」被链走
        for term in sorted(own, key=len, reverse=True):
            for m in re.finditer(re.escape(term), text):
                for k in range(m.start(), m.end()):
                    taken[k] = True
        links, linked = [], set()
        for term in terms:
            target = owner[term]
            if target == e["id"] or target in linked:
                continue
            for m in re.finditer(re.escape(term), text):
                if any(taken[m.start():m.end()]):
                    continue
                for k in range(m.start(), m.end()):
                    taken[k] = True
                links.append({"text": term, "id": target})
                linked.add(target)
                break
        e["links"] = links


def main():
    entries = parse()
    titles = [e["title"] for e in entries]
    dupes = {t for t in titles if titles.count(t) > 1}
    if dupes:
        sys.exit("重名条目：" + "、".join(sorted(dupes)))
    add_links(entries)
    OUTPUT.write_text(json.dumps({"version": 1, "entries": entries}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    covered = {e["nodeID"] for e in entries}
    missing = sorted(node_ids() - covered)
    print(f"史事词典：{len(entries)} 条，年表 {sum(e['year'] is not None for e in entries)} 条，"
          f"链接 {sum(len(e['links']) for e in entries)} 个，覆盖章节 {len(covered)} 个")
    if missing:
        print("还没有条目的章节：" + "、".join(missing))


if __name__ == "__main__":
    main()
