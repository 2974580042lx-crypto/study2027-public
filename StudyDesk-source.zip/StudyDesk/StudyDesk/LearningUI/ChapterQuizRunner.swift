import Foundation

enum ChapterQuizPreview {
    static let reply = """
    {"questions":[
     {"stem":"汉武帝为解决王国问题，采纳主父偃建议颁布的是","options":["推恩令","刺史制度","盐铁官营","郡国并行"],"answer":"A","explanation":"推恩令让诸侯王把封地分给子弟，王国越分越小。刺史制度是监察措施。"},
     {"stem":"西汉设西域都护府的时间是","options":["前138年","前119年","前60年","公元73年"],"answer":"C","explanation":"前60年设西域都护府，西域正式归属中央。前138年是张骞第一次出使。"}
    ]}
    """
}

extension LearningStore {
    /// 某一节已经出过的 AI 题
    func chapterQuizQuestions(nodeID: String) -> [StudyQuestion] {
        guard let node = syllabusNodes.first(where: { $0.id == nodeID }) else { return [] }
        let group = ChapterQuiz.group(block: node.block, title: node.title)
        return state.questions.filter { $0.group == group }
    }

    /// 让 AI 给这一节出一组单选题，存进题库并返回新题。
    func generateChapterQuiz(nodeID: String, chat: AppStore) async throws -> [StudyQuestion] {
        guard writable else { throw StudyFailure.message("学习记录现在是只读状态。") }
        guard let node = syllabusNodes.first(where: { $0.id == nodeID }) else { throw StudyFailure.message("找不到这一节。") }
        let group = ChapterQuiz.group(block: node.block, title: node.title)
        let reference = HistoryDictionary.bundled.entries(inNode: nodeID).map { "\($0.title)：\(String($0.text.prefix(70)))" }
        let weak = memoryItems.filter { $0.category == .weakPoints }.map(\.text)
        let input = ChapterQuiz.Input(block: node.block, title: node.title, reference: reference,
                                      previousStems: state.questions.filter { $0.group == group }.map(\.stem), weakPoints: weak)
        let text = try await chat.completeOnce(system: ChapterQuiz.systemPrompt(node.subject), user: ChapterQuiz.userMessage(input),
                                               previewReply: ChapterQuizPreview.reply)
        let questions = try ChapterQuiz.parse(text, subject: node.subject, group: group, idPrefix: "ai-\(nodeID)")
        state.questions.append(contentsOf: questions)
        save()
        return questions
    }
}
