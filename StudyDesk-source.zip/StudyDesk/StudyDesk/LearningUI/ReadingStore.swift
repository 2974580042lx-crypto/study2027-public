import Foundation

@MainActor
extension LearningStore {
    var readingPassages: [ReadingPassage] { state.readingPassages ?? [] }
    var readingWords: [ReadingWord] { state.readingWords ?? [] }
    @discardableResult private func readingChange(_ body: (inout StudySnapshot) throws -> Void) -> Bool {
        guard writable else { return false }
        var candidate = state
        do {
            try body(&candidate); try candidate.validate()
            let old = state; state = candidate
            if save() { return true }
            state = old; return false
        } catch { self.error = error.localizedDescription; return false }
    }
    @discardableResult func openReading(_ id: String, restart: Bool = false) -> UUID? {
        var result: UUID?
        guard readingChange({ result = try $0.beginReading(id, restart: restart) }) else { return nil }
        return result
    }
    func selectReading(attemptID: UUID, questionID: String, option: Int) {
        readingChange { try $0.chooseReadingOption(attemptID: attemptID, questionID: questionID, option: option) }
    }
    @discardableResult func finishReading(_ attemptID: UUID) -> Bool {
        readingChange { _ = try $0.submitReading(attemptID) }
    }
    func rememberReadingPosition(_ attemptID: UUID, paragraph: Int) {
        guard let attempt = state.readingAttempts?.first(where: { $0.id == attemptID }), attempt.paragraph != paragraph,
              let passage = readingPassages.first(where: { $0.id == attempt.passageID }), passage.paragraphs.indices.contains(paragraph) else { return }
        readingChange { state in
            if let index = state.readingAttempts?.firstIndex(where: { $0.id == attemptID }) { state.readingAttempts?[index].paragraph = paragraph }
        }
    }
    func cardForReadingTerm(_ term: String) -> StudyCard? {
        let normalized = ReadingWords.normalized(term)
        if let collected = readingWords.first(where: { $0.normalizedTerm == normalized }), let card = state.cards.first(where: { $0.id == collected.cardID }) { return card }
        return state.cards.first { $0.subject == .english && ReadingWords.normalized($0.front) == normalized }
    }
    @discardableResult func saveReadingWord(term: String, definition: String, example: ReadingWordExample) -> Bool {
        readingChange { _ = try $0.collectReadingWord(term: term, definition: definition, example: example) }
    }
    func removeReadingWord(_ cardID: String) {
        readingChange { $0.readingWords?.removeAll { $0.cardID == cardID } }
    }
    func ensureReadingExample() {
        guard !readingPassages.contains(where: { $0.id == "reading-feature-example" }),
              let url = Bundle.main.url(forResource: "reading-example", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let pack = try? JSONDecoder().decode(ImportedStudyPack.self, from: data), let passages = pack.readings else { return }
        readingChange { $0.readingPassages = ($0.readingPassages ?? []) + passages }
    }
}
