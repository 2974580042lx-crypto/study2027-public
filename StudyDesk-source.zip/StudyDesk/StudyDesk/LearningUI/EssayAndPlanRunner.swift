import Foundation

enum EssayPreview {
    static let task = #"{"title":"古代中央集权的演变","prompt":"试论秦至清中央集权制度的演变趋势及其历史影响。"}"#
    static let grade = """
    {"score":19.5,"points":[{"point":"秦确立皇帝制度、三公九卿和郡县制（6分）","hit":"full","comment":"到位"},
     {"point":"汉至唐处理中央与地方、君权与相权（8分）","hit":"partial","comment":"漏了三省六部对相权的分割"},
     {"point":"宋元明清的强化（明废丞相、清设军机处）（8分）","hit":"partial","comment":"军机处只写了时间，没写作用"},
     {"point":"影响：积极与消极两方面（8分）","hit":"miss","comment":"没有展开影响"}],
     "summary":"主线清楚，但中段跳得太快，影响部分基本没写。","improvements":["按「中央与地方」「君权与相权」两条线组织","影响分积极、消极各写两三点"],
     "corrections":[],"weakPoints":["军机处的作用说不清","中央集权的影响答不全"]}
    """
    static let outline = "主线一：中央与地方——分封制→郡县制→郡国并行→推恩令、刺史→藩镇割据→宋削藩→行省制。\n主线二：君权与相权——三公九卿→三省六部→宋分相权→明废丞相、设内阁→清军机处。\n影响：积极——巩固统一、促进民族融合；消极——后期压制思想、阻碍社会转型。"
    static let diagnosis = #"{"diagnosis":"本周选择题稳定，大题是短板：知识点知道，但组织不成体系。","errorTypes":[{"type":"答题不成体系","detail":"中央集权论述题只按朝代罗列，没有主线"}],"focus":["每天一道 313 论述题，先列提纲再写","重做本周错题","政治分析题练两道"]}"#
}

extension LearningStore {
    // MARK: 大题

    var essayTasks: [EssayTask] { state.essays ?? [] }
    func essay(_ id: String) -> EssayTask? { essayTasks.first { $0.id == id } }

    /// 出一道主观题。nodeID 和 topicID 二选一，都没有就按整个科目出。
    func generateEssay(kind: EssayKind, nodeID: String?, topicID: String?, chat: AppStore) async throws -> EssayTask {
        guard writable else { throw StudyFailure.message("学习记录现在是只读状态。") }
        let dict = HistoryDictionary.bundled
        var scope = kind.subject.title, reference: [String] = []
        if let topicID, let topic = HistoryTopics.topic(topicID) {
            scope = topic.title + "（" + topic.focus + "）"
            reference = topic.entries(in: dict).map { "\($0.title)：\(String($0.text.prefix(60)))" }
        } else if let nodeID, let node = syllabusNodes.first(where: { $0.id == nodeID }) {
            scope = "\(node.block) · \(node.title)"
            reference = dict.entries(inNode: nodeID).map { "\($0.title)：\(String($0.text.prefix(60)))" }
        }
        let weak = memoryItems.filter { $0.category == .weakPoints }.map(\.text)
        let previous = essayTasks.filter { $0.kind == kind }.map(\.title)
        let text = try await chat.completeOnce(system: EssayPractice.generateSystemPrompt(kind),
                                               user: EssayPractice.generateUserMessage(kind: kind, scope: scope, reference: reference, weakPoints: weak, previousTitles: previous),
                                               previewReply: EssayPreview.task)
        let shortScope = topicID.flatMap { HistoryTopics.topic($0)?.title } ?? (scope.components(separatedBy: "（").first ?? scope)
        let task = try EssayPractice.parseTask(text, kind: kind, scope: shortScope, nodeID: nodeID, topicID: topicID)
        var list = essayTasks; list.append(task); state.essays = list; save()
        return task
    }

    /// 批改并记录；薄弱点并入长期记忆
    func gradeEssay(_ id: String, answer: String, chat: AppStore) async throws -> EssayAttempt {
        guard writable, let task = essay(id) else { throw StudyFailure.message("找不到这道题。") }
        let answer = answer.trimmingCharacters(in: .whitespacesAndNewlines)
        guard answer.count >= 20 else { throw StudyFailure.message("答案太短了，至少写出几个要点再批改。") }
        let text = try await chat.completeOnce(system: EssayPractice.gradeSystemPrompt(task.kind),
                                               user: EssayPractice.gradeUserMessage(task: task, answer: answer, previous: task.latest),
                                               previewReply: EssayPreview.grade)
        let attempt = try EssayPractice.parseGrade(text, kind: task.kind, answer: answer)
        guard let i = state.essays?.firstIndex(where: { $0.id == id }) else { return attempt }
        state.essays?[i].attempts.append(attempt)
        state.essays?[i].draft = nil
        var memories = memoryItems
        if EssayPractice.mergeWeakPoints(attempt.weakPoints, into: &memories, scope: task.kind.title) > 0 { state.memories = memories }
        let now = Date()
        state.events.append(LearningEvent(subject: task.kind.subject, kind: .essay, title: "\(task.kind.title)：\(task.title)",
                                         detail: "\(task.kind.title) · \(EssayPractice.formatScore(attempt.score)) / \(task.kind.fullScore) 分",
                                         start: now, end: now, referenceID: task.id))
        save()
        return attempt
    }

    func saveEssayDraft(_ id: String, text: String) {
        guard writable, let i = state.essays?.firstIndex(where: { $0.id == id }), state.essays?[i].draft != text else { return }
        state.essays?[i].draft = text; save()
    }
    func deleteEssay(_ id: String) {
        guard writable else { return }
        state.essays?.removeAll { $0.id == id }; save()
    }

    // MARK: 专题框架

    func topicOutline(_ topicID: String) -> String? { state.topicOutlines?[topicID] }

    func generateTopicOutline(_ topicID: String, chat: AppStore) async throws {
        guard writable, let topic = HistoryTopics.topic(topicID) else { return }
        let reference = topic.entries(in: HistoryDictionary.bundled).map { "\($0.yearText ?? "") \($0.title)：\(String($0.text.prefix(50)))" }
        let system = """
        你是 313 历史学基础的辅导老师。为给定专题写一份论述题答题框架，帮学生把散的知识点串成主线。
        要求：按 2—4 条主线或阶段组织，每条下面列关键史实和「为什么这样变」；最后写影响或评价（分积极、消极或分层次）。
        史实必须准确，不确定的不写。总长 600 字以内，用纯文本分行，不用 Markdown 符号。
        """
        let user = "专题：\(topic.title)\n主线提示：\(topic.focus)\n相关条目：\n" + reference.prefix(30).joined(separator: "\n")
        let text = try await chat.completeOnce(system: system, user: user, previewReply: EssayPreview.outline)
        let outline = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !outline.isEmpty else { throw StudyFailure.message("AI 没有返回内容，再试一次。") }
        var all = state.topicOutlines ?? [:]; all[topicID] = outline; state.topicOutlines = all; save()
    }

    // MARK: 今日计划

    func todayPlan(at now: Date = Date()) -> DailyPlan {
        DailyPlanner.plan(for: now, plans: state.plans ?? [], digests: digestList)
    }
    private func updateTodayPlan(_ change: (inout DailyPlan) -> Void) {
        guard writable else { return }
        var plan = todayPlan(); change(&plan)
        var plans = state.plans ?? []; DailyPlanner.store(plan, in: &plans); state.plans = plans; save()
    }
    func togglePlanItem(_ id: String) { updateTodayPlan { p in if let i = p.items.firstIndex(where: { $0.id == id }) { p.items[i].done.toggle() } } }
    func addPlanItem(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        updateTodayPlan { $0.items.append(PlanItem(text: String(t.prefix(80)))) }
    }
    func editPlanItem(_ id: String, text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else { return }
        updateTodayPlan { p in if let i = p.items.firstIndex(where: { $0.id == id }) { p.items[i].text = String(t.prefix(80)) } }
    }
    func deletePlanItem(_ id: String) { updateTodayPlan { $0.items.removeAll { $0.id == id } } }

    // MARK: 周报

    func weeklyReport(weekStart: Date) -> WeeklyReport {
        WeeklyReport.compute(weekStart: weekStart, events: state.events, attempts: state.attempts, questions: state.questions,
                             essays: essayTasks, digests: digestList)
    }
    func weeklyDiagnosis(weekStart: Date) -> WeeklyDiagnosis? {
        let id = WeeklyReport.id(for: weekStart)
        return state.weeklyDiagnoses?.first { $0.id == id }
    }
    func runWeeklyDiagnosis(weekStart: Date, chat: AppStore) async throws {
        guard writable else { return }
        let report = weeklyReport(weekStart: weekStart)
        let days = StudyPreferences.daysUntil(state.preferences.examDate, from: Date())
        let text = try await chat.completeOnce(system: WeeklyReview.systemPrompt, user: WeeklyReview.userMessage(report, examDays: days),
                                               previewReply: EssayPreview.diagnosis)
        let diagnosis = try WeeklyReview.parse(text, id: WeeklyReport.id(for: weekStart))
        var list = state.weeklyDiagnoses ?? []
        list.removeAll { $0.id == diagnosis.id }; list.append(diagnosis)
        state.weeklyDiagnoses = Array(list.suffix(12)); save()
    }
}
