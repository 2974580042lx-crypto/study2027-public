import SwiftUI
import PencilKit

/// 大题：按科目出题、看历史作答，313 另有专题入口
@MainActor
struct EssayHubView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    @State private var subject: StudySubject = .history
    @State private var generating = false
    @State private var issue: String?
    @State private var opened: EssayRef?
    @State private var addingCustom = false

    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text("大题").font(TypeScale.serif(29, relativeTo: .title)).padding(.top, Space.xl)
                Text("先自己写，再看得分点。漏掉的点会记进「记忆」，之后出题和汇总都会照顾到。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.xs).padding(.bottom, Space.l)
                InkTabs(items: [(StudySubject.history, "313 历史学"), (.politics, "政治"), (.english, "英语一")], selection: $subject)

                let mine = learning.essayTasks.filter { $0.kind.subject == subject }
                // 真题只有写了一半才算「没写完」，不然几十道真题会挤满这里
                let unfinished = mine.filter { $0.attempts.isEmpty && (!$0.isReal || hasProgress($0)) }.reversed()
                let reals = mine.filter(\.isReal)
                if !unfinished.isEmpty {
                    InkSectionHeader(title: "没写完的", trailing: "\(unfinished.count) 道").padding(.top, Space.xl).padding(.bottom, Space.s)
                    ForEach(Array(unfinished)) { task in
                        NavigationLink { EssayTaskView(taskID: task.id) } label: {
                            InkRow(title: task.title, detail: "\(task.kind.title) · \(task.scope)", value: progressText(task), valueIsSeal: true, chevron: true)
                        }.buttonStyle(.plain).accessibilityIdentifier("essay-unfinished")
                        .contextMenu { Button("删除", role: .destructive) { learning.deleteEssay(task.id) } }
                    }
                }

                if !reals.isEmpty {
                    NavigationLink { RealEssayListView(subject: subject) } label: {
                        InkRow(title: "历年真题", detail: "按年份列出，可以手写或打字作答、批改",
                               value: "\(reals.count) 道 · 做过 \(reals.filter { !$0.attempts.isEmpty }.count)", chevron: true)
                    }.buttonStyle(.plain).padding(.top, Space.l).accessibilityIdentifier("essay-real-list")
                }

                InkSectionHeader(title: "出一道新题").padding(.top, Space.xl).padding(.bottom, Space.s)
                ForEach(EssayKind.kinds(for: subject), id: \.self) { kind in
                    Button { generate(kind) } label: {
                        InkRow(title: kind.title, detail: detail(kind), value: "满分 \(kind.fullScore)", chevron: true)
                    }.buttonStyle(.plain).disabled(generating || !aiReady).accessibilityIdentifier("essay-new-\(kind.rawValue)")
                }
                if generating { HStack(spacing: Space.s) { ProgressView().controlSize(.small); Text("正在出题…") }.font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s) }
                if !aiReady { Text("先在设置里连上 AI 才能出题和批改。").font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
                if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
                Button { addingCustom = true } label: {
                    InkRow(title: "录入一道题", detail: "把书上的真题、模拟题录进来，照样作答、批改", chevron: true)
                }.buttonStyle(.plain).accessibilityIdentifier("essay-add-custom")

                let finished = mine.filter { !$0.attempts.isEmpty && !$0.isReal }.reversed()
                if !finished.isEmpty {
                    InkSectionHeader(title: "做过的题", trailing: "\(finished.count) 道").padding(.top, Space.section).padding(.bottom, Space.s)
                    ForEach(Array(finished)) { task in
                        NavigationLink { EssayTaskView(taskID: task.id) } label: {
                            InkRow(title: task.title, detail: "\(task.kind.title) · \(task.scope)", value: scoreText(task), chevron: true)
                        }.buttonStyle(.plain)
                        .contextMenu { Button("删除", role: .destructive) { learning.deleteEssay(task.id) } }
                    }
                }

                if subject == .history {
                    InkSectionHeader(title: "专题", trailing: "\(HistoryTopics.all.count) 个").padding(.top, Space.section).padding(.bottom, Space.s)
                    Text("统考论述题常考贯通性的题目。专题把几个章节串成一条线，可以先看框架再出题。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.bottom, Space.s)
                    ForEach(HistoryTopics.all) { topic in
                        NavigationLink { HistoryTopicView(topicID: topic.id) } label: {
                            InkRow(title: topic.title, detail: topic.block + (learning.topicOutline(topic.id) == nil ? "" : " · 已有框架"),
                                   value: topicScore(topic.id), chevron: true)
                        }.buttonStyle(.plain).accessibilityIdentifier("topic-\(topic.id)")
                    }
                }

            }
        }
        .navigationTitle("大题").navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $addingCustom) {
            CustomEssaySheet(subject: subject) { opened = EssayRef(id: $0.id) }
        }
        .navigationDestination(item: $opened) { EssayTaskView(taskID: $0.id) }
        .accessibilityIdentifier("essay-hub")
    }

    private var aiReady: Bool { chat.canUseAI || chat.isPreview }
    private func detail(_ kind: EssayKind) -> String {
        switch kind {
        case .historyEssay: "按整个 313 出，想按章节或专题出，到考纲或下面的专题里"
        case .historyMaterial: "材料 + 2—3 问"
        case .politicsAnalysis: "材料 + 1—2 问，考原理运用"
        case .englishLarge: "图画 / 图表作文，160—200 词"
        case .englishSmall: "书信、通知等应用文，约 100 词"
        }
    }
    private func hasProgress(_ task: EssayTask) -> Bool {
        !(task.draft ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !learning.drawing("essay-\(task.id)").strokes.isEmpty
    }
    /// 没写完的题：有没有打字草稿、手写笔迹
    private func progressText(_ task: EssayTask) -> String {
        let typed = !(task.draft ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        let inked = !learning.drawing("essay-\(task.id)").strokes.isEmpty
        return typed && inked ? "有草稿和手写" : typed ? "有草稿" : inked ? "写了一半" : "未作答"
    }
    private func scoreText(_ task: EssayTask) -> String {
        guard let best = task.best else { return "未作答" }
        return "\(EssayPractice.formatScore(best.score)) / \(task.fullScore)"
    }
    private func topicScore(_ id: String) -> String? {
        let done = learning.essayTasks.filter { $0.topicID == id && !$0.attempts.isEmpty }
        return done.isEmpty ? nil : "做过 \(done.count) 题"
    }
    private func generate(_ kind: EssayKind) {
        generating = true; issue = nil
        Task {
            defer { generating = false }
            do { opened = EssayRef(id: try await learning.generateEssay(kind: kind, nodeID: nil, topicID: nil, chat: chat).id) }
            catch { issue = error.localizedDescription }
        }
    }
}

struct EssayRef: Identifiable, Hashable { let id: String }

/// 专题页：主线提示、相关章节和词条、AI 答题框架、按专题出题
@MainActor
struct HistoryTopicView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let topicID: String
    @State private var working: String?
    @State private var issue: String?
    @State private var opened: EssayRef?

    var body: some View {
        if let topic = HistoryTopics.topic(topicID) {
            InkPage(spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(topic.block).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                    Text(topic.title).font(TypeScale.serif(26, relativeTo: .title)).padding(.top, Space.xs)
                    Text(topic.focus).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).padding(.top, Space.m)

                    InkSectionHeader(title: "答题框架").padding(.top, Space.section).padding(.bottom, Space.s)
                    if let outline = learning.topicOutline(topicID) {
                        Text(outline).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineSpacing(7).textSelection(.enabled)
                            .accessibilityIdentifier("topic-outline")
                    } else {
                        Text("先自己在纸上列一遍主线，再让 AI 给一份对照，效果更好。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    }
                    HStack(spacing: Space.m) {
                        action(learning.topicOutline(topicID) == nil ? "✦ 生成框架" : "重新生成", key: "outline") {
                            try await learning.generateTopicOutline(topicID, chat: chat)
                        }
                        action("出论述题", key: "essay") {
                            opened = EssayRef(id: try await learning.generateEssay(kind: .historyEssay, nodeID: nil, topicID: topicID, chat: chat).id)
                        }.accessibilityIdentifier("topic-new-essay")
                        action("出材料题", key: "material") {
                            opened = EssayRef(id: try await learning.generateEssay(kind: .historyMaterial, nodeID: nil, topicID: topicID, chat: chat).id)
                        }
                    }.padding(.top, Space.l)
                    if let working { Text(working == "outline" ? "正在整理框架…" : "正在出题…").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s) }
                    if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }

                    let done = learning.essayTasks.filter { $0.topicID == topicID }
                    if !done.isEmpty {
                        InkSectionHeader(title: "这个专题做过的题").padding(.top, Space.section).padding(.bottom, Space.s)
                        ForEach(done) { task in
                            NavigationLink { EssayTaskView(taskID: task.id) } label: {
                                InkRow(title: task.title, detail: task.kind.title,
                                       value: task.best.map { "\(EssayPractice.formatScore($0.score)) / \(task.fullScore)" } ?? "未作答", chevron: true)
                            }.buttonStyle(.plain)
                        }
                    }

                    InkSectionHeader(title: "涉及的章节").padding(.top, Space.section).padding(.bottom, Space.s)
                    Text(topic.nodeIDs.compactMap { id in learning.syllabusNodes.first { $0.id == id }.map { "\($0.block) · \($0.title)" } }.joined(separator: "\n"))
                        .font(TypeScale.label).foregroundStyle(Ink.ink2).lineSpacing(5)
                    InkSectionHeader(title: "相关条目").padding(.top, Space.section).padding(.bottom, Space.xs)
                    ForEach(topic.entries(in: HistoryDictionary.bundled).sorted { ($0.year ?? .max) < ($1.year ?? .max) }) {
                        HistoryEntryRow(entry: $0, showYear: true)
                    }
                }
            }
            .navigationTitle("专题").navigationBarTitleDisplayMode(.inline)
            .navigationDestination(item: $opened) { EssayTaskView(taskID: $0.id) }
        } else {
            ContentUnavailableView("找不到这个专题", systemImage: "questionmark")
        }
    }

    private func action(_ title: String, key: String, run: @escaping () async throws -> Void) -> some View {
        Button(title) {
            working = key; issue = nil
            Task {
                defer { working = nil }
                do { try await run() } catch { issue = error.localizedDescription }
            }
        }.buttonStyle(.inkGlass).disabled(working != nil || !(chat.canUseAI || chat.isPreview))
    }
}

/// 一道大题：题目、作答（自动存草稿）、批改结果、历次得分
@MainActor
struct EssayTaskView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let taskID: String
    @State private var answer = ""
    @State private var writing = false
    @State private var grading = false
    @State private var issue: String?
    @State private var shownAttempt: String?
    @State private var loaded = false
    @FocusState private var editorFocused: Bool
    // 手写作答（iPad + Apple Pencil）
    @AppStorage("study2027.essay.handwriting") private var handwriting = false
    @State private var penTool: PencilTool = .pen
    @State private var clearInk = 0
    @State private var latestInk: PKDrawing?
    @State private var reading = false
    @State private var readNote: String?
    private var isPad: Bool { UIDevice.current.userInterfaceIdiom == .pad }
    private var inkKey: String { "essay-\(taskID)" }

    var body: some View {
        if let task = learning.essay(taskID) {
            InkPage(spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    Text("\(task.kind.title) · 满分 \(task.fullScore) · \(task.scope)").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                    if let note = task.note { Text("注：\(note)").font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.xs) }
                    Text(task.prompt).font(TypeScale.serif(17, relativeTo: .body)).foregroundStyle(Ink.ink).lineSpacing(8)
                        .textSelection(.enabled).padding(.top, Space.m).accessibilityIdentifier("essay-prompt")

                    if writing || task.attempts.isEmpty {
                        editor(task)
                    } else {
                        Button(task.attempts.isEmpty ? "开始作答" : "重写一遍") { answer = task.draft ?? ""; writing = true }
                            .buttonStyle(.inkGlass).padding(.top, Space.xl).accessibilityIdentifier("essay-rewrite")
                    }

                    if let attempt = task.attempts.first(where: { $0.id == shownAttempt }) ?? task.latest {
                        EssayResultView(attempt: attempt, kind: task.kind, fullScore: task.fullScore, previous: previous(of: attempt, in: task)).padding(.top, Space.section)
                    }
                    if task.attempts.count > 1 {
                        InkSectionHeader(title: "历次得分").padding(.top, Space.section).padding(.bottom, Space.xs)
                        ForEach(task.attempts.reversed()) { a in
                            Button { shownAttempt = a.id } label: {
                                InkRow(title: a.date.formatted(.dateTime.month().day().hour().minute()), detail: String(a.summary.prefix(40)),
                                       value: "\(EssayPractice.formatScore(a.score)) / \(task.fullScore)", valueIsSeal: a.id == (shownAttempt ?? task.latest?.id))
                            }.buttonStyle(.plain)
                        }
                    }
                }
            }
            .navigationTitle(task.title).navigationBarTitleDisplayMode(.inline)
            .onAppear {
                guard !loaded else { return }
                loaded = true; answer = task.draft ?? ""
            }
            .onDisappear { if writing || task.attempts.isEmpty { learning.saveEssayDraft(taskID, text: answer) } }
            .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("收起") { editorFocused = false } } }
        } else {
            ContentUnavailableView("这道题已删除", systemImage: "trash")
        }
    }

    @ViewBuilder private func editor(_ task: EssayTask) -> some View {
        InkSectionHeader(title: "你的答案", trailing: handwriting && isPad ? nil : countText(task)).padding(.top, Space.xl).padding(.bottom, Space.s)
        if isPad {
            Picker("作答方式", selection: $handwriting) {
                Text("打字").tag(false)
                Text("手写").tag(true)
            }.pickerStyle(.segmented).frame(maxWidth: 260).padding(.bottom, Space.m).accessibilityIdentifier("essay-input-mode")
        }
        if handwriting && isPad { handwritingArea(task) } else { typedArea(task) }
    }

    /// 用 Apple Pencil 在横线纸上写；写完识别成文字，检查后再提交
    @ViewBuilder private func handwritingArea(_ task: EssayTask) -> some View {
        PencilToolbar(tool: $penTool, clear: { clearInk += 1; latestInk = nil })
        Text("用 Apple Pencil 像考场一样手写，手指可以照常滚动页面。")
            .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s).padding(.bottom, Space.s)
        ZStack {
            GridPaper(spacing: 46, linesOnly: true)
            PencilCanvas(key: inkKey, tool: penTool, clearToken: clearInk) { latestInk = $0 }
        }
        .frame(height: task.fullScore >= 20 ? 900 : 620)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Ink.line, lineWidth: 0.5))
        .accessibilityIdentifier("essay-handwriting")
        HStack(spacing: Space.m) {
            Button {
                reading = true; readNote = nil
                Task {
                    defer { reading = false }
                    do {
                        let text = try await HandwritingReader.recognize(latestInk ?? learning.drawing(inkKey))
                        guard !text.isEmpty else { readNote = "没认出字，写清楚一点再试。"; return }
                        answer = text
                        learning.saveEssayDraft(taskID, text: answer)
                        handwriting = false
                        readNote = "识别好了，先检查一遍错字，再提交批改。手写笔迹还保留着。"
                    } catch { readNote = error.localizedDescription }
                }
            } label: {
                HStack(spacing: Space.s) {
                    if reading { ProgressView().controlSize(.small) }
                    Text(reading ? "正在识别…" : "识别文字")
                }
            }.buttonStyle(.inkPrimary).disabled(reading).accessibilityIdentifier("essay-recognize")
            Text("识别在本机完成，不上传笔迹。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
        }.padding(.top, Space.l)
        if let readNote { Text(readNote).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
    }

    @ViewBuilder private func typedArea(_ task: EssayTask) -> some View {
        if let readNote { Text(readNote).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.bottom, Space.s) }
        TextEditor(text: $answer)
            .font(TypeScale.serif(16, relativeTo: .body)).lineSpacing(6)
            .scrollContentBackground(.hidden).frame(minHeight: 260)
            .padding(Space.m).background(Ink.line.opacity(0.35), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .focused($editorFocused).accessibilityIdentifier("essay-answer")
        Text(task.kind.isEnglish ? "按考场写法写，写完再提交。" : "先列要点再展开，写得像考场答卷。草稿会自动保存。")
            .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s)
        HStack(spacing: Space.m) {
            Button {
                editorFocused = false; grading = true; issue = nil
                learning.saveEssayDraft(taskID, text: answer)
                Task {
                    defer { grading = false }
                    do { let a = try await learning.gradeEssay(taskID, answer: answer, chat: chat); shownAttempt = a.id; writing = false }
                    catch { issue = error.localizedDescription }
                }
            } label: {
                HStack(spacing: Space.s) {
                    if grading { ProgressView().controlSize(.small) }
                    Text(grading ? "正在批改…" : "提交批改")
                }
            }.buttonStyle(.inkPrimary).disabled(grading || answer.trimmingCharacters(in: .whitespacesAndNewlines).count < 20 || !(chat.canUseAI || chat.isPreview))
            .accessibilityIdentifier("essay-submit")
            if writing { Button("取消") { learning.saveEssayDraft(taskID, text: answer); writing = false }.buttonStyle(.inkGlass) }
        }.padding(.top, Space.l)
        if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
    }

    private func countText(_ task: EssayTask) -> String {
        if task.kind.isEnglish { return "\(answer.split { $0.isWhitespace || $0.isNewline }.count) 词" }
        return "\(answer.filter { !$0.isWhitespace }.count) 字"
    }
    private func previous(of attempt: EssayAttempt, in task: EssayTask) -> EssayAttempt? {
        guard let i = task.attempts.firstIndex(where: { $0.id == attempt.id }), i > 0 else { return nil }
        return task.attempts[i - 1]
    }
}

/// 批改结果：分数、逐个得分点、总评、改进、改句、记入记忆的薄弱点
struct EssayResultView: View {
    let attempt: EssayAttempt
    let kind: EssayKind
    var fullScore: Int? = nil
    var previous: EssayAttempt?
    @State private var showAnswer = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline, spacing: Space.s) {
                Text(EssayPractice.formatScore(attempt.score)).font(TypeScale.serif(34, relativeTo: .title)).foregroundStyle(Ink.seal)
                    .accessibilityIdentifier("essay-score")
                Text("/ \(fullScore ?? kind.fullScore)").font(TypeScale.label).foregroundStyle(Ink.ink3)
                if let previous {
                    let diff = attempt.score - previous.score
                    Text(diff == 0 ? "和上次一样" : (diff > 0 ? "比上次 +" : "比上次 ") + EssayPractice.formatScore(diff))
                        .font(TypeScale.caption).foregroundStyle(diff > 0 ? Ink.seal : Ink.ink3)
                }
                Spacer()
                Text(attempt.date.formatted(.dateTime.month().day().hour().minute())).font(TypeScale.caption).foregroundStyle(Ink.ink3)
            }
            if !attempt.summary.isEmpty {
                Text(attempt.summary).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).padding(.top, Space.s)
            }
            if !attempt.points.isEmpty {
                InkSectionHeader(title: kind.isEnglish ? "分项" : "得分点").padding(.top, Space.xl).padding(.bottom, Space.xs)
                ForEach(Array(attempt.points.enumerated()), id: \.offset) { _, p in
                    HStack(alignment: .firstTextBaseline, spacing: Space.m) {
                        Image(systemName: p.hit == .full ? "circle.fill" : p.hit == .partial ? "circle.lefthalf.filled" : "circle")
                            .font(.system(size: 11)).foregroundStyle(p.hit == .miss ? Ink.seal : Ink.ink)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(p.point).font(TypeScale.serif(15)).foregroundStyle(Ink.ink)
                            if !p.comment.isEmpty { Text(p.comment).font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                        }
                    }.padding(.vertical, 8)
                    InkRule()
                }
                Text("● 答到　◐ 部分答到　○ 没答").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s)
            }
            if !attempt.improvements.isEmpty {
                InkSectionHeader(title: "怎么改").padding(.top, Space.xl).padding(.bottom, Space.xs)
                ForEach(Array(attempt.improvements.enumerated()), id: \.offset) { i, text in
                    Text("\(i + 1). \(text)").font(TypeScale.serif(15)).foregroundStyle(Ink.ink2).lineSpacing(5).padding(.vertical, 4)
                }
            }
            if !attempt.corrections.isEmpty {
                InkSectionHeader(title: "改句").padding(.top, Space.xl).padding(.bottom, Space.xs)
                ForEach(Array(attempt.corrections.enumerated()), id: \.offset) { _, c in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(c.original).font(TypeScale.serif(15)).strikethrough().foregroundStyle(Ink.ink3)
                        Text(c.better).font(TypeScale.serif(15)).foregroundStyle(Ink.ink)
                        if !c.reason.isEmpty { Text(c.reason).font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                    }.textSelection(.enabled).padding(.vertical, 8)
                    InkRule()
                }
            }
            if !attempt.weakPoints.isEmpty {
                Text("已记入薄弱点：" + attempt.weakPoints.joined(separator: "；")).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    .lineSpacing(3).padding(.top, Space.l)
            }
            Button(showAnswer ? "收起这次的答案" : "看这次的答案") { showAnswer.toggle() }
                .font(TypeScale.label).foregroundStyle(Ink.ink3).padding(.top, Space.l)
            if showAnswer {
                Text(attempt.text).font(TypeScale.serif(15)).foregroundStyle(Ink.ink2).lineSpacing(6).textSelection(.enabled).padding(.top, Space.s)
            }
            Text(EssayPractice.source).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
        }
    }
}

/// 录入一道题：题型、标题、题目全文、出处
struct CustomEssaySheet: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    let subject: StudySubject
    let onCreate: (EssayTask) -> Void
    @State private var kind: EssayKind
    @State private var title = ""
    @State private var prompt = ""
    @State private var source = ""
    init(subject: StudySubject, onCreate: @escaping (EssayTask) -> Void) {
        self.subject = subject; self.onCreate = onCreate
        _kind = State(initialValue: EssayKind.kinds(for: subject).first ?? .historyEssay)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("题型") {
                    Picker("题型", selection: $kind) { ForEach(EssayKind.kinds(for: subject), id: \.self) { Text("\($0.title)（满分 \($0.fullScore)）").tag($0) } }
                        .pickerStyle(.inline).labelsHidden()
                }
                Section {
                    TextEditor(text: $prompt).frame(minHeight: 180).accessibilityIdentifier("custom-essay-prompt")
                } header: { Text("题目全文") } footer: { Text("材料题把材料和设问都放进来。可以从电子版复制粘贴，也可以对着书打字。") }
                Section("标题和出处（可不填）") {
                    TextField("标题，比如：汉罗帝国比较", text: $title)
                    TextField("出处，比如：2023 年 313 真题", text: $source)
                }
            }
            .navigationTitle("录入一道题").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("开始作答") {
                        if let task = learning.addCustomEssay(kind: kind, title: title, prompt: prompt, source: source) { dismiss(); onCreate(task) }
                    }.disabled(prompt.trimmingCharacters(in: .whitespacesAndNewlines).count < 8)
                }
            }
        }
    }
}

/// 历年真题：按年份分组，显示每道做没做、最好成绩
struct RealEssayListView: View {
    @EnvironmentObject private var learning: LearningStore
    let subject: StudySubject
    var body: some View {
        let reals = learning.essayTasks.filter { $0.isReal && $0.kind.subject == subject }
        let years = Array(Set(reals.compactMap(\.year))).sorted(by: >)
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text("历年真题").font(TypeScale.serif(29, relativeTo: .title)).padding(.top, Space.xl)
                Text("据网络整理，以原卷为准。早年的简答题每题 30 分，论述题 40 分，材料题 30 分。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.xs).padding(.bottom, Space.l)
                ForEach(years, id: \.self) { year in
                    InkSectionHeader(title: "\(year) 年").padding(.top, Space.xl).padding(.bottom, Space.xs)
                    ForEach(reals.filter { $0.year == year }.sorted { ($0.kind == .historyMaterial ? 0 : 1, $0.id) < ($1.kind == .historyMaterial ? 0 : 1, $1.id) }) { task in
                        NavigationLink { EssayTaskView(taskID: task.id) } label: {
                            InkRow(title: task.title, detail: task.kind.title + (task.note == nil ? "" : " · " + task.note!),
                                   value: task.best.map { "\(EssayPractice.formatScore($0.score)) / \(task.fullScore)" } ?? "满分 \(task.fullScore)",
                                   valueIsSeal: task.best != nil, chevron: true)
                        }.buttonStyle(.plain)
                    }
                }
            }
        }
        .navigationTitle("历年真题").navigationBarTitleDisplayMode(.inline)
    }
}
