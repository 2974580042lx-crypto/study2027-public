import SwiftUI

/// 大题：按科目出题、看历史作答，313 另有专题入口
@MainActor
struct EssayHubView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    @State private var subject: StudySubject = .history
    @State private var generating = false
    @State private var issue: String?
    @State private var opened: EssayRef?

    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text("大题").font(TypeScale.serif(29, relativeTo: .title)).padding(.top, Space.xl)
                Text("先自己写，再看得分点。漏掉的点会记进「记忆」，之后出题和汇总都会照顾到。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.xs).padding(.bottom, Space.l)
                InkTabs(items: [(StudySubject.history, "313 历史学"), (.politics, "政治"), (.english, "英语一")], selection: $subject)

                InkSectionHeader(title: "出一道新题").padding(.top, Space.xl).padding(.bottom, Space.s)
                ForEach(EssayKind.kinds(for: subject), id: \.self) { kind in
                    Button { generate(kind) } label: {
                        InkRow(title: kind.title, detail: detail(kind), value: "满分 \(kind.fullScore)", chevron: true)
                    }.buttonStyle(.plain).disabled(generating || !aiReady).accessibilityIdentifier("essay-new-\(kind.rawValue)")
                }
                if generating { HStack(spacing: Space.s) { ProgressView().controlSize(.small); Text("正在出题…") }.font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s) }
                if !aiReady { Text("先在设置里连上 AI 才能出题和批改。").font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
                if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }

                if subject == .history {
                    InkSectionHeader(title: "专题", trailing: "\(HistoryTopics.all.count) 个").padding(.top, Space.section).padding(.bottom, Space.s)
                    Text("统考论述题常考贯通性的题目。专题把几个章节串成一条线，可以先看框架再出题。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.bottom, Space.s)
                    ForEach(HistoryTopics.all) { topic in
                        NavigationLink { HistoryTopicView(topicID: topic.id) } label: {
                            InkRow(title: topic.title, detail: topic.block + (learning.topicOutline(topic.id) == nil ? "" : " · 已有框架"),
                                   value: topicScore(topic.id), chevron: true)
                        }.buttonStyle(.plain).accessibilityIdentifier("topic-\(topic.id)")
                    }
                }

                let tasks = learning.essayTasks.filter { $0.kind.subject == subject }.reversed()
                InkSectionHeader(title: tasks.isEmpty ? "还没有做过" : "做过的题").padding(.top, Space.section).padding(.bottom, Space.s)
                ForEach(Array(tasks)) { task in
                    NavigationLink { EssayTaskView(taskID: task.id) } label: {
                        InkRow(title: task.title, detail: "\(task.kind.title) · \(task.scope)", value: scoreText(task), valueIsSeal: task.attempts.isEmpty, chevron: true)
                    }.buttonStyle(.plain)
                    .contextMenu { Button("删除", role: .destructive) { learning.deleteEssay(task.id) } }
                }
            }
        }
        .navigationTitle("大题").navigationBarTitleDisplayMode(.inline)
        .navigationDestination(item: $opened) { EssayTaskView(taskID: $0.id) }
        .accessibilityIdentifier("essay-hub")
    }

    private var aiReady: Bool { chat.canUseAI || chat.isPreview }
    private func detail(_ kind: EssayKind) -> String {
        switch kind {
        case .historyEssay: "按整个 313 出，想按章节或专题出，到考纲或下面的专题里"
        case .historyMaterial: "材料 + 2—3 问"
        case .politicsAnalysis: "材料 + 1—2 问，考原理运用"
        case .englishLarge: "图画 / 图表作文，160—200 词"
        case .englishSmall: "书信、通知等应用文，约 100 词"
        }
    }
    private func scoreText(_ task: EssayTask) -> String {
        guard let best = task.best else { return "未作答" }
        return "\(EssayPractice.formatScore(best.score)) / \(task.kind.fullScore)"
    }
    private func topicScore(_ id: String) -> String? {
        let done = learning.essayTasks.filter { $0.topicID == id && !$0.attempts.isEmpty }
        return done.isEmpty ? nil : "做过 \(done.count) 题"
    }
    private func generate(_ kind: EssayKind) {
        generating = true; issue = nil
        Task {
            defer { generating = false }
            do { opened = EssayRef(id: try await learning.generateEssay(kind: kind, nodeID: nil, topicID: nil, chat: chat).id) }
            catch { issue = error.localizedDescription }
        }
    }
}

struct EssayRef: Identifiable, Hashable { let id: String }

/// 专题页：主线提示、相关章节和词条、AI 答题框架、按专题出题
@MainActor
struct HistoryTopicView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let topicID: String
    @State private var working: String?
    @State private var issue: String?
    @State private var opened: EssayRef?

    var body: some View {
        if let topic = HistoryTopics.topic(topicID) {
            InkPage(spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    Text(topic.block).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                    Text(topic.title).font(TypeScale.serif(26, relativeTo: .title)).padding(.top, Space.xs)
                    Text(topic.focus).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).padding(.top, Space.m)

                    InkSectionHeader(title: "答题框架").padding(.top, Space.section).padding(.bottom, Space.s)
                    if let outline = learning.topicOutline(topicID) {
                        Text(outline).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineSpacing(7).textSelection(.enabled)
                            .accessibilityIdentifier("topic-outline")
                    } else {
                        Text("先自己在纸上列一遍主线，再让 AI 给一份对照，效果更好。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    }
                    HStack(spacing: Space.m) {
                        action(learning.topicOutline(topicID) == nil ? "✦ 生成框架" : "重新生成", key: "outline") {
                            try await learning.generateTopicOutline(topicID, chat: chat)
                        }
                        action("出论述题", key: "essay") {
                            opened = EssayRef(id: try await learning.generateEssay(kind: .historyEssay, nodeID: nil, topicID: topicID, chat: chat).id)
                        }.accessibilityIdentifier("topic-new-essay")
                        action("出材料题", key: "material") {
                            opened = EssayRef(id: try await learning.generateEssay(kind: .historyMaterial, nodeID: nil, topicID: topicID, chat: chat).id)
                        }
                    }.padding(.top, Space.l)
                    if let working { Text(working == "outline" ? "正在整理框架…" : "正在出题…").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s) }
                    if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }

                    let done = learning.essayTasks.filter { $0.topicID == topicID }
                    if !done.isEmpty {
                        InkSectionHeader(title: "这个专题做过的题").padding(.top, Space.section).padding(.bottom, Space.s)
                        ForEach(done) { task in
                            NavigationLink { EssayTaskView(taskID: task.id) } label: {
                                InkRow(title: task.title, detail: task.kind.title,
                                       value: task.best.map { "\(EssayPractice.formatScore($0.score)) / \(task.kind.fullScore)" } ?? "未作答", chevron: true)
                            }.buttonStyle(.plain)
                        }
                    }

                    InkSectionHeader(title: "涉及的章节").padding(.top, Space.section).padding(.bottom, Space.s)
                    Text(topic.nodeIDs.compactMap { id in learning.syllabusNodes.first { $0.id == id }.map { "\($0.block) · \($0.title)" } }.joined(separator: "\n"))
                        .font(TypeScale.label).foregroundStyle(Ink.ink2).lineSpacing(5)
                    InkSectionHeader(title: "相关条目").padding(.top, Space.section).padding(.bottom, Space.xs)
                    ForEach(topic.entries(in: HistoryDictionary.bundled).sorted { ($0.year ?? .max) < ($1.year ?? .max) }) {
                        HistoryEntryRow(entry: $0, showYear: true)
                    }
                }
            }
            .navigationTitle("专题").navigationBarTitleDisplayMode(.inline)
            .navigationDestination(item: $opened) { EssayTaskView(taskID: $0.id) }
        } else {
            ContentUnavailableView("找不到这个专题", systemImage: "questionmark")
        }
    }

    private func action(_ title: String, key: String, run: @escaping () async throws -> Void) -> some View {
        Button(title) {
            working = key; issue = nil
            Task {
                defer { working = nil }
                do { try await run() } catch { issue = error.localizedDescription }
            }
        }.buttonStyle(.inkGlass).disabled(working != nil || !(chat.canUseAI || chat.isPreview))
    }
}

/// 一道大题：题目、作答（自动存草稿）、批改结果、历次得分
@MainActor
struct EssayTaskView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let taskID: String
    @State private var answer = ""
    @State private var writing = false
    @State private var grading = false
    @State private var issue: String?
    @State private var shownAttempt: String?
    @State private var loaded = false
    @FocusState private var editorFocused: Bool

    var body: some View {
        if let task = learning.essay(taskID) {
            InkPage(spacing: 0) {
                VStack(alignment: .leading, spacing: 0) {
                    Text("\(task.kind.title) · 满分 \(task.kind.fullScore) · \(task.scope)").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                    Text(task.prompt).font(TypeScale.serif(17, relativeTo: .body)).foregroundStyle(Ink.ink).lineSpacing(8)
                        .textSelection(.enabled).padding(.top, Space.m).accessibilityIdentifier("essay-prompt")

                    if writing || task.attempts.isEmpty {
                        editor(task)
                    } else {
                        Button(task.attempts.isEmpty ? "开始作答" : "重写一遍") { answer = task.draft ?? ""; writing = true }
                            .buttonStyle(.inkGlass).padding(.top, Space.xl).accessibilityIdentifier("essay-rewrite")
                    }

                    if let attempt = task.attempts.first(where: { $0.id == shownAttempt }) ?? task.latest {
                        EssayResultView(attempt: attempt, kind: task.kind, previous: previous(of: attempt, in: task)).padding(.top, Space.section)
                    }
                    if task.attempts.count > 1 {
                        InkSectionHeader(title: "历次得分").padding(.top, Space.section).padding(.bottom, Space.xs)
                        ForEach(task.attempts.reversed()) { a in
                            Button { shownAttempt = a.id } label: {
                                InkRow(title: a.date.formatted(.dateTime.month().day().hour().minute()), detail: String(a.summary.prefix(40)),
                                       value: "\(EssayPractice.formatScore(a.score)) / \(task.kind.fullScore)", valueIsSeal: a.id == (shownAttempt ?? task.latest?.id))
                            }.buttonStyle(.plain)
                        }
                    }
                }
            }
            .navigationTitle(task.title).navigationBarTitleDisplayMode(.inline)
            .onAppear {
                guard !loaded else { return }
                loaded = true; answer = task.draft ?? ""
            }
            .onDisappear { if writing || task.attempts.isEmpty { learning.saveEssayDraft(taskID, text: answer) } }
            .toolbar { ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("收起") { editorFocused = false } } }
        } else {
            ContentUnavailableView("这道题已删除", systemImage: "trash")
        }
    }

    @ViewBuilder private func editor(_ task: EssayTask) -> some View {
        InkSectionHeader(title: "你的答案", trailing: countText(task)).padding(.top, Space.xl).padding(.bottom, Space.s)
        TextEditor(text: $answer)
            .font(TypeScale.serif(16, relativeTo: .body)).lineSpacing(6)
            .scrollContentBackground(.hidden).frame(minHeight: 260)
            .padding(Space.m).background(Ink.line.opacity(0.35), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .focused($editorFocused).accessibilityIdentifier("essay-answer")
        Text(task.kind.isEnglish ? "按考场写法写，写完再提交。" : "先列要点再展开，写得像考场答卷。草稿会自动保存。")
            .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s)
        HStack(spacing: Space.m) {
            Button {
                editorFocused = false; grading = true; issue = nil
                learning.saveEssayDraft(taskID, text: answer)
                Task {
                    defer { grading = false }
                    do { let a = try await learning.gradeEssay(taskID, answer: answer, chat: chat); shownAttempt = a.id; writing = false }
                    catch { issue = error.localizedDescription }
                }
            } label: {
                HStack(spacing: Space.s) {
                    if grading { ProgressView().controlSize(.small) }
                    Text(grading ? "正在批改…" : "提交批改")
                }
            }.buttonStyle(.inkPrimary).disabled(grading || answer.trimmingCharacters(in: .whitespacesAndNewlines).count < 20 || !(chat.canUseAI || chat.isPreview))
            .accessibilityIdentifier("essay-submit")
            if writing { Button("取消") { learning.saveEssayDraft(taskID, text: answer); writing = false }.buttonStyle(.inkGlass) }
        }.padding(.top, Space.l)
        if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
    }

    private func countText(_ task: EssayTask) -> String {
        if task.kind.isEnglish { return "\(answer.split { $0.isWhitespace || $0.isNewline }.count) 词" }
        return "\(answer.filter { !$0.isWhitespace }.count) 字"
    }
    private func previous(of attempt: EssayAttempt, in task: EssayTask) -> EssayAttempt? {
        guard let i = task.attempts.firstIndex(where: { $0.id == attempt.id }), i > 0 else { return nil }
        return task.attempts[i - 1]
    }
}

/// 批改结果：分数、逐个得分点、总评、改进、改句、记入记忆的薄弱点
struct EssayResultView: View {
    let attempt: EssayAttempt
    let kind: EssayKind
    var previous: EssayAttempt?
    @State private var showAnswer = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .firstTextBaseline, spacing: Space.s) {
                Text(EssayPractice.formatScore(attempt.score)).font(TypeScale.serif(34, relativeTo: .title)).foregroundStyle(Ink.seal)
                    .accessibilityIdentifier("essay-score")
                Text("/ \(kind.fullScore)").font(TypeScale.label).foregroundStyle(Ink.ink3)
                if let previous {
                    let diff = attempt.score - previous.score
                    Text(diff == 0 ? "和上次一样" : (diff > 0 ? "比上次 +" : "比上次 ") + EssayPractice.formatScore(diff))
                        .font(TypeScale.caption).foregroundStyle(diff > 0 ? Ink.seal : Ink.ink3)
                }
                Spacer()
                Text(attempt.date.formatted(.dateTime.month().day().hour().minute())).font(TypeScale.caption).foregroundStyle(Ink.ink3)
            }
            if !attempt.summary.isEmpty {
                Text(attempt.summary).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).padding(.top, Space.s)
            }
            if !attempt.points.isEmpty {
                InkSectionHeader(title: kind.isEnglish ? "分项" : "得分点").padding(.top, Space.xl).padding(.bottom, Space.xs)
                ForEach(Array(attempt.points.enumerated()), id: \.offset) { _, p in
                    HStack(alignment: .firstTextBaseline, spacing: Space.m) {
                        Image(systemName: p.hit == .full ? "circle.fill" : p.hit == .partial ? "circle.lefthalf.filled" : "circle")
                            .font(.system(size: 11)).foregroundStyle(p.hit == .miss ? Ink.seal : Ink.ink)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(p.point).font(TypeScale.serif(15)).foregroundStyle(Ink.ink)
                            if !p.comment.isEmpty { Text(p.comment).font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                        }
                    }.padding(.vertical, 8)
                    InkRule()
                }
                Text("● 答到　◐ 部分答到　○ 没答").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s)
            }
            if !attempt.improvements.isEmpty {
                InkSectionHeader(title: "怎么改").padding(.top, Space.xl).padding(.bottom, Space.xs)
                ForEach(Array(attempt.improvements.enumerated()), id: \.offset) { i, text in
                    Text("\(i + 1). \(text)").font(TypeScale.serif(15)).foregroundStyle(Ink.ink2).lineSpacing(5).padding(.vertical, 4)
                }
            }
            if !attempt.corrections.isEmpty {
                InkSectionHeader(title: "改句").padding(.top, Space.xl).padding(.bottom, Space.xs)
                ForEach(Array(attempt.corrections.enumerated()), id: \.offset) { _, c in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(c.original).font(TypeScale.serif(15)).strikethrough().foregroundStyle(Ink.ink3)
                        Text(c.better).font(TypeScale.serif(15)).foregroundStyle(Ink.ink)
                        if !c.reason.isEmpty { Text(c.reason).font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                    }.textSelection(.enabled).padding(.vertical, 8)
                    InkRule()
                }
            }
            if !attempt.weakPoints.isEmpty {
                Text("已记入薄弱点：" + attempt.weakPoints.joined(separator: "；")).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    .lineSpacing(3).padding(.top, Space.l)
            }
            Button(showAnswer ? "收起这次的答案" : "看这次的答案") { showAnswer.toggle() }
                .font(TypeScale.label).foregroundStyle(Ink.ink3).padding(.top, Space.l)
            if showAnswer {
                Text(attempt.text).font(TypeScale.serif(15)).foregroundStyle(Ink.ink2).lineSpacing(6).textSelection(.enabled).padding(.top, Space.s)
            }
            Text(EssayPractice.source).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
        }
    }
}
