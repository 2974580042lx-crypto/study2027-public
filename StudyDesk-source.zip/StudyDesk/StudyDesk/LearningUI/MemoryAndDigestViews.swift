import SwiftUI

/// 记忆页：AI 长期记得的、和备考有关的事。看得见、改得了、删得掉。
@MainActor
struct MemoryView: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var editing: MemoryItem?
    private var useMemory: Binding<Bool> {
        Binding(get: { learning.state.memoryEnabled != false }, set: { learning.state.memoryEnabled = $0; learning.save() })
    }
    private var autoDigest: Binding<Bool> {
        Binding(get: { learning.autoDigestEnabled }, set: { learning.setAutoDigest($0) })
    }

    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text("记忆").font(TypeScale.pageTitle).foregroundStyle(Ink.ink).padding(.top, Space.l)
                Text("研习会记住和你备考有关的事，回答问题和汇总时参考。只存在这台手机上，随学习备份一起导出，可以随时修改或删除。")
                    .font(TypeScale.label).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.s)
                VStack(spacing: 0) {
                    Toggle(isOn: useMemory) { Text("让 AI 参考记忆").font(TypeScale.serif(16)) }
                        .padding(.vertical, 10).accessibilityIdentifier("memory-toggle-use")
                    InkRule()
                    Toggle(isOn: autoDigest) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("每天自动汇总前一天").font(TypeScale.serif(16))
                            Text("第一次打开时在后台整理，更新考纲和记忆").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                        }
                    }.padding(.vertical, 10).accessibilityIdentifier("memory-toggle-auto")
                    InkRule()
                }.tint(Ink.ink).padding(.top, Space.l)

                let items = learning.memoryItems
                if items.isEmpty {
                    Text("还没有记忆。每天汇总时 AI 会把值得长期记住的事放在这里，你也可以自己加一条。")
                        .font(TypeScale.label).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.section)
                }
                ForEach(MemoryCategory.allCases, id: \.self) { category in
                    let group = items.filter { $0.category == category }.sorted { ($0.pinned ? 0 : 1, $1.updatedAt) < ($1.pinned ? 0 : 1, $0.updatedAt) }
                    if !group.isEmpty {
                        InkSectionHeader(title: category.title).padding(.top, Space.section)
                        ForEach(group) { item in
                            Button { editing = item } label: {
                                VStack(alignment: .leading, spacing: 4) {
                                    HStack(alignment: .firstTextBaseline) {
                                        Text(item.text).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).multilineTextAlignment(.leading)
                                        Spacer(minLength: Space.s)
                                        if item.pinned { Text("置顶").font(TypeScale.tiny).foregroundStyle(Ink.seal) }
                                    }
                                    Text(item.source).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                                }.padding(.vertical, 11).frame(maxWidth: .infinity, alignment: .leading).contentShape(Rectangle())
                            }.buttonStyle(.plain).accessibilityIdentifier("memory-item-\(item.id)")
                            InkRule()
                        }
                    }
                }
                Button("添加一条") { editing = MemoryItem(text: "", category: .weakPoints, source: "你写的") }
                    .buttonStyle(.inkGlass).padding(.top, Space.xl).accessibilityIdentifier("memory-add")
            }
        }
        .navigationTitle("记忆").navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("memory-page")
        .sheet(item: $editing) { MemoryEditSheet(item: $0) }
    }
}

@MainActor
struct MemoryEditSheet: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State var item: MemoryItem
    private var isNew: Bool { !learning.memoryItems.contains { $0.id == item.id } }
    var body: some View {
        NavigationStack {
            Form {
                TextField("比如：秦汉郡国并行的原因容易忘", text: $item.text, axis: .vertical).font(TypeScale.serif(17)).lineLimit(2...6)
                Picker("分类", selection: $item.category) {
                    ForEach(MemoryCategory.allCases, id: \.self) { Text($0.title).tag($0) }
                }
                Toggle("置顶", isOn: $item.pinned).tint(Ink.ink)
                if !isNew {
                    Text("来源：\(item.source)").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    Button("删除这条", role: .destructive) { learning.deleteMemory(item.id); dismiss() }
                }
            }
            .scrollContentBackground(.hidden).background(AppBackground())
            .navigationTitle(isNew ? "添加记忆" : "修改记忆").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { learning.saveMemory(item); dismiss() }
                        .disabled(item.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
}

/// 某一天的汇总：总结、考纲变化（可改）、卡住的地方、明天可以先做的事。
@MainActor
struct DigestSheet: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    let digestID: String
    private var digest: DailyDigest? { learning.digestList.first { $0.id == digestID } }

    var body: some View {
        NavigationStack {
            InkPage(spacing: 0) {
                if let d = digest {
                    VStack(alignment: .leading, spacing: 0) {
                        Text(d.day.formatted(.dateTime.month().day().weekday())).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                        Text(d.summary).font(TypeScale.serif(18)).foregroundStyle(Ink.ink).lineSpacing(6).padding(.top, Space.m)
                        if !d.changes.isEmpty {
                            InkSectionHeader(title: "考纲进度　AI 估的，点一下就能改").padding(.top, Space.section)
                            ForEach(d.changes.keys.sorted(), id: \.self) { id in
                                if let node = learning.syllabusNodes.first(where: { $0.id == id }) { masteryRow(node) }
                            }
                        }
                        if !d.weakPoints.isEmpty {
                            InkSectionHeader(title: "卡住的地方").padding(.top, Space.section)
                            ForEach(d.weakPoints, id: \.self) { line(text: $0) }
                        }
                        if !d.tomorrow.isEmpty {
                            InkSectionHeader(title: "明天可以先做").padding(.top, Space.section)
                            ForEach(d.tomorrow, id: \.self) { line(text: $0) }
                            Text("只是建议。明天学了什么，照样记下来就行。").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s)
                        }
                    }
                }
            }
            .navigationTitle("汇总").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
            .onAppear { learning.markDigestSeen(digestID) }
        }
        .accessibilityIdentifier("ai-summary-sheet")
    }

    private func line(text: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: Space.s) {
            Text("·").foregroundStyle(Ink.ink3)
            Text(text).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineSpacing(4)
        }.padding(.vertical, 6)
    }

    private func masteryRow(_ node: SyllabusNode) -> some View {
        VStack(spacing: 0) {
            HStack(spacing: Space.m) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(node.title).font(TypeScale.serif(16)).foregroundStyle(Ink.ink)
                    Text("\(node.subject.title) · \(node.block)").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
                Spacer()
                Menu {
                    ForEach((0...4).reversed(), id: \.self) { level in
                        Button { learning.setMastery(nodeID: node.id, level: level) } label: {
                            if node.mastery == level { Label(Mastery.title(level), systemImage: "checkmark") } else { Text(Mastery.title(level)) }
                        }
                    }
                } label: {
                    HStack(spacing: 6) {
                        HStack(spacing: 3) { ForEach(1...4, id: \.self) { i in Circle().fill(i <= node.mastery ? Ink.ink : Ink.line).frame(width: 7, height: 7) } }
                        Text(Mastery.title(node.mastery)).font(TypeScale.serif(14))
                        Image(systemName: "chevron.up.chevron.down").font(.system(size: 10))
                    }.foregroundStyle(Ink.ink2)
                }.accessibilityIdentifier("summary-mastery-\(node.id)")
            }.padding(.vertical, 11)
            InkRule()
        }
    }
}
