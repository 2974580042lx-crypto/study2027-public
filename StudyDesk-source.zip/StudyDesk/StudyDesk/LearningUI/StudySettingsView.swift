import SwiftUI
import UniformTypeIdentifiers

@MainActor
struct StudySettingsView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State private var preferences = StudyPreferences()
    @State private var aiSettings = false
    @State private var importing = false
    @State private var confirmRestore = false
    @State private var pendingRestore: URL?
    @State private var shareURL: URL?
    @State private var sharing = false
    @State private var memory = ""
    @State private var memoryEnabled = true
    @State private var licenses = false
    private var appVersion: String {
        if let value = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String { return value }
        return "1.3.0"
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    NavigationLink { AppGuideView() } label: { Label("使用说明", systemImage: "book") }
                        .accessibilityIdentifier("app-guide-link")
                } footer: { Text("想知道某个功能怎么用，也可以直接问 AI。") }
                Section("目标") {
                    DatePicker("考试日期", selection: $preferences.examDate, displayedComponents: .date)
                    InkStepper(title: "每天学习", value: $preferences.dailyMinutes, range: 15...900, step: 15) { value in
                        value % 60 == 0 ? "\(value / 60) 小时" : value > 60 ? "\(value / 60) 小时 \(value % 60) 分" : "\(value) 分钟"
                    }
                    InkStepper(title: "每天新学", value: $preferences.dailyWords, range: 1...300) { "\($0) 个单词" }
                }.listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
                Section("专注计时") {
                    InkStepper(title: "学习", value: $preferences.focusMinutes, range: 1...180) { "\($0) 分钟" }
                    InkStepper(title: "休息", value: $preferences.restMinutes, range: 1...60) { "\($0) 分钟" }
                    Picker("默认科目", selection: $preferences.preferredSubject) { ForEach(StudySubject.allCases) { Text($0.title).tag($0) } }
                }.listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
                Section("AI 与学习记忆") {
                    Button("AI 连接、系统提示词与聊天设置") { aiSettings = true }
                    Toggle("让 AI 参考学习档案", isOn: $memoryEnabled)
                    VStack(spacing: Space.s) {
                        InkRule()
                        TextEditor(text: $memory).font(TypeScale.note).frame(minHeight: 130).scrollContentBackground(.hidden)
                        InkRule()
                    }
                    Text("档案由你编辑。开启后，提问会附带近期学习记录和仍待巩固的错题；AI 讲解自动记录到当天日志。关闭后不附加这些记忆。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    Button("清空手写档案", role: .destructive) { memory = "" }.foregroundStyle(Ink.seal)
                }.listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
                Section("学习资料备份") {
                    Button("导出学习记录与附件") { learning.updatePreferences(preferences); shareURL = learning.exportBackup(); sharing = shareURL != nil }
                    if let latest = learning.autoBackups.first {
                        Button("导出最近的自动备份") { shareURL = latest; sharing = true }
                        Text("每周自动备份一次，保留最近 4 份。最近一份：\(latest.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "研习自动备份-", with: ""))")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    } else {
                        Text("每周第一次打开时会自动备份一次，保留最近 4 份。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    }
                    Button("从备份恢复") { importing = true }.foregroundStyle(Ink.seal)
                    Text("学习备份包含词卡、题目、时间轴及导入附件。AI 对话在聊天设置中另行备份；Key 不进入备份。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
                Section("导入与来源") {
                    Button("导出题包模板") { exportTemplate() }
                    Button("导出阅读题包模板") { exportReadingTemplate() }
                    Button("开源项目与许可证") { licenses = true }
                    Text("考研基础词库来源于 ECDICT；复习排程使用 FSRS；CSV/TSV 导入使用 SwiftCSV。《红宝书 2027》按你实际使用的目录另行导入和对齐。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
                Section { Text("研习 · \(appVersion)\n手机端先行 · 独立于 Vox").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                    .listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
            }
            .scrollContentBackground(.hidden).background(AppBackground())
            .listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
            .tint(Ink.ink)
            .navigationTitle("设置").navigationBarTitleDisplayMode(.large).toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("完成") { savePreferences(); dismiss() } }
            }
        }.onAppear { preferences = learning.state.preferences; memory = learning.state.personalMemory ?? ""; memoryEnabled = learning.state.memoryEnabled != false }
            .onDisappear { savePreferences() }
            .sheet(isPresented: $aiSettings) { SettingsView() }
            .sheet(isPresented: $sharing) { if let shareURL { ShareSheet(items: [shareURL]) } }
            .sheet(isPresented: $licenses) { NavigationStack { ScrollView { Text(licenseText).font(.caption.monospaced()).textSelection(.enabled).padding() }.navigationTitle("开源说明").toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { licenses = false } } } } }
            .sheet(isPresented: $importing) {
                DocumentPicker(types: [.json]) { url in
                    importing = false; pendingRestore = url
                    Task { @MainActor in try? await Task.sleep(for: .milliseconds(400)); confirmRestore = true }
                } onCancel: { importing = false }.ignoresSafeArea()
            }
            .alert("恢复学习备份？", isPresented: $confirmRestore) {
                Button("取消", role: .cancel) { pendingRestore = nil }
                Button("恢复", role: .destructive) {
                    if let url = pendingRestore { learning.restoreBackup(url); preferences = learning.state.preferences; memory = learning.state.personalMemory ?? ""; memoryEnabled = learning.state.memoryEnabled != false }
                    pendingRestore = nil
                }
            } message: { Text("会替换当前学习记录与资料，恢复前的数据会另外保留一份本机副本。请先导出当前备份。") }
    }
    private func savePreferences() {
        learning.state.personalMemory = memory; learning.state.memoryEnabled = memoryEnabled; learning.updatePreferences(preferences)
    }
    private var licenseText: String {
        ["OPEN-SOURCE", "CEVAL-SOURCES", "CEVAL-LICENSE", "ECDICT-LICENSE", "FSRS-LICENSE", "SwiftCSV-LICENSE", "JWTKit-LICENSE", "JWTKit-BoringSSL-LICENSE", "SwiftCrypto-LICENSE", "SwiftASN1-LICENSE", "FONT-LICENSE"].compactMap { name in
            Bundle.main.url(forResource: name, withExtension: "txt").flatMap { try? String(contentsOf: $0, encoding: .utf8) }
        }.joined(separator: "\n\n────────\n\n")
    }
    private func exportTemplate() {
        do {
            let q = StudyQuestion(id: "my-question-001", subject: .history, group: "我的试卷", stem: "请替换为题干", options: ["选项 A", "选项 B", "选项 C", "选项 D"], answers: [0], explanation: "请填写核对后的解析。", source: "请填写资料名、年份及页码")
            let card = ImportedCard(front: "example", back: "n. 例子", subject: .english, deck: "我的词表", source: "个人整理", phonetic: nil)
            let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("研习-导入模板.json")
            try encoder.encode(ImportedStudyPack(cards: [card], questions: [q])).write(to: url, options: .atomic)
            shareURL = url; sharing = true
        } catch { learning.error = error.localizedDescription }
    }
    private func exportReadingTemplate() {
        do {
            guard let source = Bundle.main.url(forResource: "reading-example", withExtension: "json") else { return }
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("研习-阅读题包模板.json")
            try Data(contentsOf: source).write(to: url, options: .atomic)
            shareURL = url; sharing = true
        } catch { learning.error = error.localizedDescription }
    }
}
