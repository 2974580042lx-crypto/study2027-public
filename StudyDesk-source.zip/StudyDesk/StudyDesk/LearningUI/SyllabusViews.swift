import SwiftUI

/// 考纲地图：每门课按板块列出章节，一个小方块一章，颜色深浅 = 掌握程度。
@MainActor
struct SyllabusView: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var subject: StudySubject = .history
    @State private var selected: SyllabusNode?
    @State private var addingBlock: String?
    @State private var newTitle = ""

    private var nodes: [SyllabusNode] { learning.syllabusNodes.filter { $0.subject == subject }.sorted { $0.order < $1.order } }
    private var blocks: [String] {
        var seen = Set<String>(); return nodes.map(\.block).filter { seen.insert($0).inserted }
    }

    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text("考纲").font(TypeScale.pageTitle).foregroundStyle(Ink.ink).padding(.top, Space.l)
                InkTabs(items: [(StudySubject.history, "313 历史学"), (.politics, "政治"), (.english, "英语一")], selection: $subject)
                    .padding(.top, Space.l)
                overview.padding(.top, Space.xl)
                ForEach(blocks, id: \.self) { block in blockSection(block).padding(.top, Space.section) }
                Text("颜色越深掌握越好。点一个方块改掌握程度；AI 每天汇总时也会按你的记录更新。章节按教材的时期划分，可以对照自己的书改名、增删。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.section)
                legend.padding(.top, Space.m).padding(.bottom, Space.section)
            }
        }
        .navigationTitle("考纲").navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("syllabus-map")
        .sheet(item: $selected) { SyllabusNodeSheet(nodeID: $0.id) }
        .alert("在「\(addingBlock ?? "")」里加一节", isPresented: Binding(get: { addingBlock != nil }, set: { if !$0 { addingBlock = nil } })) {
            TextField("章节名", text: $newTitle)
            Button("取消", role: .cancel) { newTitle = "" }
            Button("添加") { if let b = addingBlock { learning.addNode(subject: subject, block: b, title: newTitle) }; newTitle = "" }
        }
    }

    private var overview: some View {
        let learned = nodes.filter { $0.mastery > 0 }.count
        let solid = nodes.filter { $0.mastery >= 3 }.count
        return VStack(alignment: .leading, spacing: Space.s) {
            Text("学过 \(learned) / \(nodes.count) 节").font(TypeScale.hero).foregroundStyle(Ink.ink)
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Ink.line)
                    Capsule().fill(Ink.dot(2)).frame(width: nodes.isEmpty ? 0 : g.size.width * CGFloat(learned) / CGFloat(nodes.count))
                    Capsule().fill(Ink.ink).frame(width: nodes.isEmpty ? 0 : g.size.width * CGFloat(solid) / CGFloat(nodes.count))
                }
            }.frame(height: 3)
            Text("其中基本掌握 \(solid) 节").font(TypeScale.label).foregroundStyle(Ink.ink3)
        }
    }

    private func blockSection(_ block: String) -> some View {
        let items = nodes.filter { $0.block == block }
        return VStack(alignment: .leading, spacing: Space.m) {
            HStack(alignment: .firstTextBaseline) {
                Text(block).font(TypeScale.serif(19)).foregroundStyle(Ink.ink)
                Spacer()
                Text("\(items.filter { $0.mastery >= 3 }.count) / \(items.count)").font(TypeScale.label).foregroundStyle(Ink.ink3).monospacedDigit()
                Button { addingBlock = block } label: { Image(systemName: "plus").font(.system(size: 13)).frame(width: 32, height: 28) }
                    .buttonStyle(.plain).foregroundStyle(Ink.ink3).accessibilityLabel("在\(block)里加一节")
            }
            VStack(spacing: 0) {
                ForEach(items) { node in
                    Button { selected = node } label: {
                        HStack(spacing: Space.m) {
                            RoundedRectangle(cornerRadius: 3).fill(node.mastery == 0 ? Ink.line : Ink.dot(node.mastery))
                                .frame(width: 14, height: 14)
                            Text(node.title).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).lineLimit(2)
                            Spacer(minLength: Space.s)
                            Text(Mastery.title(node.mastery)).font(TypeScale.label).foregroundStyle(node.mastery == 0 ? Ink.ink3 : Ink.ink2)
                        }
                        .padding(.vertical, 11).contentShape(Rectangle())
                    }
                    .buttonStyle(.plain).accessibilityIdentifier("syllabus-node-\(node.id)")
                    InkRule()
                }
            }
        }
    }

    private var legend: some View {
        HStack(spacing: Space.m) {
            ForEach(0...4, id: \.self) { level in
                HStack(spacing: 4) {
                    RoundedRectangle(cornerRadius: 2).fill(level == 0 ? Ink.line : Ink.dot(level)).frame(width: 9, height: 9)
                    Text(Mastery.title(level)).font(TypeScale.tiny).foregroundStyle(Ink.ink3)
                }
            }
        }
    }
}

/// 一个章节的详情：改掌握程度、改名、删除、看相关记录。
@MainActor
struct SyllabusNodeSheet: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    let nodeID: String
    @State private var renaming = false
    @State private var title = ""
    @State private var confirmDelete = false
    @EnvironmentObject private var chat: AppStore
    @State private var generating = false
    @State private var quizError: String?
    @State private var quiz: QuizBatch?
    @State private var essayRef: EssayRef?
    @State private var essayWorking = false
    private var node: SyllabusNode? { learning.syllabusNodes.first { $0.id == nodeID } }
    private struct QuizBatch: Identifiable, Hashable {
        let id = UUID(); let questions: [StudyQuestion]
        static func == (a: Self, b: Self) -> Bool { a.id == b.id }
        func hash(into hasher: inout Hasher) { hasher.combine(id) }
    }

    var body: some View {
        NavigationStack {
            if let node {
                InkPage(spacing: 0) {
                    VStack(alignment: .leading, spacing: 0) {
                        Text("\(node.subject.title) · \(node.block)").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                        Text(node.title).font(TypeScale.hero).foregroundStyle(Ink.ink).padding(.top, Space.s)
                        InkSectionHeader(title: "掌握程度").padding(.top, Space.xl)
                        VStack(spacing: 0) {
                            ForEach(0...4, id: \.self) { level in
                                Button { learning.setMastery(nodeID: node.id, level: level) } label: {
                                    HStack(spacing: Space.m) {
                                        HStack(spacing: 4) {
                                            ForEach(1...4, id: \.self) { i in
                                                Circle().fill(i <= level ? Ink.ink : Ink.line).frame(width: 7, height: 7)
                                            }
                                        }
                                        Text(Mastery.title(level)).font(TypeScale.serif(16)).foregroundStyle(Ink.ink)
                                        Spacer()
                                        if node.mastery == level { Image(systemName: "checkmark").foregroundStyle(Ink.seal) }
                                    }.padding(.vertical, 12).contentShape(Rectangle())
                                }.buttonStyle(.plain).accessibilityIdentifier("mastery-\(level)")
                                InkRule()
                            }
                        }
                        if let last = node.lastStudied {
                            Text("上次更新 \(last.formatted(.dateTime.month().day()))" + (node.nextReview.map { "　·　\($0.formatted(.dateTime.month().day())) 可以回顾" } ?? ""))
                                .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.m)
                        }
                        if node.subject != .english { practice(node) }
                        HStack(spacing: Space.l) {
                            Button("改名") { title = node.title; renaming = true }.buttonStyle(.inkGlass)
                            Button("删除这一节") { confirmDelete = true }.buttonStyle(.inkGlass)
                        }.padding(.top, Space.xl)
                    }
                }
                .navigationTitle("章节").navigationBarTitleDisplayMode(.inline)
                .navigationDestination(item: $quiz) { QuestionPracticeView(questions: $0.questions) }
                .navigationDestination(item: $essayRef) { EssayTaskView(taskID: $0.id) }
                .alert("没出成", isPresented: Binding(get: { quizError != nil }, set: { if !$0 { quizError = nil } })) {
                    Button("好", role: .cancel) {}
                } message: { Text(quizError ?? "") }
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { dismiss() } } }
                .alert("改名", isPresented: $renaming) {
                    TextField("章节名", text: $title)
                    Button("取消", role: .cancel) {}
                    Button("保存") { learning.renameNode(node.id, title: title) }
                }
                .confirmationDialog("删除「\(node.title)」？", isPresented: $confirmDelete, titleVisibility: .visible) {
                    Button("删除", role: .destructive) { learning.deleteNode(node.id); dismiss() }
                }
            } else {
                Text("这一节已删除").font(TypeScale.note).foregroundStyle(Ink.ink3)
            }
        }
        .presentationDetents([.medium, .large])
    }

    /// 这一节的史事条目、AI 出题和已出过的题
    @ViewBuilder private func practice(_ node: SyllabusNode) -> some View {
        let entries = HistoryDictionary.bundled.entries(inNode: node.id)
        let done = learning.chapterQuizQuestions(nodeID: node.id)
        InkSectionHeader(title: "这一节的练习").padding(.top, Space.section)
        if !entries.isEmpty {
            NavigationLink { HistoryNodeEntriesView(nodeID: node.id) } label: {
                InkRow(title: "本节史事", detail: entries.prefix(4).map(\.title).joined(separator: "、"), value: "\(entries.count) 条", chevron: true)
            }.buttonStyle(.plain).accessibilityIdentifier("node-history-entries")
        }
        if !done.isEmpty {
            NavigationLink { QuestionPracticeView(questions: done, resume: true) } label: {
                InkRow(title: "已出的题", value: PracticeProgress(questionIDs: done.map(\.id), attempts: learning.state.attempts).summary, chevron: true)
            }.buttonStyle(.plain).accessibilityIdentifier("node-quiz-history")
        }
        Button {
            generating = true
            Task {
                defer { generating = false }
                do { quiz = QuizBatch(questions: try await learning.generateChapterQuiz(nodeID: node.id, chat: chat)) }
                catch { quizError = error.localizedDescription }
            }
        } label: {
            HStack(spacing: Space.s) {
                if generating { ProgressView().controlSize(.small) }
                Text(generating ? "正在出题…" : "✦ AI 出 \(ChapterQuiz.count) 道选择题")
            }
        }
        .buttonStyle(.inkGlass).disabled(generating || !(chat.canUseAI || chat.isPreview)).padding(.top, Space.l)
        .accessibilityIdentifier("node-generate-quiz")
        Text(chat.canUseAI || chat.isPreview ? "题目按统考选择题的难度出，做错的同样进错题本、按间隔重做。AI 出的题偶尔会错，答案以教材为准。" : "先在设置里连上 AI 才能出题。")
            .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.s)
        let kind: EssayKind = node.subject == .politics ? .politicsAnalysis : .historyEssay
        Button {
            essayWorking = true
            Task {
                defer { essayWorking = false }
                do { essayRef = EssayRef(id: try await learning.generateEssay(kind: kind, nodeID: node.id, topicID: nil, chat: chat).id) }
                catch { quizError = error.localizedDescription }
            }
        } label: {
            HStack(spacing: Space.s) {
                if essayWorking { ProgressView().controlSize(.small) }
                Text(essayWorking ? "正在出题…" : "✦ 出一道本节\(kind.title)")
            }
        }
        .buttonStyle(.inkGlass).disabled(essayWorking || generating || !(chat.canUseAI || chat.isPreview)).padding(.top, Space.l)
        .accessibilityIdentifier("node-generate-essay")
        let essays = learning.essayTasks.filter { $0.nodeID == node.id }.reversed()
        if !essays.isEmpty {
            InkSectionHeader(title: "这一节出过的大题").padding(.top, Space.section).padding(.bottom, Space.xs)
            ForEach(Array(essays)) { task in
                NavigationLink { EssayTaskView(taskID: task.id) } label: {
                    InkRow(title: task.title, detail: task.kind.title,
                           value: task.best.map { "\(EssayPractice.formatScore($0.score)) / \(task.fullScore)" } ?? "没写完", valueIsSeal: task.attempts.isEmpty, chevron: true)
                }.buttonStyle(.plain)
            }
        }
        let topics = HistoryTopics.topics(touching: node.id)
        if !topics.isEmpty {
            InkSectionHeader(title: "涉及这一节的专题").padding(.top, Space.section).padding(.bottom, Space.xs)
            ForEach(topics) { topic in
                NavigationLink { HistoryTopicView(topicID: topic.id) } label: { InkRow(title: topic.title, chevron: true) }.buttonStyle(.plain)
            }
        }
    }
}
