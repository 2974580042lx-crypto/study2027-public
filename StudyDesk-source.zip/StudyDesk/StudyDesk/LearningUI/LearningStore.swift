import SwiftUI
import PDFKit
import Vision
import UniformTypeIdentifiers

@MainActor
final class LearningStore: ObservableObject {
    @Published var state = StudySnapshot()
    @Published var error: String?
    @Published var notice: String?
    @Published var busy = false
    @Published var digesting = false
    private(set) var writable = true
    private let root: URL
    let preview: Bool
    init(preview: Bool = ProcessInfo.processInfo.arguments.contains("--study-preview")) {
        self.preview = preview
        root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("Study2027/Learning", isDirectory: true)
        do {
            if !preview { try FileManager.default.createDirectory(at: attachmentsURL, withIntermediateDirectories: true) }
            if !preview && FileManager.default.fileExists(atPath: stateURL.path) {
                state = try StudySnapshot.decode(Data(contentsOf: stateURL))
                if (state.bundledContentRevision ?? 0) < 4,
                   let url = Bundle.main.url(forResource: "study-seed", withExtension: "json") {
                    let bundle = try JSONDecoder().decode(SeedBundle.self, from: Data(contentsOf: url))
                    // 内置题只留有出处的题：早期自编的示范选择题连同作答记录一起去掉
                    let retired = Set(state.questions.filter { $0.source == "原创基础练习 · 非历年真题" }.map(\.id))
                    state.questions.removeAll { retired.contains($0.id) }
                    state.attempts.removeAll { retired.contains($0.questionID) }
                    let existing = Set(state.questions.map(\.id))
                    state.questions.append(contentsOf: bundle.questions.filter { !existing.contains($0.id) })
                    state.bundledContentRevision = 4
                    save()
                }
            } else {
                if let url = Bundle.main.url(forResource: "study-seed", withExtension: "json") {
                    let bundle = try JSONDecoder().decode(SeedBundle.self, from: Data(contentsOf: url))
                    state.cards = bundle.cards; state.questions = bundle.questions; state.resources = bundle.resources
                    state.bundledContentRevision = 4
                }
                if preview { seedPreview() } else { save() }
            }
        } catch { writable = false; self.error = "读取学习记录失败，原文件已保留。\(error.localizedDescription)" }
        preparePlanData()
    }
    private var stateURL: URL { root.appendingPathComponent("learning.json") }
    var attachmentsURL: URL { root.appendingPathComponent("attachments", isDirectory: true) }
    func fileURL(_ resource: StudyResource) -> URL? { resource.fileName.map { attachmentsURL.appendingPathComponent($0) } }
    @discardableResult func save() -> Bool {
        guard writable else { return false }; if preview { return true }
        do { try state.encoded().write(to: stateURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]); return true }
        catch { self.error = "保存失败，请先导出备份：\(error.localizedDescription)"; return false }
    }
    func updatePreferences(_ value: StudyPreferences) { state.preferences = value; save() }
    func events(on day: Date) -> [LearningEvent] { state.events.filter { $0.isOn(day) }.sorted { $0.start > $1.start } }
    func summary(on day: Date, at now: Date = Date()) -> DailyStudySummary {
        var events = state.events
        if let run = state.focus, !run.isRest, let start = run.segmentStart, let end = run.effectiveEnd(at: now), end > start {
            events.append(LearningEvent(subject: run.subject, kind: .focus, title: run.label, detail: "正在学习", start: start, end: end))
        }
        return DailyStudySummary(events: events, day: day)
    }
    func wordsLearnedToday(in deck: String? = nil) -> Int {
        let ids = Set(state.cards.filter { deck == nil || $0.deck == deck }.map(\.id))
        return state.events.filter { $0.kind == .newWord && Calendar.current.isDateInToday($0.start) && ids.contains($0.referenceID ?? "") }.count
    }
    static let bundledWordDeck = "考研基础词库"
    var wordReviewOn: Bool { state.preferences.wordReview == true }
    func queue(subject: StudySubject? = nil, deck: String? = nil, reviewsOnly: Bool = false, onlyIDs: Set<String>? = nil) -> [StudyCard] {
        // 内置词库默认只查不背：不进汇总队列；直接打开这个词库时仍可以背
        let skipBundled = !wordReviewOn && deck != Self.bundledWordDeck && onlyIDs == nil
        let cards = state.cards.filter { (subject == nil || $0.subject == subject) && (deck == nil || $0.deck == deck) && (onlyIDs == nil || onlyIDs!.contains($0.id))
            && !(skipBundled && $0.deck == Self.bundledWordDeck) }
        let due = cards.filter { $0.reviews > 0 && $0.due <= Date() }.sorted { $0.due < $1.due }
        if reviewsOnly { return due }
        let remaining = max(0, state.preferences.dailyWords - wordsLearnedToday())
        let fresh = cards.filter { $0.reviews == 0 }.prefix(subject == .english || cards.allSatisfy({ $0.subject == .english }) ? remaining : 30)
        return due + fresh
    }
    func review(id: String, grade: RecallGrade) {
        guard writable, let i = state.cards.firstIndex(where: { $0.id == id }) else { return }
        let old = state.cards[i], now = Date()
        do { try state.cards[i].review(grade, at: now) }
        catch { self.error = "安排复习失败：\(error.localizedDescription)"; return }
        let kind: LearningEventKind = old.subject == .english ? (old.reviews == 0 ? .newWord : .reviewWord) : (old.reviews == 0 ? .newCard : .reviewCard)
        state.events.append(LearningEvent(subject: old.subject, kind: kind, title: old.front,
                                         detail: "\(old.deck) · \(grade.title)", start: now, end: now, referenceID: id))
        save()
    }
    func updateCard(_ card: StudyCard) {
        guard writable else { return }
        if let i = state.cards.firstIndex(where: { $0.id == card.id }) { state.cards[i] = card }
        else { state.cards.append(card) }
        save()
    }
    func recordAnswer(_ question: StudyQuestion, selected: Set<Int>) {
        guard writable else { return }; let correct = question.isCorrect(selected), now = Date()
        state.attempts.append(QuestionAttempt(questionID: question.id, selected: selected.sorted(), correct: correct, date: now))
        state.events.append(LearningEvent(subject: question.subject, kind: .question, title: String(question.stem.prefix(38)),
                                         detail: "\(question.group) · \(correct ? "答对" : "答错")", start: now, end: now,
                                         referenceID: question.id, correct: correct))
        save()
    }
    /// 仍在错题本里的题（未掌握）。规则见 WrongQuestionSchedule。
    var wrongQuestions: [StudyQuestion] {
        let states = WrongQuestionSchedule.states(attempts: state.attempts)
        return state.questions.filter { states[$0.id].map { $0.stage != .mastered } ?? false }
    }
    /// 今天到期、该重做的错题，最早答错的排前面。
    func dueWrongQuestions(at now: Date = Date()) -> [StudyQuestion] {
        let states = WrongQuestionSchedule.states(attempts: state.attempts, now: now)
        return state.questions
            .filter { states[$0.id]?.stage == .due }
            .sorted { (states[$0.id]?.lastWrong ?? .distantPast) < (states[$1.id]?.lastWrong ?? .distantPast) }
    }
    /// 还没到期的错题里，最早一道的到期时间。
    func nextWrongQuestionDate(at now: Date = Date()) -> Date? {
        WrongQuestionSchedule.states(attempts: state.attempts, now: now).values.compactMap {
            if case .waiting(let next) = $0.stage { return next } else { return nil }
        }.min()
    }
    func startFocus(subject: StudySubject, label: String, minutes: Int?, rest: Bool = false) {
        guard writable, state.focus == nil else { return }
        state.focus = FocusRun(subject: subject, label: label.isEmpty ? subject.title : label,
                               targetSeconds: minutes.map { TimeInterval($0 * 60) }, segmentStart: Date(), isRest: rest)
        save()
    }
    func pauseFocus(at now: Date = Date()) {
        guard writable, var run = state.focus, let start = run.segmentStart, let end = run.effectiveEnd(at: now) else { return }
        let duration = max(0, end.timeIntervalSince(start))
        if duration > 0 && !run.isRest {
            state.events.append(LearningEvent(subject: run.subject, kind: .focus, title: run.label,
                                             detail: "专注学习", start: start, end: max(start, end)))
        }
        run.elapsed += duration; run.segmentStart = nil; state.focus = run; save()
    }
    func resumeFocus() {
        guard writable, var run = state.focus, run.isPaused,
              run.elapsed < (run.targetSeconds ?? .greatestFiniteMagnitude) else { return }
        run.segmentStart = Date(); state.focus = run; save()
    }
    func finishFocus() { pauseFocus(); state.focus = nil; save() }
    /// 一句话记录。填了时长就当作一段补记（计入学习时长），没填只记一条笔记。
    /// 返回 false 表示没有保存（例如补记时间和已有计时重叠）。
    @discardableResult func addNote(_ text: String, subject: StudySubject?, minutes: Int?, at now: Date = Date()) -> Bool {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard writable, !trimmed.isEmpty else { return false }
        let subject = subject ?? QuickNote.guessSubject(trimmed) ?? .history
        if let minutes, minutes > 0 {
            let before = state.events.count
            addManual(subject: subject, title: QuickNote.title(for: trimmed), start: now.addingTimeInterval(-Double(minutes) * 60), minutes: minutes)
            guard state.events.count > before else { return false }
            state.events[state.events.count - 1].detail = trimmed; save(); return true
        }
        state.events.append(LearningEvent(subject: subject, kind: .note, title: QuickNote.title(for: trimmed),
                                         detail: trimmed, start: now, end: now, manual: true))
        save(); return true
    }
    /// 计时结束后补一句「这一段学了什么」：把这次计时产生的各段记录改成这句话。
    func relabelFocus(subject: StudySubject, label: String, since: Date, note: String) {
        let trimmed = note.trimmingCharacters(in: .whitespacesAndNewlines)
        guard writable, !trimmed.isEmpty else { return }
        for i in state.events.indices where state.events[i].kind == .focus && !state.events[i].manual
            && state.events[i].subject == subject && state.events[i].title == label && state.events[i].start >= since {
            state.events[i].title = QuickNote.title(for: trimmed)
            state.events[i].detail = trimmed
        }
        save()
    }
    func updateNote(_ id: UUID, text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard writable, !trimmed.isEmpty, let i = state.events.firstIndex(where: { $0.id == id && $0.manual }) else { return }
        state.events[i].title = QuickNote.title(for: trimmed); state.events[i].detail = trimmed; save()
    }
    func addManual(subject: StudySubject, title: String, start: Date, minutes: Int) {
        guard writable, (1...1440).contains(minutes) else { return }
        let end = start.addingTimeInterval(Double(minutes) * 60)
        guard end <= Date().addingTimeInterval(60) else { error = "补记的结束时间不能晚于现在。"; return }
        let overlaps = state.events.contains { $0.kind == .focus && $0.start < end && $0.end > start }
        guard !overlaps, state.focus?.segmentStart.map({ $0 < end }) != true else { error = "这段时间已有学习计时，请调整时间以免重复统计。"; return }
        state.events.append(LearningEvent(subject: subject, kind: .focus, title: title.isEmpty ? "线下学习" : title,
                                         detail: "手动补记", start: start, end: end, manual: true)); save()
    }
    func deleteEvent(_ id: UUID) { guard writable else { return }; state.events.removeAll { $0.id == id }; save() }
    func updateResource(_ resource: StudyResource, log: Bool = false) {
        guard writable else { return }
        if let i = state.resources.firstIndex(where: { $0.id == resource.id }) { state.resources[i] = resource }
        else { state.resources.insert(resource, at: 0) }
        if log { let now = Date(); state.events.append(LearningEvent(subject: resource.subject, kind: .note, title: resource.title,
                                                                    detail: "更新学习笔记", start: now, end: now, referenceID: resource.id)) }
        save()
    }
    func deleteResource(_ resource: StudyResource) {
        guard writable else { return }
        state.resources.removeAll { $0.id == resource.id }
        // Keep the original attachment recoverable; backup includes referenced files only.
        save()
    }
    func importFile(_ url: URL, subject: StudySubject, asCards: Bool) async {
        guard writable, !busy else { return }; busy = true; defer { busy = false }
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let values = try url.resourceValues(forKeys: [.fileSizeKey])
            guard (values.fileSize ?? 0) <= 25 * 1024 * 1024 else { throw StudyFailure.message("第一版请按章节导入，每个文件不超过 25 MB。") }
            let data = try Data(contentsOf: url)
            if asCards || url.pathExtension.lowercased() == "json" {
                try importPack(data, name: url.deletingPathExtension().lastPathComponent, subject: subject, json: url.pathExtension.lowercased() == "json"); return
            }
            let ext = url.pathExtension.lowercased()
            let text = try await Task.detached(priority: .userInitiated) { try Self.extractText(data, ext: ext) }.value
            let filename = UUID().uuidString + "." + ext
            try data.write(to: attachmentsURL.appendingPathComponent(filename), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            let resource = StudyResource(title: url.deletingPathExtension().lastPathComponent, subject: subject, fileName: filename, text: text)
            state.resources.insert(resource, at: 0)
            let now = Date(); state.events.append(LearningEvent(subject: subject, kind: .material, title: resource.title,
                                                               detail: "导入资料", start: now, end: now, referenceID: resource.id))
            save(); notice = text.isEmpty ? "原文件已保存。扫描 PDF 可在阅读页逐页识别。" : "资料已导入，可阅读、做笔记和提问。"
        } catch { self.error = error.localizedDescription }
    }
    func importPack(_ data: Data, name: String, subject: StudySubject, json: Bool) throws {
        var cards: [StudyCard] = [], questions: [StudyQuestion] = [], readings: [ReadingPassage] = []
        if json {
            let pack = try JSONDecoder().decode(ImportedStudyPack.self, from: data)
            cards = (pack.cards ?? []).map { $0.card(subject: subject, deck: name) }; questions = pack.questions ?? []; readings = pack.readings ?? []
        } else {
            guard let text = String(data: data, encoding: .utf8) else { throw StudyFailure.message("词表需要 UTF-8 编码。") }
            cards = try StudyImport.parseCards(text, subject: subject, deck: name)
        }
        guard !cards.isEmpty || !questions.isEmpty || !readings.isEmpty else { throw StudyFailure.message("没有找到可导入的卡片、题目或阅读。") }
        var candidate = state
        var keys = Set(candidate.cards.map { "\($0.subject.rawValue)|\($0.deck)|\($0.front.lowercased())" })
        var qids = Set(candidate.questions.map(\.id)), added = 0, addedQ = 0
        for card in cards {
            if keys.insert("\(card.subject.rawValue)|\(card.deck)|\(card.front.lowercased())").inserted { candidate.cards.append(card); added += 1 }
        }
        for q in questions { try q.validate(); if qids.insert(q.id).inserted { candidate.questions.append(q); addedQ += 1 } }
        let readingImport = try candidate.mergingReadings(readings)
        candidate = readingImport.snapshot
        try candidate.validate()
        let old = state; state = candidate
        guard save() else { state = old; throw StudyFailure.message("导入内容暂未保存，原有记录未被替换。") }
        notice = "新增 \(added) 张卡片、\(addedQ) 道题；阅读新增 \(readingImport.added) 篇、更新 \(readingImport.updated) 篇。阅读位置与历史作答已保留。"
    }
    nonisolated static func extractText(_ data: Data, ext: String) throws -> String {
        if ext == "pdf" {
            guard let doc = PDFDocument(data: data) else { throw StudyFailure.message("无法读取这个 PDF。") }
            return (0..<min(doc.pageCount, 300)).compactMap { i in doc.page(at: i)?.string.map { "[第 \(i+1) 页]\n\($0)" } }.joined(separator: "\n\n")
        }
        if ["jpg", "jpeg", "png", "heic"].contains(ext) {
            let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate
            request.recognitionLanguages = ["zh-Hans", "en-US"]
            try VNImageRequestHandler(data: data).perform([request])
            return request.results?.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n") ?? ""
        }
        guard let text = String(data: data, encoding: .utf8) else { throw StudyFailure.message("请导入 PDF、图片或 UTF-8 文本。") }
        return text
    }
    func exportBackup() -> URL? {
        do {
            var attachments: [String: Data] = [:], total = 0
            for r in state.resources { if let filename = r.fileName, attachments[filename] == nil {
                let data = try Data(contentsOf: attachmentsURL.appendingPathComponent(filename)); total += data.count
                guard total <= 100 * 1024 * 1024 else { throw StudyFailure.message("附件总量超过 100 MB，请先单独保存大型原文件。") }
                attachments[filename] = data
            } }
            try state.validate(); let encoder = JSONEncoder(); encoder.dateEncodingStrategy = .iso8601
            let url = FileManager.default.temporaryDirectory.appendingPathComponent("研习备份-\(Int(Date().timeIntervalSince1970)).json")
            try encoder.encode(StudyBackup(state: state, attachments: attachments)).write(to: url, options: .atomic); return url
        } catch { self.error = error.localizedDescription; return nil }
    }
    func restoreBackup(_ url: URL) {
        guard !busy else { return }
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        let stage = root.deletingLastPathComponent().appendingPathComponent("Restore-" + UUID().uuidString)
        let old = root.deletingLastPathComponent().appendingPathComponent("BeforeRestore-" + UUID().uuidString)
        do {
            guard (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 160 * 1024 * 1024 else { throw StudyFailure.message("备份文件过大。") }
            let decoder = JSONDecoder(); decoder.dateDecodingStrategy = .iso8601
            let backup = try decoder.decode(StudyBackup.self, from: Data(contentsOf: url))
            guard backup.format == "study2027-backup", backup.version == 1 else { throw StudyFailure.message("请选择研习的学习备份。AI 聊天备份请在 AI 设置中恢复。") }
            try backup.state.validate()
            try FileManager.default.createDirectory(at: stage.appendingPathComponent("attachments"), withIntermediateDirectories: true)
            for r in backup.state.resources { if let filename = r.fileName {
                guard let data = backup.attachments[filename] else { throw StudyFailure.message("备份缺少附件：\(r.title)") }
                try data.write(to: stage.appendingPathComponent("attachments").appendingPathComponent(filename), options: .atomic)
            } }
            var restored = backup.state; restored.focus = nil
            try restored.encoded().write(to: stage.appendingPathComponent("learning.json"), options: .atomic)
            if FileManager.default.fileExists(atPath: root.path) { try FileManager.default.moveItem(at: root, to: old) }
            do { try FileManager.default.moveItem(at: stage, to: root) }
            catch { if FileManager.default.fileExists(atPath: old.path) { try? FileManager.default.moveItem(at: old, to: root) }; throw error }
            state = restored; writable = true; notice = "学习记录与附件已恢复。恢复前的数据另留了一份本机副本。"
        } catch { self.error = error.localizedDescription }
    }
    private struct SeedBundle: Decodable { var cards: [StudyCard]; var questions: [StudyQuestion]; var resources: [StudyResource] }
    private func seedPreview() {
        // UI tests may launch the preview app repeatedly on the same simulator.
        // Keep preview reading state deterministic even if bundled preview data grows later.
        state.readingAttempts = nil
        state.readingWords = nil
        let now = Date(), start = Calendar.current.startOfDay(for: now).addingTimeInterval(9 * 3600)
        state.events = [LearningEvent(subject: .english, kind: .focus, title: "阅读与词汇", detail: "专注学习", start: start, end: start.addingTimeInterval(2100)),
                        LearningEvent(subject: .history, kind: .focus, title: "中国古代史", detail: "专注学习", start: start.addingTimeInterval(5400), end: start.addingTimeInterval(8100))]
    }
}
