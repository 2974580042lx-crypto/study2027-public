import SwiftUI
import Combine

@MainActor
struct StudyRootView: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var tab = 0
    @State private var settings = false
    @State private var assistant = false
    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { StudyDashboard(openSettings: { settings = true }, openAI: { assistant = true }) }
                .tabItem { Label("学习", systemImage: "book") }.tag(0)
            NavigationStack { ReviewHub() }.tabItem { Label("复习", systemImage: "arrow.clockwise") }.tag(1)
            NavigationStack { StudyLibrary() }.tabItem { Label("资料", systemImage: "books.vertical") }.tag(2)
        }
        .tint(Ink.ink)
        .sheet(isPresented: $settings) { StudySettingsView() }
        .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
        .alert("需要处理", isPresented: Binding(get: { learning.error != nil }, set: { if !$0 { learning.error = nil } })) {
            Button("知道了") { learning.error = nil }
        } message: { Text(learning.error ?? "") }
        .alert("已完成", isPresented: Binding(get: { learning.notice != nil }, set: { if !$0 { learning.notice = nil } })) {
            Button("好") { learning.notice = nil }
        } message: { Text(learning.notice ?? "") }
        .onAppear {
            if ProcessInfo.processInfo.arguments.contains("--study-library") { tab = 2 }
            if ProcessInfo.processInfo.arguments.contains("--study-review") { tab = 1 }
        }
    }
}

struct StudyPanel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(Ink.raised.opacity(0.5), in: RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(Ink.line, lineWidth: 0.7))
    }
}
struct StudyPage<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        ScrollView { content.frame(maxWidth: 900).frame(maxWidth: .infinity).padding(.horizontal, 22).padding(.top, 14).padding(.bottom, 30) }
            .background(AppBackground()).scrollDismissesKeyboard(.interactively)
    }
}
func studyDuration(_ seconds: TimeInterval) -> String {
    let minutes = max(0, Int(seconds / 60))
    return minutes >= 60 ? "\(minutes / 60) 小时 \(minutes % 60) 分钟" : "\(minutes) 分钟"
}

@MainActor
struct StudyDashboard: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    var openSettings: () -> Void
    var openAI: () -> Void
    @State private var date = Date()
    @State private var showCalendar = false
    @State private var focus = false
    @State private var manual = false
    @State private var tick = Date()
    private var summary: DailyStudySummary { learning.summary(on: date, at: tick) }
    var body: some View {
        StudyPage {
            VStack(alignment: .leading, spacing: 26) {
                TimelineView(.periodic(from: .now, by: 60)) { timeline in
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("2027 · 考研").font(.caption).tracking(2).foregroundStyle(.secondary)
                            HStack(alignment: .firstTextBaseline, spacing: 10) {
                                Text("\(StudyPreferences.daysUntil(learning.state.preferences.examDate, from: timeline.date))")
                                    .font(.system(size: 70, weight: .light, design: .serif)).monospacedDigit().accessibilityIdentifier("exam-countdown")
                                Text("天").font(.title3).foregroundStyle(.secondary)
                            }
                            Text("距离 \(learning.state.preferences.examDate.formatted(.dateTime.year().month().day()))")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button { focus = true } label: { Image(systemName: "timer").font(.title2).frame(width: 58, height: 58) }
                            .buttonStyle(.plain).glassEffect(.regular.interactive(), in: .circle).accessibilityLabel("开始学习计时")
                    }
                }
                if learning.state.focus != nil { FocusBanner(open: { focus = true }) }
                HStack {
                    Button { date = Calendar.current.date(byAdding: .day, value: -1, to: date)! } label: { Image(systemName: "chevron.left").frame(width: 36, height: 36) }.accessibilityLabel("前一天")
                    Spacer()
                    Button { showCalendar = true } label: {
                        HStack(spacing: 7) { Text(Calendar.current.isDateInToday(date) ? "今天" : date.formatted(.dateTime.month().day())); Image(systemName: "chevron.down").font(.caption2) }
                    }.accessibilityIdentifier("day-picker")
                    Spacer()
                    Button { date = Calendar.current.date(byAdding: .day, value: 1, to: date)! } label: { Image(systemName: "chevron.right").frame(width: 36, height: 36) }
                        .disabled(Calendar.current.isDateInToday(date)).accessibilityLabel("后一天")
                }.font(.headline)
                StudyPanel {
                    VStack(alignment: .leading, spacing: 16) {
                        HStack(alignment: .firstTextBaseline) {
                            Text(studyDuration(summary.seconds)).font(.system(size: 27, weight: .medium, design: .rounded)).accessibilityIdentifier("daily-duration")
                            Spacer()
                            Button { manual = true } label: { Label("补记", systemImage: "plus") }.font(.caption)
                        }
                        ProgressView(value: min(1, summary.seconds / Double(learning.state.preferences.dailyMinutes * 60))).tint(Ink.ink)
                        HStack {
                            metric("新学单词", summary.newWords)
                            Spacer(); metric("复习单词", summary.reviewedWords)
                            Spacer(); metric("作答次数", summary.answers)
                        }
                    }
                }
                HStack {
                    Text("学习科目").font(.custom("NotoSerifSC-Regular", size: 21))
                    Spacer()
                }
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), spacing: 12)], spacing: 12) {
                    ForEach(StudySubject.allCases) { subject in
                        NavigationLink { SubjectHub(subject: subject) } label: {
                            StudyPanel {
                                VStack(alignment: .leading, spacing: 22) {
                                    Image(systemName: subject.symbol).font(.title2)
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(subject.title).font(.system(size: 19, weight: .medium))
                                        Text(subject == .english ? "词汇 · 真题 · 阅读" : subject == .politics ? "练习 · 错题 · 笔记" : "史料 · 练习 · 背诵").font(.caption2).foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }.buttonStyle(.plain).accessibilityIdentifier("subject-\(subject.rawValue)")
                    }
                }
                VStack(alignment: .leading, spacing: 15) {
                    Text("学习时间轴").font(.custom("NotoSerifSC-Regular", size: 24))
                    let events = learning.events(on: date)
                    if events.isEmpty {
                        Text("这一天还没有学习记录。开始计时、背词或做题后，会自动记录在这里。")
                            .font(.subheadline).foregroundStyle(.secondary).padding(.vertical, 10)
                    } else {
                        ForEach(Array(events.prefix(80))) { event in TimelineEventRow(event: event) }
                        if events.count > 80 { Text("当天共 \(events.count) 条记录，首页展示最近 80 条。所有记录均已保存。") .font(.caption).foregroundStyle(.secondary) }
                    }
                }
                if !learning.events(on: date).isEmpty {
                    StudyPanel {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("当日小结", systemImage: "text.alignleft").font(.headline)
                            Text("累计学习 \(studyDuration(summary.seconds))，新学 \(summary.newWords) 个单词，复习 \(summary.reviewedWords) 次单词及 \(summary.cardReviews) 次知识卡。完成 \(summary.answers) 次作答，其中答对 \(summary.correct) 次。")
                                .font(.subheadline).foregroundStyle(.secondary).lineSpacing(5)
                            if summary.readingsCompleted > 0 || summary.wordsCollected > 0 {
                                Text("完成 \(summary.readingsCompleted) 篇阅读 · 收录 \(summary.wordsCollected) 个生词").font(.subheadline).foregroundStyle(.secondary)
                            }
                            ForEach(StudySubject.allCases) { s in
                                if let seconds = summary.subjects[s], seconds > 0 { Text("\(s.title) · \(studyDuration(seconds))").font(.caption) }
                            }
                            Button("让 AI 帮我复盘") {
                                let facts = learning.events(on: date).prefix(60).map { "\($0.subject.title)：\($0.title) · \($0.detail)" }.joined(separator: "\n")
                                let prompt = "请根据下面已记录的学习事实，帮我复盘 \(date.formatted(date: .numeric, time: .omitted)) 的学习。输出：完成了什么、需要巩固什么、下一次的具体建议。不猜测没有记录的学习内容，不把做过等同于掌握。\n专注时间：\(studyDuration(summary.seconds))\n新词：\(summary.newWords)，复习单词：\(summary.reviewedWords)，作答：\(summary.answers)，答对：\(summary.correct)\n\(facts)"
                                if chat.prepareStudyDraft(prompt) { openAI() }
                            }.buttonStyle(.glass).font(.caption)
                        }
                    }
                }
            }
        }
        .navigationTitle("研习").navigationBarTitleDisplayMode(.inline)
        .onReceive(Timer.publish(every: 10, on: .main, in: .common).autoconnect()) { now in
            if Calendar.current.isDate(date, inSameDayAs: tick) && !Calendar.current.isDate(tick, inSameDayAs: now) { date = now }
            tick = now
        }
        .toolbar {
            ToolbarItem(placement: .topBarLeading) { Button(action: openSettings) { Image(systemName: "slider.horizontal.3") }.accessibilityLabel("学习设置") }
            ToolbarItem(placement: .topBarTrailing) { Button(action: openAI) { Image(systemName: "sparkles") }.accessibilityLabel("学习助手") }
        }
        .sheet(isPresented: $focus) { FocusView() }
        .sheet(isPresented: $manual) { ManualStudyView() }
        .sheet(isPresented: $showCalendar) {
            NavigationStack {
                DatePicker("学习日期", selection: $date, in: ...Date(), displayedComponents: .date).datePickerStyle(.graphical).padding()
                    .navigationTitle("选择日期").toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { showCalendar = false } } }
            }.presentationDetents([.medium])
        }
    }
    private func metric(_ label: String, _ value: Int) -> some View {
        VStack(alignment: .leading, spacing: 5) { Text("\(value)").font(.title2.monospacedDigit()); Text(label).font(.caption2).foregroundStyle(.secondary) }
    }
}

@MainActor
struct TimelineEventRow: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let event: LearningEvent
    var body: some View {
        Group {
            if event.kind == .assistant, let id = event.referenceID,
               let thread = chat.threads.first(where: { $0.messages.contains(where: { $0.id.uuidString == id }) }) {
                NavigationLink { StudyAssistantView(threadID: thread.id) } label: { row }
            } else if let id = event.readingPassageID, learning.readingPassages.contains(where: { $0.id == id }) {
                NavigationLink { ReadingPracticeView(passageID: id, initialQuestionID: event.readingQuestionID, initialAttemptID: event.readingAttemptID) } label: { row }
            } else if let id = event.referenceID, let card = learning.state.cards.first(where: { $0.id == id }) {
                NavigationLink { CardDetailView(cardID: card.id) } label: { row }
            } else if let id = event.referenceID, let q = learning.state.questions.first(where: { $0.id == id }) {
                NavigationLink { QuestionPracticeView(questions: [q]) } label: { row }
            } else if let id = event.referenceID, let r = learning.state.resources.first(where: { $0.id == id }) {
                NavigationLink { ResourceDetailView(resourceID: r.id) } label: { row }
            } else { row }
        }.buttonStyle(.plain)
    }
    private var row: some View {
        HStack(alignment: .top, spacing: 15) {
            VStack(spacing: 5) { Circle().fill(Ink.ink2).frame(width: 6, height: 6); Rectangle().fill(Ink.line).frame(width: 1, height: 38) }.padding(.top, 7)
            VStack(alignment: .leading, spacing: 5) {
                Text("\(event.start.formatted(.dateTime.hour().minute())) · \(event.subject.title)").font(.caption).foregroundStyle(.secondary)
                Text(event.title).font(.subheadline).lineLimit(2)
                Text(event.kind == .focus ? "\(studyDuration(event.end.timeIntervalSince(event.start))) · \(event.detail)" : event.detail)
                    .font(.caption2).foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
    }
}

@MainActor
struct FocusBanner: View {
    @EnvironmentObject private var learning: LearningStore
    var open: () -> Void
    var body: some View {
        if let run = learning.state.focus {
            Button(action: open) {
                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    HStack { Image(systemName: run.isRest ? "cup.and.saucer" : "timer"); Text(run.label).lineLimit(1); Spacer(); Text(clock(run, at: timeline.date)).monospacedDigit(); Image(systemName: run.isPaused ? "pause.fill" : "chevron.right").font(.caption) }
                        .font(.subheadline).padding(16).glassEffect(.regular.interactive(), in: .capsule)
                }
            }.buttonStyle(.plain)
        }
    }
    private func clock(_ run: FocusRun, at now: Date) -> String {
        let time = Int(run.targetSeconds.map { max(0, $0 - run.total(at: now)) } ?? run.total(at: now))
        return String(format: "%02d:%02d", time / 60, time % 60)
    }
}

@MainActor
struct FocusView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State private var subject: StudySubject = .english
    @State private var label = ""
    @State private var countdown = false
    @State private var minutes = 25
    var body: some View {
        NavigationStack {
            Group {
                if let run = learning.state.focus {
                    TimelineView(.periodic(from: .now, by: 1)) { timeline in
                        let elapsed = run.total(at: timeline.date)
                        let seconds = Int(run.targetSeconds.map { max(0, $0 - elapsed) } ?? elapsed)
                        VStack(spacing: 26) {
                            Spacer()
                            Text(run.isRest ? "休息一下" : run.subject.title).foregroundStyle(.secondary)
                            Text(run.label).font(.custom("NotoSerifSC-Regular", size: 25))
                            Text(String(format: "%02d:%02d", seconds / 60, seconds % 60)).font(.system(size: 66, weight: .light, design: .rounded)).monospacedDigit().accessibilityIdentifier("focus-clock")
                            if let target = run.targetSeconds, elapsed >= target { Text("这一段已完成").foregroundStyle(.secondary) }
                            HStack(spacing: 20) {
                                Button(run.isPaused ? "继续" : "暂停") { if run.isPaused { learning.resumeFocus() } else { learning.pauseFocus() } }
                                    .buttonStyle(.glass).disabled(run.targetSeconds.map { elapsed >= $0 } ?? false)
                                Button("结束并保存") { learning.finishFocus(); dismiss() }.buttonStyle(.glassProminent)
                            }
                            if !run.isRest {
                                Button("结束学习，休息 \(learning.state.preferences.restMinutes) 分钟") {
                                    let subject = run.subject; learning.finishFocus()
                                    learning.startFocus(subject: subject, label: "休息", minutes: learning.state.preferences.restMinutes, rest: true)
                                }.font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(run.isRest ? "休息不计入学习时长" : "暂停的时间不计入学习时长").font(.caption).foregroundStyle(.secondary)
                        }.padding(25).frame(maxWidth: .infinity)
                            .onChange(of: seconds) { _, _ in if let target = run.targetSeconds, elapsed >= target, !run.isPaused { learning.pauseFocus(at: timeline.date) } }
                    }
                } else {
                    Form {
                        Section("这次学什么") {
                            Picker("科目", selection: $subject) { ForEach(StudySubject.allCases) { Text($0.title).tag($0) } }
                            TextField("内容，例如：阅读第 2 篇", text: $label)
                        }
                        Section("计时方式") {
                            Toggle("番茄倒计时", isOn: $countdown)
                            if countdown { Stepper("学习 \(minutes) 分钟", value: $minutes, in: 1...180) }
                            else { Text("自由计时，学完后结束。").foregroundStyle(.secondary) }
                        }
                        Button("开始学习") { learning.startFocus(subject: subject, label: label, minutes: countdown ? minutes : nil) }.accessibilityIdentifier("focus-start")
                    }.scrollContentBackground(.hidden)
                }
            }.background(AppBackground()).navigationTitle("专注").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("收起") { dismiss() } } }
        }.onAppear { subject = learning.state.preferences.preferredSubject; minutes = learning.state.preferences.focusMinutes }
    }
}

@MainActor
struct ManualStudyView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State private var subject: StudySubject = .english
    @State private var title = ""
    @State private var end = Date()
    @State private var minutes = 30
    var body: some View {
        NavigationStack { Form {
            Picker("科目", selection: $subject) { ForEach(StudySubject.allCases) { Text($0.title).tag($0) } }
            TextField("学习内容", text: $title)
            DatePicker("结束时间", selection: $end, in: ...Date())
            Stepper("学习 \(minutes) 分钟", value: $minutes, in: 1...600, step: 5)
            Text("补记纸质书或线下学习；与已记录时段重叠时会提示调整。").font(.caption).foregroundStyle(.secondary)
        }.navigationTitle("补记学习").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") { learning.addManual(subject: subject, title: title, start: end.addingTimeInterval(-Double(minutes)*60), minutes: minutes); dismiss() } }
        } }
    }
}
