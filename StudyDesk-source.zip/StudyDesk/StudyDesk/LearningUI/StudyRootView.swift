import SwiftUI
import Combine
import UIKit

enum StudyRootSection: Hashable {
    case today, review, library
    case subject(StudySubject)
}

private struct SidebarGlyph: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 6.2) {
            Capsule().frame(width: 16, height: 1.8)
            Capsule().frame(width: 10, height: 1.8)
        }
        .frame(width: 18, height: 18, alignment: .leading)
        .accessibilityHidden(true)
    }
}

@MainActor
struct StudyRootView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var section: StudyRootSection = {
        if ProcessInfo.processInfo.arguments.contains("--study-library") { return .library }
        if ProcessInfo.processInfo.arguments.contains("--study-review") { return .review }
        return .today
    }()
    @State private var showSidebar = ProcessInfo.processInfo.arguments.contains("--study-sidebar")
    @State private var sidebarDrag: CGFloat = 0
    @State private var settings = false
    @State private var assistant = false
    @State private var assistantThreadID: UUID?
    @AppStorage("study2027.haptics") private var hapticsEnabled = true
    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width * 0.76, 340)
            let position = min(width, max(0, (showSidebar ? width : 0) + sidebarDrag))
            let progress = position / width
            let frontPage = PageContour(radius: Radius.pageFront * progress, topInset: geometry.safeAreaInsets.top,
                                        bottomInset: geometry.safeAreaInsets.bottom)
            let backPage = PageContour(radius: Radius.pageBack * progress, topInset: geometry.safeAreaInsets.top,
                                       bottomInset: geometry.safeAreaInsets.bottom)
            ZStack(alignment: .leading) {
                Ink.paper.ignoresSafeArea()
                StudySidebar(selection: $section, close: { showSidebar = false }, openSettings: {
                    showSidebar = false; settings = true
                }, openConversation: { id in
                    showSidebar = false; assistantThreadID = id; assistant = true
                }, openSearch: {
                    section = .library; showSidebar = false
                })
                .frame(width: width)
                .background(Ink.sheet.ignoresSafeArea())
                .clipShape(backPage)
                .overlay(backPage.stroke(Ink.line.opacity(progress), lineWidth: 0.5).allowsHitTesting(false))
                .offset(x: -width * 0.2 * (1 - progress))
                .opacity(min(1, progress * 3))
                .allowsHitTesting(showSidebar)
                .accessibilityHidden(!showSidebar)

                NavigationStack { rootPage(openSidebar: { showSidebar = true }) }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .scrollDisabled(sidebarDrag != 0)
                    .tint(Ink.ink)
                    .background(AppBackground())
                    .overlay {
                        if progress > 0 {
                            Ink.ink.opacity(0.12 * progress).contentShape(Rectangle())
                                .onTapGesture { showSidebar = false }
                        }
                    }
                    .clipShape(frontPage)
                    .overlay(frontPage.stroke(Ink.line.opacity(progress), lineWidth: 0.6).allowsHitTesting(false))
                    .scaleEffect(reduceMotion ? 1 : 1 - 0.01 * progress, anchor: .trailing)
                    .offset(x: position)
                    .shadow(color: Ink.ink.opacity(0.18 * progress), radius: 14, x: -5)
                    .accessibilityHidden(showSidebar)
            }
            .contentShape(Rectangle())
            .animation(reduceMotion ? nil : .snappy(duration: 0.28), value: showSidebar)
            .background(SidebarPan(enabled: true, isOpen: showSidebar,
                maximumStartY: geometry.frame(in: .global).maxY - 92,
                changed: { distance in
                    sidebarDrag = showSidebar ? max(-width, min(0, distance)) : min(width, max(0, distance))
                }, ended: { distance, prediction in
                    let threshold = min(65, width * 0.18)
                    let open = showSidebar ? !(distance < -threshold || prediction < -width * 0.45) :
                        (distance > threshold || prediction > width * 0.45)
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { showSidebar = open; sidebarDrag = 0 }
                }, cancelled: {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { sidebarDrag = 0 }
                }))
        }
        .sheet(isPresented: $settings) { StudySettingsView() }
        .fullScreenCover(isPresented: $assistant) { StudyAssistantView(threadID: assistantThreadID) }
        .alert("需要处理", isPresented: Binding(get: { learning.error != nil }, set: { if !$0 { learning.error = nil } })) {
            Button("知道了") { learning.error = nil }
        } message: { Text(learning.error ?? "") }
        .alert("已完成", isPresented: Binding(get: { learning.notice != nil }, set: { if !$0 { learning.notice = nil } })) {
            Button("好") { learning.notice = nil }
        } message: { Text(learning.notice ?? "") }
        .onChange(of: section) { _, _ in showSidebar = false }
        .onChange(of: showSidebar) { _, _ in
            if hapticsEnabled { UIImpactFeedbackGenerator(style: .soft).impactOccurred(intensity: 0.65) }
        }
    }

    @ViewBuilder private func rootPage(openSidebar: @escaping () -> Void) -> some View {
        switch section {
        case .today:
            StudyDashboard(openSidebar: openSidebar, openAI: { prompt in
                if !prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { _ = chat.prepareStudyDraft(prompt) }
                assistantThreadID = nil; assistant = true
            })
        case .review:
            ReviewHub().toolbar { sidebarButton(openSidebar) }
        case .library:
            StudyLibrary().toolbar { sidebarButton(openSidebar) }
        case .subject(let subject):
            SubjectHub(subject: subject).toolbar { sidebarButton(openSidebar) }
        }
    }

    private func sidebarButton(_ action: @escaping () -> Void) -> some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button(action: action) { SidebarGlyph() }.accessibilityLabel("打开侧栏")
        }
    }
}

@MainActor
struct StudySidebar: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    @Environment(\.colorScheme) private var colorScheme
    @Binding var selection: StudyRootSection
    let close: () -> Void
    let openSettings: () -> Void
    let openConversation: (UUID) -> Void
    let openSearch: () -> Void
    private var dueCount: Int { learning.queue(reviewsOnly: true).count }
    private var selectedBackground: Color { colorScheme == .dark ? Ink.raised : Ink.paper.opacity(0.7) }
    var body: some View {
        VStack(alignment: .leading, spacing: Space.m) {
            HStack(spacing: Space.s) {
                SealStamp(size: 28)
                Text("研习").font(TypeScale.subject).foregroundStyle(Ink.ink)
                Spacer()
                Button(action: openSearch) { Image(systemName: "magnifyingglass").frame(width: 40, height: 40) }
                    .buttonStyle(.plain).foregroundStyle(Ink.ink2).accessibilityLabel("搜索学习资料")
            }.padding(.top, Space.l)
            VStack(spacing: 2) {
                sidebarRow("今天", section: .today, symbol: "sun.max")
                sidebarRow("复习", section: .review, symbol: "arrow.clockwise", badge: dueCount)
                sidebarRow("资料", section: .library, symbol: "books.vertical")
            }
            Text("科目").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                .padding(.top, Space.s).padding(.horizontal, Space.m)
            VStack(spacing: 2) {
                subjectRow(.english); subjectRow(.politics); subjectRow(.history)
            }
            Text("最近的对话").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                .padding(.top, Space.s).padding(.horizontal, Space.m)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 2) {
                    ForEach(Array(chat.sortedThreads.prefix(5))) { thread in
                        Button { openConversation(thread.id) } label: {
                            HStack(spacing: Space.s) {
                                Text(thread.title).font(.system(size: 15)).foregroundStyle(Ink.ink2).lineLimit(1)
                                Spacer(minLength: 0)
                            }.padding(.horizontal, Space.m).frame(height: 42).contentShape(Rectangle())
                        }.buttonStyle(.plain)
                    }
                    if chat.sortedThreads.isEmpty { Text("暂无学习对话").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.vertical, Space.s) }
                }
            }
            Spacer(minLength: 0)
            InkRule()
            Button(action: openSettings) {
                HStack { Image(systemName: "gearshape"); Text("设置"); Spacer() }
                    .font(.system(size: 16)).foregroundStyle(Ink.ink)
                    .padding(.horizontal, Space.m).frame(height: 50).contentShape(Rectangle())
            }.buttonStyle(.plain).accessibilityLabel("学习设置")
        }
        .padding(.horizontal, Space.l).padding(.bottom, Space.s)
    }

    private func sidebarRow(_ title: String, section item: StudyRootSection, symbol: String, badge: Int? = nil) -> some View {
        Button { selection = item; close() } label: {
            HStack(spacing: Space.m) {
                Image(systemName: symbol).frame(width: 20)
                Text(title).fontWeight(selection == item ? .semibold : .regular)
                Spacer()
                if let badge, badge > 0 { Text("\(badge)").font(TypeScale.label.weight(.semibold)).foregroundStyle(Ink.seal) }
            }
            .font(.system(size: 16)).foregroundStyle(Ink.ink).padding(.horizontal, Space.m).frame(height: 44)
            .background(selection == item ? selectedBackground : .clear, in: RoundedRectangle(cornerRadius: Radius.control))
            .contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityAddTraits(selection == item ? .isSelected : [])
    }

    private func subjectRow(_ subject: StudySubject) -> some View {
        let item = StudyRootSection.subject(subject)
        return Button { selection = item; close() } label: {
            HStack { Text(subject.title).font(TypeScale.serif(17)); Spacer() }
                .foregroundStyle(Ink.ink).padding(.horizontal, Space.m).frame(height: 44)
                .background(selection == item ? selectedBackground : .clear, in: RoundedRectangle(cornerRadius: Radius.control))
                .contentShape(Rectangle())
        }.buttonStyle(.plain).accessibilityAddTraits(selection == item ? .isSelected : [])
    }
}

struct StudyPanel<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        content.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(Ink.raised.opacity(0.5), in: RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(Ink.line, lineWidth: 0.7))
    }
}
struct StudyPage<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        ScrollView { content.frame(maxWidth: 900).frame(maxWidth: .infinity).padding(.horizontal, 22).padding(.top, 14).padding(.bottom, 30) }
            .background(AppBackground()).scrollDismissesKeyboard(.interactively)
    }
}
func studyDuration(_ seconds: TimeInterval) -> String {
    let minutes = max(0, Int(seconds / 60))
    guard minutes >= 60 else { return "\(minutes) 分钟" }
    let remainder = minutes % 60
    return remainder == 0 ? "\(minutes / 60) 小时" : "\(minutes / 60) 小时 \(remainder) 分钟"
}

@MainActor
struct StudyDashboard: View {
    @EnvironmentObject private var learning: LearningStore
    let openSidebar: () -> Void
    let openAI: (String) -> Void
    @State private var date = Date()
    @State private var showCalendar = false
    @State private var focus = false
    @State private var manual = false
    @State private var tick = Date()
    @State private var calendarDays: [PrepCalendarDay] = []
    @State private var composerText = ""
    private var summary: DailyStudySummary { learning.summary(on: date, at: tick) }
    private var events: [LearningEvent] { learning.events(on: date) }
    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                dateAndCountdown
                if learning.state.focus != nil { FocusBanner(open: { focus = true }).padding(.top, Space.m) }
                Text(dayTitle).font(TypeScale.hero).foregroundStyle(Ink.ink).padding(.top, Space.s)
                    .accessibilityIdentifier("daily-duration")
                Text("目标 \(studyDuration(TimeInterval(learning.state.preferences.dailyMinutes * 60)))　·　新词 \(summary.newWords)　·　复习 \(summary.reviewedWords)　·　正确 \(summary.correct) / \(summary.answers)")
                    .font(TypeScale.label).foregroundStyle(Ink.ink3).padding(.top, Space.s)
                PrepCalendarView(days: calendarDays, examDate: learning.state.preferences.examDate) { selected in date = selected }
                    .padding(.top, Space.section)
                InkRule().padding(.top, 28)
                subjectLink(.english, value: "\(learning.queue(subject: .english, reviewsOnly: true).count) 个单词待复习")
                    .accessibilityIdentifier("subject-english")
                subjectLink(.politics, value: "\(learning.wrongQuestions.filter { $0.subject == .politics }.count) 道错题")
                    .accessibilityIdentifier("subject-politics")
                subjectLink(.history, value: "史料 · 背诵", divider: false)
                    .accessibilityIdentifier("subject-history")

                InkSectionHeader(title: Calendar.current.isDateInToday(date) ? "今日记录" : "学习记录", trailing: events.isEmpty ? nil : "全部")
                    .padding(.top, Space.section)
                if events.isEmpty {
                    Text("这一天还没有学习记录。开始计时、背词或做题后，会自动记录在这里。")
                        .font(TypeScale.label).foregroundStyle(Ink.ink3).padding(.vertical, Space.l)
                } else {
                    ForEach(Array(events.prefix(80))) { TimelineEventRow(event: $0) }
                    if events.count > 80 { Text("当天共 \(events.count) 条记录，首页展示最近 80 条。所有记录均已保存。") .font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                }
                if !events.isEmpty {
                    InkSectionHeader(title: "小结").padding(.top, Space.section)
                    Text(summaryText).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).padding(.top, Space.m)
                    if summary.readingsCompleted > 0 || summary.wordsCollected > 0 {
                        Text("完成 \(summary.readingsCompleted) 篇阅读 · 收录 \(summary.wordsCollected) 个生词")
                            .font(TypeScale.label).foregroundStyle(Ink.ink3).padding(.top, Space.s)
                    }
                    Button("让 AI 帮我复盘") { openAI(reviewPrompt) }.buttonStyle(.inkGlass).padding(.top, Space.l)
                }
            }
        }
        .inkBottomBar {
            InkComposer(text: $composerText, placeholder: "问点什么…", canSend: true, fieldIdentifier: "study-home-composer",
                        onAttach: { openAI("") }, onSend: {
                            let prompt = composerText; composerText = ""; openAI(prompt)
                        })
        }
        .navigationTitle("研习").navigationBarTitleDisplayMode(.inline)
        .onReceive(Timer.publish(every: 10, on: .main, in: .common).autoconnect()) { now in
            if Calendar.current.isDate(date, inSameDayAs: tick) && !Calendar.current.isDate(tick, inSameDayAs: now) { date = now }
            tick = now
        }
        .onAppear { refreshCalendar() }
        .onChange(of: learning.state.events.count) { _, _ in refreshCalendar() }
        .onChange(of: learning.state.preferences.dailyMinutes) { _, _ in refreshCalendar() }
        .onChange(of: learning.state.preferences.examDate) { _, _ in refreshCalendar() }
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: openSidebar) { SidebarGlyph() }.accessibilityLabel("打开侧栏")
            }
            ToolbarItem(placement: .principal) { SealStamp(size: 30) }
            ToolbarItem(placement: .topBarTrailing) {
                Button { focus = true } label: { Image(systemName: "timer") }.accessibilityLabel("开始学习计时")
            }
        }
        .sheet(isPresented: $focus) { FocusView() }
        .sheet(isPresented: $manual) { ManualStudyView() }
        .sheet(isPresented: $showCalendar) {
            NavigationStack {
                DatePicker("学习日期", selection: $date, in: ...Date(), displayedComponents: .date).datePickerStyle(.graphical).padding()
                    .navigationTitle("选择日期").toolbar { ToolbarItem(placement: .confirmationAction) { Button("完成") { showCalendar = false } } }
            }.presentationDetents([.medium])
        }
    }

    private var dateAndCountdown: some View {
        HStack(alignment: .firstTextBaseline) {
            HStack(spacing: 4) {
                Button { shiftDay(-1) } label: { Image(systemName: "chevron.left").frame(width: 24, height: 30) }.accessibilityLabel("前一天")
                Button { showCalendar = true } label: { Text(dateLabel).font(TypeScale.label); Image(systemName: "chevron.down").font(.system(size: 9)) }
                    .buttonStyle(.plain).accessibilityIdentifier("day-picker")
                Button { shiftDay(1) } label: { Image(systemName: "chevron.right").frame(width: 24, height: 30) }
                    .disabled(Calendar.current.isDateInToday(date))
                    .opacity(Calendar.current.isDateInToday(date) ? 0.3 : 1)
                    .accessibilityLabel("后一天")
            }.foregroundStyle(Ink.ink3)
            Spacer()
            HStack(alignment: .firstTextBaseline, spacing: 4) {
                Text("距初试").font(TypeScale.serif(14)).foregroundStyle(Ink.ink2)
                Text("\(StudyPreferences.daysUntil(learning.state.preferences.examDate, from: tick))")
                    .font(TypeScale.serif(22)).foregroundStyle(Ink.ink).monospacedDigit().accessibilityIdentifier("exam-countdown")
                Text("天").font(TypeScale.serif(14)).foregroundStyle(Ink.ink2)
            }
        }
    }

    private func subjectLink(_ subject: StudySubject, value: String, divider: Bool = true) -> some View {
        NavigationLink { SubjectHub(subject: subject) } label: {
            InkRow(title: subject.title, value: value, chevron: false, divider: divider)
        }.buttonStyle(.plain)
    }

    private var dayTitle: String {
        (Calendar.current.isDateInToday(date) ? "今天学了 " : "\(date.formatted(.dateTime.month().day()))学了 ") + studyDuration(summary.seconds)
    }
    private var dateLabel: String {
        let formatter = DateFormatter(); formatter.locale = Locale(identifier: "zh_CN"); formatter.dateFormat = "M月d日 · EEEE"
        return formatter.string(from: date)
    }
    private var summaryText: String {
        "累计学习 \(studyDuration(summary.seconds))，新学 \(summary.newWords) 个单词，复习 \(summary.reviewedWords) 次单词及 \(summary.cardReviews) 次知识卡。完成 \(summary.answers) 次作答，其中答对 \(summary.correct) 次。"
    }
    private var reviewPrompt: String {
        let facts = events.prefix(60).map { "\($0.subject.title)：\($0.title) · \($0.detail)" }.joined(separator: "\n")
        return "请根据下面已记录的学习事实，帮我复盘 \(date.formatted(date: .numeric, time: .omitted)) 的学习。输出：完成了什么、需要巩固什么、下一次的具体建议。不猜测没有记录的学习内容，不把做过等同于掌握。\n专注时间：\(studyDuration(summary.seconds))\n新词：\(summary.newWords)，复习单词：\(summary.reviewedWords)，作答：\(summary.answers)，答对：\(summary.correct)\n\(facts)"
    }
    private func shiftDay(_ amount: Int) {
        if let next = Calendar.current.date(byAdding: .day, value: amount, to: date), next <= Date() { date = next }
    }
    private func refreshCalendar() {
        calendarDays = PrepCalendar.days(today: tick, examDate: learning.state.preferences.examDate,
                                         goalMinutes: learning.state.preferences.dailyMinutes) { day in
            learning.summary(on: day, at: tick).seconds
        }
    }
}

@MainActor
struct TimelineEventRow: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let event: LearningEvent
    var body: some View {
        Group {
            if event.kind == .assistant, let id = event.referenceID,
               let thread = chat.threads.first(where: { $0.messages.contains(where: { $0.id.uuidString == id }) }) {
                NavigationLink { StudyAssistantView(threadID: thread.id) } label: { row }
            } else if let id = event.readingPassageID, learning.readingPassages.contains(where: { $0.id == id }) {
                NavigationLink { ReadingPracticeView(passageID: id, initialQuestionID: event.readingQuestionID, initialAttemptID: event.readingAttemptID) } label: { row }
            } else if let id = event.referenceID, let card = learning.state.cards.first(where: { $0.id == id }) {
                NavigationLink { CardDetailView(cardID: card.id) } label: { row }
            } else if let id = event.referenceID, let q = learning.state.questions.first(where: { $0.id == id }) {
                NavigationLink { QuestionPracticeView(questions: [q]) } label: { row }
            } else if let id = event.referenceID, let r = learning.state.resources.first(where: { $0.id == id }) {
                NavigationLink { ResourceDetailView(resourceID: r.id) } label: { row }
            } else { row }
        }.buttonStyle(.plain)
    }
    private var row: some View {
        HStack(alignment: .top, spacing: Space.m) {
            Text(event.start.formatted(.dateTime.hour().minute()))
                .font(TypeScale.caption).foregroundStyle(Ink.ink3).monospacedDigit().frame(width: 38, alignment: .leading)
            VStack(alignment: .leading, spacing: 5) {
                Text(event.title).font(.system(size: 15)).foregroundStyle(Ink.ink).lineLimit(2)
                Text(event.kind == .focus ? "\(studyDuration(event.end.timeIntervalSince(event.start))) · \(event.detail)" : event.detail)
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3)
            }
            Spacer(minLength: 0)
        }.padding(.vertical, 7)
    }
}

@MainActor
struct FocusBanner: View {
    @EnvironmentObject private var learning: LearningStore
    var open: () -> Void
    var body: some View {
        if let run = learning.state.focus {
            Button(action: open) {
                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    HStack { Image(systemName: run.isRest ? "cup.and.saucer" : "timer"); Text(run.label).lineLimit(1); Spacer(); Text(clock(run, at: timeline.date)).monospacedDigit(); Image(systemName: run.isPaused ? "pause.fill" : "chevron.right").font(.caption) }
                        .font(.subheadline).padding(16).glassEffect(.regular.interactive(), in: .capsule)
                }
            }.buttonStyle(.plain)
        }
    }
    private func clock(_ run: FocusRun, at now: Date) -> String {
        let time = Int(run.targetSeconds.map { max(0, $0 - run.total(at: now)) } ?? run.total(at: now))
        return String(format: "%02d:%02d", time / 60, time % 60)
    }
}

@MainActor
struct FocusView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State private var subject: StudySubject = .english
    @State private var label = ""
    @State private var countdown = false
    @State private var minutes = 25
    var body: some View {
        NavigationStack {
            Group {
                if let run = learning.state.focus {
                    TimelineView(.periodic(from: .now, by: 1)) { timeline in
                        let elapsed = run.total(at: timeline.date)
                        let seconds = Int(run.targetSeconds.map { max(0, $0 - elapsed) } ?? elapsed)
                        VStack(spacing: 26) {
                            Spacer()
                            Text(run.isRest ? "休息一下" : run.subject.title).font(TypeScale.label).foregroundStyle(Ink.ink3)
                            Text(run.label).font(TypeScale.serif(25, relativeTo: .title2))
                            Text(String(format: "%02d:%02d", seconds / 60, seconds % 60)).font(.system(size: 66, weight: .light, design: .rounded)).monospacedDigit().accessibilityIdentifier("focus-clock")
                            if let target = run.targetSeconds, elapsed >= target { Text("这一段已完成").foregroundStyle(Ink.ink3) }
                            HStack(spacing: 20) {
                                Button(run.isPaused ? "继续" : "暂停") { if run.isPaused { learning.resumeFocus() } else { learning.pauseFocus() } }
                                    .buttonStyle(.inkGlass).disabled(run.targetSeconds.map { elapsed >= $0 } ?? false)
                                Button("结束并保存") { learning.finishFocus(); dismiss() }.buttonStyle(.inkPrimary)
                            }
                            if !run.isRest {
                                Button("结束学习，休息 \(learning.state.preferences.restMinutes) 分钟") {
                                    let subject = run.subject; learning.finishFocus()
                                    learning.startFocus(subject: subject, label: "休息", minutes: learning.state.preferences.restMinutes, rest: true)
                                }.font(TypeScale.caption).foregroundStyle(Ink.ink3)
                            }
                            Spacer()
                            Text(run.isRest ? "休息不计入学习时长" : "暂停的时间不计入学习时长").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                        }.padding(25).frame(maxWidth: .infinity)
                            .onChange(of: seconds) { _, _ in if let target = run.targetSeconds, elapsed >= target, !run.isPaused { learning.pauseFocus(at: timeline.date) } }
                    }
                } else {
                    Form {
                        Section("这次学什么") {
                            Picker("科目", selection: $subject) { ForEach(StudySubject.allCases) { Text($0.title).tag($0) } }
                            TextField("内容，例如：阅读第 2 篇", text: $label)
                        }
                        Section("计时方式") {
                            Toggle("番茄倒计时", isOn: $countdown)
                            if countdown { InkStepper(title: "学习", value: $minutes, range: 1...180) { "\($0) 分钟" } }
                            else { Text("自由计时，学完后结束。").foregroundStyle(Ink.ink3) }
                        }
                        Button("开始学习") { learning.startFocus(subject: subject, label: label, minutes: countdown ? minutes : nil) }.buttonStyle(.inkPrimary).accessibilityIdentifier("focus-start")
                    }.scrollContentBackground(.hidden).listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
                }
            }.background(AppBackground()).navigationTitle("专注").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("收起") { dismiss() } } }
        }.onAppear { subject = learning.state.preferences.preferredSubject; minutes = learning.state.preferences.focusMinutes }
    }
}

@MainActor
struct ManualStudyView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State private var subject: StudySubject = .english
    @State private var title = ""
    @State private var end = Date()
    @State private var minutes = 30
    var body: some View {
        NavigationStack { Form {
            Picker("科目", selection: $subject) { ForEach(StudySubject.allCases) { Text($0.title).tag($0) } }
            TextField("学习内容", text: $title)
            DatePicker("结束时间", selection: $end, in: ...Date())
            InkStepper(title: "学习", value: $minutes, range: 1...600, step: 5) { "\($0) 分钟" }
            Text("补记纸质书或线下学习；与已记录时段重叠时会提示调整。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
        }.navigationTitle("补记学习").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") { learning.addManual(subject: subject, title: title, start: end.addingTimeInterval(-Double(minutes)*60), minutes: minutes); dismiss() } }
        }.scrollContentBackground(.hidden).background(AppBackground()).listRowBackground(Color.clear).listRowSeparatorTint(Ink.line) }
    }
}
