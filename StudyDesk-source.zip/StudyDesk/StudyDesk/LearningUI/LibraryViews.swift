import SwiftUI
import PDFKit
import UniformTypeIdentifiers

@MainActor
struct StudyLibrary: View {
    @EnvironmentObject private var learning: LearningStore
    var initialSubject: StudySubject? = nil
    @State private var subject: StudySubject? = nil
    @State private var importSubject: StudySubject = .english
    @State private var importing = false
    @State private var asCards = false
    @State private var search = ""
    @State private var addingNote = false
    private var filtered: [StudyResource] {
        learning.state.resources.filter { (subject == nil || $0.subject == subject) && (search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.note.localizedCaseInsensitiveContains(search)) }
    }
    var body: some View {
        InkPage(spacing: 0) {
            InkTabs(items: [(Optional<StudySubject>.none, "全部"), (.some(.english), "英语一"), (.some(.politics), "政治"), (.some(.history), "313 历史学")], selection: $subject)
            InkSectionHeader(title: "我的资料").padding(.top, Space.section)
            let local = filtered.filter { $0.fileName != nil || $0.url == nil }
            ForEach(local) { resource in resourceRow(resource, canDelete: true) }
            if local.isEmpty {
                Text("点右上角导入 PDF、图片、笔记或题包。")
                    .font(TypeScale.note).foregroundStyle(Ink.ink2).padding(.vertical, Space.xl)
            }
            InkSectionHeader(title: "资料来源").padding(.top, Space.section)
            ForEach(filtered.filter { $0.url != nil && $0.fileName == nil }) { resource in resourceRow(resource) }
            Text("词表：UTF-8 CSV 或 TSV，前两列为正面、背面，第三列可填分组。JSON 题包可包含 readings 阅读文章与配套题。来源入口需联网，已导入资料可以离线阅读。")
                .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(4).padding(.top, Space.section)
        }
            .searchable(text: $search, prompt: "搜索资料和笔记").navigationTitle("资料").navigationBarTitleDisplayMode(.large)
            .toolbar { ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    ForEach(StudySubject.allCases) { item in
                        Menu(item.title) {
                            Button("导入 PDF、图片或文字") { startImport(item, cards: false) }
                            Button("导入词表或题包") { startImport(item, cards: true) }
                        }
                    }
                    Button("新建笔记") { addingNote = true }
                } label: { Image(systemName: "plus") }.accessibilityLabel("导入学习资料")
            } }
            .overlay { if learning.busy { ProgressView("正在导入与识别…").padding(24).glassEffect(.regular, in: .rect(cornerRadius: 24)) } }
            .fileImporter(isPresented: $importing, allowedContentTypes: asCards ? [.commaSeparatedText, .tabSeparatedText, .plainText, .json] : [.pdf, .image, .plainText, .json]) { result in
                do { let url = try result.get(); Task { await learning.importFile(url, subject: importSubject, asCards: asCards) } }
                catch { learning.error = error.localizedDescription }
            }
            .sheet(isPresented: $addingNote) { NewStudyNote(subject: subject ?? .english) }
            .onAppear { if let initialSubject { subject = initialSubject } }
    }
    /// 等菜单收起后再弹出文件选择器；菜单还在消失时立即弹出，选择器可能点了没反应。
    private func startImport(_ item: StudySubject, cards: Bool) {
        importSubject = item; asCards = cards
        Task { @MainActor in try? await Task.sleep(for: .milliseconds(350)); importing = true }
    }
    private func resourceRow(_ resource: StudyResource, canDelete: Bool = false) -> some View {
        NavigationLink { ResourceDetailView(resourceID: resource.id) } label: {
            VStack(spacing: 0) {
                HStack(alignment: .top, spacing: Space.l) {
                    Text(resourceType(resource)).font(TypeScale.serif(11)).foregroundStyle(Ink.ink3).frame(width: 40, alignment: .leading)
                    VStack(alignment: .leading, spacing: 7) {
                        Text(resource.title).font(TypeScale.serif(18)).foregroundStyle(Ink.ink).lineLimit(2)
                        Text(resource.subject.title + " · " + resource.source).font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(2)
                        if !resource.note.isEmpty { Text(resource.note).font(TypeScale.serif(14)).foregroundStyle(Ink.ink2).lineLimit(2) }
                    }
                    Spacer(minLength: 0)
                }.padding(.vertical, 18)
                InkRule()
            }.contentShape(Rectangle())
        }.buttonStyle(.plain)
            .swipeActions { if canDelete { Button("删除", role: .destructive) { learning.deleteResource(resource) } } }
            .contextMenu { if canDelete { Button("删除资料", role: .destructive) { learning.deleteResource(resource) } } }
    }
    private func resourceType(_ resource: StudyResource) -> String {
        if resource.fileName?.lowercased().hasSuffix(".pdf") == true { return "PDF" }
        if let name = resource.fileName?.lowercased(), [".jpg", ".jpeg", ".png", ".heic"].contains(where: { name.hasSuffix($0) }) { return "图片" }
        if resource.url != nil { return "来源" }
        if resource.text.isEmpty { return "笔记" }
        return "资料"
    }
}

@MainActor
struct ResourceDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let resourceID: String
    @State private var note = ""
    @State private var selectedText = ""
    @State private var assistant = false
    @State private var editingText = false
    @State private var askContext: StudyAskContext?
    @State private var wordDraft: ReadingWordDraft?
    private var resource: StudyResource? { learning.state.resources.first { $0.id == resourceID } }
    var body: some View {
        InkPage {
            if let resource {
                VStack(alignment: .leading, spacing: 22) {
                    Text(resource.title).font(TypeScale.serif(28, relativeTo: .title))
                    Text(resource.source).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    if let raw = resource.url, let url = URL(string: raw), ["https", "http"].contains(url.scheme ?? "") {
                        Link(destination: url) { Label("打开来源", systemImage: "arrow.up.right.square") }.buttonStyle(.inkGlass)
                    }
                    if let url = learning.fileURL(resource) {
                        if url.pathExtension.lowercased() == "pdf" {
                            NavigationLink { StudyPDFReader(resourceID: resourceID) } label: { Label("阅读 PDF · 第 \(resource.page + 1) 页", systemImage: "doc.richtext") }.buttonStyle(.inkPrimary)
                        } else if let image = UIImage(contentsOfFile: url.path) {
                            Image(uiImage: image).resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 18))
                        }
                        ShareLink(item: url) { Label("导出原文件", systemImage: "square.and.arrow.up") }.font(TypeScale.serif(12, relativeTo: .caption))
                    }
                    if !resource.text.isEmpty {
                        HStack { Text("文字内容").font(TypeScale.serif(17, relativeTo: .headline).weight(.semibold)); Spacer(); Button("校正文字") { selectedText = resource.text; editingText = true }.font(TypeScale.serif(12, relativeTo: .caption)) }
                        SelectableStudyText(text: String(resource.text.prefix(18000)), identifier: "selectable-resource-text", onCollect: collectionAction(resource)) { quote in
                            askContext = resourceContext(resource, quote: quote)
                        }
                        if resource.text.count > 18000 { Text("此处展示前 18,000 字。完整 PDF 请打开原文阅读；提问可粘贴选中的段落。").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        InkSectionHeader(title: "学习笔记")
                        InkRule()
                        TextEditor(text: $note).frame(minHeight: 120).scrollContentBackground(.hidden)
                        InkRule()
                        Button("保存笔记") { var r = resource; r.note = note; learning.updateResource(r, log: true) }.buttonStyle(.inkGlass)
                    }
                    Button("结合这份资料问 AI") {
                        askContext = resourceContext(resource, quote: "")
                    }.buttonStyle(.inkGlass).disabled(resource.text.isEmpty && note.isEmpty)
                }
            }
        }.navigationTitle("资料").navigationBarTitleDisplayMode(.inline)
            .onAppear { note = resource?.note ?? "" }
            .sheet(isPresented: $editingText) {
                NavigationStack { TextEditor(text: $selectedText).padding().navigationTitle("校正识别文字").toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("取消") { editingText = false } }
                    ToolbarItem(placement: .confirmationAction) { Button("保存") { if var r = resource { r.text = selectedText; learning.updateResource(r) }; editingText = false } }
                } }
            }
            .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .sheet(item: $wordDraft) { ReadingWordEditor(term: $0.term, example: $0.example) }
    }
    private func resourceContext(_ r: StudyResource, quote: String) -> StudyAskContext {
        StudyAskContext(referenceID: "resource:" + r.id, subject: r.subject, title: r.title, quote: quote,
                        background: r.text.isEmpty ? note : r.text, source: r.source)
    }
    private func collectionAction(_ resource: StudyResource) -> ((String, String) -> Void)? {
        guard resource.subject == .english else { return nil }
        return { term, context in wordDraft = ReadingWordDraft(term: term, example: ReadingWordExample(passageID: "", passageTitle: resource.title, quote: context, resourceID: resource.id)) }
    }
}

@MainActor
struct NewStudyNote: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State var subject: StudySubject
    @State private var title = ""
    @State private var text = ""
    var body: some View {
        NavigationStack { Form {
            Picker("科目", selection: $subject) { ForEach(StudySubject.allCases) { Text($0.title).tag($0) } }
            TextField("笔记标题", text: $title)
            TextEditor(text: $text).frame(minHeight: 300)
        }.navigationTitle("新建笔记").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") { learning.updateResource(StudyResource(title: title, subject: subject, text: text, source: "个人笔记"), log: true); dismiss() }.disabled(title.isEmpty || text.isEmpty) }
        }.scrollContentBackground(.hidden).background(AppBackground()).listRowBackground(Color.clear).listRowSeparatorTint(Ink.line) }
    }
}

@MainActor
struct StudyPDFReader: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let resourceID: String
    var initialPageOverride: Int? = nil
    @State private var selection = ""
    @State private var page = 0
    @State private var pageText = ""
    @State private var assistant = false
    @State private var recognizing = false
    @State private var askContext: StudyAskContext?
    @State private var wordDraft: ReadingWordDraft?
    private var resource: StudyResource? { learning.state.resources.first { $0.id == resourceID } }
    var body: some View {
        Group {
            if let r = resource, let url = learning.fileURL(r) {
                NativePDFReader(url: url, initialPage: initialPageOverride ?? r.page, pageChanged: { index, text in page = index; pageText = text }, selectionChanged: { selection = $0 })
                    .overlay(alignment: .topTrailing) { Text("第 \(page + 1) 页").font(TypeScale.serif(12, relativeTo: .caption)).padding(10).glassEffect(.regular, in: .capsule).padding(12) }
                    .overlay(alignment: .bottom) {
                        if !selection.isEmpty {
                            HStack {
                            Button { ask(r, quote: selection) } label: { Label("问选中的内容", systemImage: "sparkles") }
                                .buttonStyle(.inkPrimary).padding(16)
                            if r.subject == .english {
                                Button("加入生词本") { wordDraft = ReadingWordDraft(term: selection, example: ReadingWordExample(passageID: "", passageTitle: r.title, quote: selection, resourceID: r.id, page: page)) }
                                    .buttonStyle(.inkGlass).padding(.trailing, 16)
                            }
                            }
                        }
                    }
            }
        }.navigationTitle(resource?.title ?? "PDF").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .bottomBar) {
                Button { recognizePage() } label: { Label(recognizing ? "识别中" : "识别本页", systemImage: "text.viewfinder") }.disabled(recognizing)
                Spacer()
                Button {
                    guard let r = resource else { return }
                    let excerpt = selection.isEmpty ? pageText : selection
                    ask(r, quote: excerpt)
                } label: { Label(selection.isEmpty ? "问本页" : "问选中内容", systemImage: "sparkles") }.disabled(selection.isEmpty && pageText.isEmpty)
            } }
            .onDisappear { if var r = resource { r.page = page; learning.updateResource(r) } }
            .sheet(item: $wordDraft) { ReadingWordEditor(term: $0.term, example: $0.example) }
            .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
    }
    private func ask(_ r: StudyResource, quote: String) {
        askContext = StudyAskContext(referenceID: "pdf:" + r.id + ":page:\(page)", subject: r.subject,
                                     title: r.title + " · 第 \(page+1) 页", quote: quote, background: pageText,
                                     source: r.source + " · 第 \(page+1) 页")
    }
    private func recognizePage() {
        guard let r = resource, let url = learning.fileURL(r), let doc = PDFDocument(url: url), let current = doc.page(at: page),
              let data = current.thumbnail(of: CGSize(width: 1800, height: 2400), for: .mediaBox).pngData() else { return }
        recognizing = true; let pageIndex = page
        Task {
            defer { recognizing = false }
            do {
                let text = try await Task.detached { try LearningStore.extractText(data, ext: "png") }.value
                guard !text.isEmpty else { learning.error = "这页没有识别到文字，请检查清晰度。"; return }
                pageText = text
                if var updated = resource { updated.text += "\n\n[第 \(pageIndex+1) 页 · OCR]\n" + text; learning.updateResource(updated) }
                learning.notice = "本页文字已保存，可以提问或返回资料页校正。"
            } catch { learning.error = error.localizedDescription }
        }
    }
}

struct NativePDFReader: UIViewRepresentable {
    let url: URL
    let initialPage: Int
    var pageChanged: (Int, String) -> Void
    var selectionChanged: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> PDFView {
        let view = PDFView(); view.autoScales = true; view.displayDirection = .vertical
        view.displayMode = .singlePageContinuous; view.backgroundColor = UIColor(white: 0.06, alpha: 1)
        view.document = PDFDocument(url: url)
        if let doc = view.document, let page = doc.page(at: min(max(0, initialPage), max(0, doc.pageCount-1))) { view.go(to: page) }
        context.coordinator.connect(view)
        DispatchQueue.main.async { context.coordinator.updatePage(view) }
        return view
    }
    func updateUIView(_ view: PDFView, context: Context) { context.coordinator.parent = self }
    final class Coordinator: NSObject {
        var parent: NativePDFReader
        var observers: [NSObjectProtocol] = []
        init(_ parent: NativePDFReader) { self.parent = parent }
        func connect(_ view: PDFView) {
            observers.append(NotificationCenter.default.addObserver(forName: .PDFViewPageChanged, object: view, queue: .main) { [weak self, weak view] _ in if let view { self?.updatePage(view) } })
            observers.append(NotificationCenter.default.addObserver(forName: .PDFViewSelectionChanged, object: view, queue: .main) { [weak self, weak view] _ in self?.parent.selectionChanged(view?.currentSelection?.string ?? "") })
        }
        func updatePage(_ view: PDFView) { if let page = view.currentPage, let doc = view.document { parent.pageChanged(doc.index(for: page), page.string ?? "") } }
        deinit { for token in observers { NotificationCenter.default.removeObserver(token) } }
    }
}
