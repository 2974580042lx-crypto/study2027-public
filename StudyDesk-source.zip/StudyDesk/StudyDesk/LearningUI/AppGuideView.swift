import SwiftUI

extension AppGuide {
    /// 随 App 打包的使用说明原文
    static let bundledText: String = {
        guard let url = Bundle.main.url(forResource: "app-guide", withExtension: "md"),
              let text = try? String(contentsOf: url, encoding: .utf8) else { return "" }
        return text
    }()
}

/// 设置里的「使用说明」：和 AI 读的是同一份文字
struct AppGuideView: View {
    private let blocks = AppGuide.blocks(AppGuide.bundledText)
    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                ForEach(Array(blocks.enumerated()), id: \.offset) { _, block in
                    switch block {
                    case .title(let t):
                        Text(t).font(TypeScale.serif(29, relativeTo: .title)).padding(.top, Space.xl).padding(.bottom, Space.s)
                    case .heading(let t):
                        Text(t).font(TypeScale.serif(19, relativeTo: .title3).weight(.semibold)).foregroundStyle(Ink.ink)
                            .padding(.top, Space.section).padding(.bottom, Space.s)
                    case .bullet(let t, let indent):
                        HStack(alignment: .firstTextBaseline, spacing: Space.s) {
                            Text(indent > 0 ? "◦" : "·").foregroundStyle(Ink.seal)
                            Text(t).foregroundStyle(Ink.ink2).lineSpacing(5)
                        }.font(TypeScale.serif(15)).padding(.leading, CGFloat(indent) * 18).padding(.vertical, 3)
                    case .numbered(let n, let t):
                        HStack(alignment: .firstTextBaseline, spacing: Space.s) {
                            Text(n + ".").foregroundStyle(Ink.ink3).monospacedDigit()
                            Text(t).foregroundStyle(Ink.ink2).lineSpacing(5)
                        }.font(TypeScale.serif(15)).padding(.vertical, 3)
                    case .paragraph(let t):
                        Text(t).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).padding(.vertical, 3)
                    }
                }
                if blocks.isEmpty { ContentUnavailableView("没有找到使用说明", systemImage: "book") }
            }
            .textSelection(.enabled)
        }
        .navigationTitle("使用说明").navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("app-guide")
    }
}
