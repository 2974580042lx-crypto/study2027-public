import SwiftUI
import UniformTypeIdentifiers

@MainActor
struct ReadingLibraryView: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var search = ""
    @State private var importing = false
    private var passages: [ReadingPassage] {
        learning.readingPassages.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.label.localizedCaseInsensitiveContains(search) }
            .sorted { ($0.year ?? 0) == ($1.year ?? 0) ? ($0.textNumber ?? 0) < ($1.textNumber ?? 0) : ($0.year ?? 0) > ($1.year ?? 0) }
    }
    var body: some View {
        List {
            Section {
                Button { importing = true } label: { Label("导入阅读题包", systemImage: "square.and.arrow.down") }
                NavigationLink { ReadingWordListView() } label: { Label("阅读生词本 · \(learning.readingWords.count)", systemImage: "character.book.closed") }
            }
            Section("我的阅读") {
                ForEach(passages.filter { !$0.isExample }) { row($0) }
                if passages.allSatisfy(\.isExample) { Text("导入包含原文、题目与来源的 JSON 题包后，会按年份和篇目显示。PDF 仍可在资料页阅读和提问。").font(TypeScale.note).foregroundStyle(Ink.ink2) }
            }
            Section("功能示例 · 非历年真题") { ForEach(passages.filter(\.isExample)) { row($0) } }
        }.scrollContentBackground(.hidden).background(AppBackground()).listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
            .navigationTitle("英语阅读").searchable(text: $search, prompt: "年份、篇目或标题")
            .onAppear { learning.ensureReadingExample() }
            .sheet(isPresented: $importing) {
                DocumentPicker(types: [.json]) { url in
                    importing = false
                    Task { await learning.importFile(url, subject: .english, asCards: true) }
                } onCancel: { importing = false }.ignoresSafeArea()
            }
    }
    private func row(_ passage: ReadingPassage) -> some View {
        NavigationLink { ReadingPracticeView(passageID: passage.id) } label: {
            VStack(alignment: .leading, spacing: 8) {
                Text(passage.title).font(TypeScale.subject)
                Text(passage.label + " · \(passage.questions.count) 题").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                if let attempt = learning.state.readingAttempt(for: passage.id) {
                    Text(attempt.submittedAt == nil ? "继续作答 · 已选 \(attempt.selected.count)/\(passage.questions.count)" : "已完成 · 核验题答对 \(attempt.correct ?? 0)/\(attempt.graded ?? 0)")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
            }.padding(.vertical, 7)
        }.accessibilityIdentifier("reading-" + passage.id)
    }
}

struct ReadingWordDraft: Identifiable {
    let id = UUID()
    let term: String
    let example: ReadingWordExample
}

@MainActor
struct ReadingPracticeView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.scenePhase) private var scenePhase
    let passageID: String
    var initialQuestionID: String? = nil
    var initialAttemptID: UUID? = nil
    @State private var attemptID: UUID?
    @State private var lastParagraph = 0
    @State private var initialized = false
    @State private var askContext: StudyAskContext?
    @State private var wordDraft: ReadingWordDraft?
    @State private var showingQuestions = false
    @State private var pageWidth: CGFloat = 0
    /// 窗口够宽（如 iPad 横屏）时原文和题目左右分栏，各自滚动，像考场试卷；
    /// iPad 竖屏分两栏每栏太窄，仍用单栏
    private var split: Bool { pageWidth >= 960 }
    private var passage: ReadingPassage? { learning.readingPassages.first { $0.id == passageID } }
    private var attempt: ReadingAttempt? { learning.state.readingAttempts?.first { $0.id == attemptID } }
    private var submitted: Bool { attempt?.submittedAt != nil }
    var body: some View {
        ScrollViewReader { proxy in
            Group {
                if let passage {
                    if split {
                        HStack(spacing: 0) {
                            ScrollView {
                                LazyVStack(alignment: .leading, spacing: 25) { passageColumn(passage) }
                                    .frame(maxWidth: 700, alignment: .leading)
                                    .padding(.horizontal, Space.xxl).padding(.top, Space.l).padding(.bottom, 120)
                                    .frame(maxWidth: .infinity)
                            }.coordinateSpace(name: "reading-scroll")
                            Rectangle().fill(Ink.line).frame(width: 1).padding(.vertical, Space.l)
                            ScrollView {
                                LazyVStack(alignment: .leading, spacing: 25) { questionColumn(passage) }
                                    .frame(maxWidth: 620, alignment: .leading)
                                    .padding(.horizontal, Space.xxl).padding(.top, Space.l).padding(.bottom, 120)
                                    .frame(maxWidth: .infinity)
                            }
                        }
                    } else {
                        ScrollView {
                            LazyVStack(alignment: .leading, spacing: 25) {
                                passageColumn(passage)
                                InkRule().padding(.vertical, 12)
                                questionColumn(passage)
                            }
                            .frame(maxWidth: 720, alignment: .leading).frame(maxWidth: .infinity)
                            .padding(.horizontal, Space.xl).padding(.top, Space.l).padding(.bottom, Space.xxl)
                        }.coordinateSpace(name: "reading-scroll")
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .onGeometryChange(for: CGFloat.self, of: { $0.size.width }) { pageWidth = $0 }
            .background(AppBackground())
                .inkBottomBar {
                    if let passage {
                        HStack(spacing: Space.m) {
                            VStack(alignment: .leading, spacing: 7) {
                                GeometryReader { geo in
                                    ZStack(alignment: .leading) {
                                        Capsule().fill(Ink.line).frame(height: 2)
                                        Capsule().fill(Ink.ink2).frame(width: geo.size.width * readingProgress(passage), height: 2)
                                    }
                                }.frame(width: 120, height: 2)
                                Text("读到第 \(lastParagraph + 1) 段 · 收了 \(learning.readingWords.filter { word in word.examples.contains { $0.passageID == passage.id } }.count) 个词")
                                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(1)
                            }
                            Spacer(minLength: 0)
                            if submitted {
                                Text("答对 \(attempt?.correct ?? 0)/\(attempt?.graded ?? 0)").font(TypeScale.serif(14).weight(.semibold)).foregroundStyle(Ink.ink).accessibilityIdentifier("reading-score")
                            } else if showingQuestions || split {
                                Button("提交") { if let attemptID { _ = learning.finishReading(attemptID) } }
                                    .buttonStyle(.inkPrimary)
                                    .disabled(passage.questions.isEmpty || attempt?.selected.count != passage.questions.count)
                                    .accessibilityIdentifier("reading-submit")
                            } else {
                                Button("去答题") { showingQuestions = true; withAnimation { proxy.scrollTo("reading-questions", anchor: .top) } }
                                    .buttonStyle(.inkPrimary)
                            }
                        }.padding(.horizontal, Space.l).frame(height: 60)
                            .glassEffect(.regular.interactive(), in: .rect(cornerRadius: 30))
                    }
                }
                .onAppear {
                    if !initialized {
                        if let initialAttemptID, learning.state.readingAttempts?.contains(where: { $0.id == initialAttemptID && $0.passageID == passageID }) == true { attemptID = initialAttemptID }
                        else { attemptID = learning.openReading(passageID) }
                        initialized = true
                        lastParagraph = attempt?.paragraph ?? 0
                        if let initialQuestionID { showingQuestions = true; DispatchQueue.main.async { proxy.scrollTo("reading-target-" + initialQuestionID, anchor: .top) } }
                        else if lastParagraph > 0 { DispatchQueue.main.async { proxy.scrollTo("reading-paragraph-\(lastParagraph)", anchor: .top) } }
                    }
                }
                .onChange(of: submitted) { _, value in
                    if value { DispatchQueue.main.async { withAnimation { proxy.scrollTo("reading-questions", anchor: .top) } } }
                }
                .toolbar {
                    if !split { ToolbarItem(placement: .principal) {
                        HStack(spacing: 2) {
                            Button { showingQuestions = false; withAnimation { proxy.scrollTo("reading-paragraph-\(lastParagraph)", anchor: .top) } } label: {
                                Text("原文").padding(.horizontal, 11).frame(height: 28)
                                    .background(!showingQuestions ? Ink.raised : Color.clear, in: Capsule())
                            }
                            Button { showingQuestions = true; withAnimation { proxy.scrollTo("reading-questions", anchor: .top) } } label: {
                                Text("题目").padding(.horizontal, 11).frame(height: 28)
                                    .background(showingQuestions ? Ink.raised : Color.clear, in: Capsule())
                            }
                                .accessibilityIdentifier("reading-jump-questions")
                        }.font(TypeScale.serif(13).weight(.medium)).buttonStyle(.plain).padding(5)
                            .glassEffect(.regular.interactive(), in: .capsule)
                    } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Menu {
                            Button("收录生词") { if let passage { collect("", paragraph: passage.paragraphs[min(lastParagraph, passage.paragraphs.count - 1)], passage: passage) } }
                            NavigationLink("打开生词本") { ReadingWordListView() }
                            if submitted {
                                Button("再做一遍") { attemptID = learning.openReading(passageID, restart: true); lastParagraph = 0; withAnimation { proxy.scrollTo("reading-top", anchor: .top) } }
                            }
                        } label: { Image(systemName: "ellipsis.circle") }.accessibilityLabel("阅读操作")
                    }
                }
        }.navigationTitle("阅读").navigationBarTitleDisplayMode(.inline).toolbar(.hidden, for: .tabBar)
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .sheet(item: $wordDraft) { ReadingWordEditor(term: $0.term, example: $0.example) }
            .onDisappear { if let attemptID { learning.rememberReadingPosition(attemptID, paragraph: lastParagraph) } }
            .onChange(of: scenePhase) { _, phase in if phase != .active, let attemptID { learning.rememberReadingPosition(attemptID, paragraph: lastParagraph) } }
    }
    @ViewBuilder private func passageColumn(_ passage: ReadingPassage) -> some View {
            VStack(alignment: .leading, spacing: 8) {
                Text(passage.label).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                Text(passage.title).font(TypeScale.serif(28, relativeTo: .title))
                Text(passage.source).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                sourceLink(passage.sourceURL)
            }.id("reading-top")
            ForEach(Array(passage.paragraphs.enumerated()), id: \.offset) { index, paragraph in
                HStack(alignment: .top, spacing: Space.s) {
                    Text("\(index + 1)").font(.system(size: 11).monospacedDigit()).foregroundStyle(Ink.ink3).frame(width: 12, alignment: .leading).padding(.top, 3)
                    SelectableStudyText(text: paragraph, identifier: "reading-paragraph-\(index)", onCollect: { term, context in collect(term, paragraph: context, passage: passage) }) { quote in
                        askContext = .reading(passage, quote: quote, attempt: attempt)
                    }
                }
                .padding(.bottom, Space.s).id("reading-paragraph-\(index)")
                    .onGeometryChange(for: CGRect.self, of: { $0.frame(in: .named("reading-scroll")) }) { frame in
                        if frame.minY <= 30 && frame.maxY > 30 { lastParagraph = index }
                    }
            }
    }
    @ViewBuilder private func questionColumn(_ passage: ReadingPassage) -> some View {
            VStack(alignment: .leading, spacing: 12) {
                Text("配套题目").font(TypeScale.subject)
                if submitted {
                    Text("答对 \(attempt?.correct ?? 0)/\(attempt?.graded ?? 0) 道已核验题").font(TypeScale.label).foregroundStyle(Ink.ink2)
                    if passage.questions.contains(where: { !$0.canGrade }) { Text("答案待核验的题目只记录作答，不计入对错。").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                }
            }.id("reading-questions")
            ForEach(passage.questions) { questionView($0, passage: passage).id("reading-target-" + $0.id) }
            if passage.questions.isEmpty { Text("这份材料暂未包含配套题目，可以先阅读、收词或问 AI。").foregroundStyle(Ink.ink2) }
    }
    private func collect(_ term: String, paragraph: String, passage: ReadingPassage) {
        wordDraft = ReadingWordDraft(term: term, example: ReadingWordExample(passageID: passage.id, passageTitle: passage.title, quote: String(paragraph.prefix(800))))
    }
    private func readingProgress(_ passage: ReadingPassage) -> CGFloat {
        guard !passage.paragraphs.isEmpty else { return 0 }
        return min(1, max(0, CGFloat(lastParagraph + 1) / CGFloat(passage.paragraphs.count)))
    }
    @ViewBuilder private func sourceLink(_ raw: String?) -> some View {
        if let raw, let url = URL(string: raw), ["https", "http"].contains(url.scheme ?? "") { Link("查看来源", destination: url).font(TypeScale.serif(12, relativeTo: .caption)) }
    }
    private func questionView(_ question: ReadingQuestion, passage: ReadingPassage) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text(String(format: "%02d", question.number)).font(TypeScale.serif(26)).foregroundStyle(Ink.ink3)
                Spacer()
                Button { askContext = .reading(passage, quote: question.stem, question: question, attempt: attempt) } label: { Image(systemName: "sparkles") }
                    .accessibilityLabel("询问第 \(question.number) 题")
            }
            SelectableStudyText(text: question.stem, identifier: "reading-question-\(question.id)") { quote in askContext = .reading(passage, quote: quote, question: question, attempt: attempt) }
            ForEach(question.options.indices, id: \.self) { index in
                Button {
                    guard !submitted else { return }
                    if let attemptID { learning.selectReading(attemptID: attemptID, questionID: question.id, option: index) }
                } label: { InkOptionRow(letter: String(UnicodeScalar(65 + index)!), text: question.options[index], state: readingOptionState(question, index: index), divider: index < question.options.count - 1) }
                .buttonStyle(.plain).accessibilityIdentifier("reading-option-\(question.number)-\(index)")
            }
            if submitted {
                if question.canGrade, let answer = question.answer {
                    Group {
                        if attempt?.selected[question.id] == answer {
                            Text("答对了").font(TypeScale.note).foregroundStyle(Ink.seal)
                        } else {
                            SealNote { Text("正确答案是 " + String(UnicodeScalar(65 + answer)!) + "，请回到原文核对依据。") }
                        }
                    }.accessibilityIdentifier("reading-answer-\(question.number)")
                    if let explanation = question.explanation, !explanation.isEmpty { Text(explanation).font(TypeScale.note).foregroundStyle(Ink.ink2).textSelection(.enabled) }
                } else { Text("参考答案待核验，已保留你的选择。").font(TypeScale.note).foregroundStyle(Ink.ink2) }
                Text(question.verification.title + " · " + question.source).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                sourceLink(question.sourceURL)
            }
        }.padding(.bottom, 26)
    }
    private func readingOptionState(_ question: ReadingQuestion, index: Int) -> InkOptionState {
        let pick = attempt?.selected[question.id]
        if !submitted { return pick == index ? .selected : .idle }
        if let answer = question.answer, answer == index { return .correct }
        if pick == index { return .wrongPick }
        return .other
    }
}

@MainActor
struct ReadingWordEditor: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State var term: String
    let example: ReadingWordExample
    @State private var definition = ""
    private var existing: StudyCard? { learning.cardForReadingTerm(term) }
    var body: some View {
        NavigationStack {
            Form {
                Section("单词或词组") { TextField("例如 library", text: $term).textInputAutocapitalization(.never).autocorrectionDisabled().accessibilityIdentifier("reading-word-term") }
                Section("释义") {
                    if let existing {
                        Text(existing.back).textSelection(.enabled)
                        Text("已有词卡，保留原来的复习进度和释义。").font(TypeScale.serif(12, relativeTo: .caption)).foregroundStyle(.secondary)
                    } else { TextField("填写你理解的词义", text: $definition, axis: .vertical).lineLimit(3...7).accessibilityIdentifier("reading-word-definition") }
                }
                Section("原句与出处") { Text(example.quote).font(TypeScale.serif(15, relativeTo: .subheadline)).textSelection(.enabled); Text(example.passageTitle).font(TypeScale.serif(12, relativeTo: .caption)).foregroundStyle(.secondary) }
            }.navigationTitle("加入生词本").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存生词") {
                        if learning.saveReadingWord(term: term, definition: existing?.back ?? definition, example: example) { dismiss() }
                    }.disabled(ReadingWords.normalized(term).isEmpty || (existing == nil && definition.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty))
                        .accessibilityIdentifier("reading-word-save")
                }
            }
        }
    }
}

@MainActor
struct ReadingWordListView: View {
    @EnvironmentObject private var learning: LearningStore
    var body: some View {
        List {
            if !learning.readingWords.isEmpty {
                Section { NavigationLink { CardReviewView(subject: .english, onlyIDs: Set(learning.readingWords.map(\.cardID))) } label: { Label("复习阅读生词", systemImage: "arrow.clockwise") } }
            }
            Section("收录 \(learning.readingWords.count) 个词") {
                ForEach(learning.readingWords) { word in
                    if let card = learning.state.cards.first(where: { $0.id == word.cardID }) {
                        NavigationLink { ReadingWordDetailView(word: word, card: card) } label: {
                            VStack(alignment: .leading, spacing: 6) { Text(card.front).font(TypeScale.subject); Text(card.back).font(TypeScale.caption).foregroundStyle(Ink.ink2).lineLimit(2); Text("来自 \(word.examples.count) 处原文 · 复习 \(card.reviews) 次").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                        }.accessibilityIdentifier("reading-collected-" + word.normalizedTerm)
                    }
                }.onDelete { offsets in let words = learning.readingWords; for index in offsets { learning.removeReadingWord(words[index].cardID) } }
                if learning.readingWords.isEmpty { Text("阅读时长按单词，点“加入生词本”。").foregroundStyle(Ink.ink2) }
            }
            Section { Text("生词复用已有词卡和复习进度。移出生词本会保留词卡与历史学习记录。").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
        }.scrollContentBackground(.hidden).background(AppBackground()).listRowBackground(Color.clear).listRowSeparatorTint(Ink.line).navigationTitle("阅读生词本")
    }
}

@MainActor
private struct ReadingWordDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    let word: ReadingWord
    let card: StudyCard
    var body: some View {
        List {
            Section { NavigationLink("查看释义与复习记录") { CardDetailView(cardID: card.id) } }
            Section("在原文中") {
                ForEach(Array(word.examples.enumerated()), id: \.offset) { _, example in
                    if let resourceID = example.resourceID, let resource = learning.state.resources.first(where: { $0.id == resourceID }) {
                        NavigationLink {
                            if resource.fileName?.lowercased().hasSuffix(".pdf") == true { StudyPDFReader(resourceID: resourceID, initialPageOverride: example.page) }
                            else { ResourceDetailView(resourceID: resourceID) }
                        } label: { exampleRow(example) }
                    } else if learning.readingPassages.contains(where: { $0.id == example.passageID }) {
                        NavigationLink { ReadingPracticeView(passageID: example.passageID) } label: { exampleRow(example) }
                    } else { exampleRow(example) }
                }
            }
        }.scrollContentBackground(.hidden).background(AppBackground()).navigationTitle(card.front)
    }
    private func exampleRow(_ example: ReadingWordExample) -> some View {
        VStack(alignment: .leading, spacing: 10) { Text(example.quote).font(TypeScale.serif(17)).lineLimit(6); Text(example.passageTitle + (example.page.map { " · 第 \($0 + 1) 页" } ?? "")).font(TypeScale.serif(12, relativeTo: .caption)).foregroundStyle(.secondary) }
    }
}
