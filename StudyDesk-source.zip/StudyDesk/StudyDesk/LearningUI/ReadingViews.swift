import SwiftUI
import UniformTypeIdentifiers

@MainActor
struct ReadingLibraryView: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var search = ""
    @State private var importing = false
    private var passages: [ReadingPassage] {
        learning.readingPassages.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.label.localizedCaseInsensitiveContains(search) }
            .sorted { ($0.year ?? 0) == ($1.year ?? 0) ? ($0.textNumber ?? 0) < ($1.textNumber ?? 0) : ($0.year ?? 0) > ($1.year ?? 0) }
    }
    var body: some View {
        List {
            Section {
                Button { importing = true } label: { Label("导入阅读题包", systemImage: "square.and.arrow.down") }
                NavigationLink { ReadingWordListView() } label: { Label("阅读生词本 · \(learning.readingWords.count)", systemImage: "character.book.closed") }
            }
            Section("我的阅读") {
                ForEach(passages.filter { !$0.isExample }) { row($0) }
                if passages.allSatisfy(\.isExample) { Text("导入包含原文、题目与来源的 JSON 题包后，会按年份和篇目显示。PDF 仍可在资料页阅读和提问。").font(.subheadline).foregroundStyle(.secondary) }
            }
            Section("功能示例 · 非历年真题") { ForEach(passages.filter(\.isExample)) { row($0) } }
        }.scrollContentBackground(.hidden).background(AppBackground())
            .navigationTitle("英语阅读").searchable(text: $search, prompt: "年份、篇目或标题")
            .onAppear { learning.ensureReadingExample() }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do { let url = try result.get(); Task { await learning.importFile(url, subject: .english, asCards: true) } }
                catch { learning.error = error.localizedDescription }
            }
    }
    private func row(_ passage: ReadingPassage) -> some View {
        NavigationLink { ReadingPracticeView(passageID: passage.id) } label: {
            VStack(alignment: .leading, spacing: 8) {
                Text(passage.title).font(.headline)
                Text(passage.label + " · \(passage.questions.count) 题").font(.caption).foregroundStyle(.secondary)
                if let attempt = learning.state.readingAttempt(for: passage.id) {
                    Text(attempt.submittedAt == nil ? "继续作答 · 已选 \(attempt.selected.count)/\(passage.questions.count)" : "已完成 · 核验题答对 \(attempt.correct ?? 0)/\(attempt.graded ?? 0)")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }.padding(.vertical, 7)
        }.accessibilityIdentifier("reading-" + passage.id)
    }
}

struct ReadingWordDraft: Identifiable {
    let id = UUID()
    let term: String
    let example: ReadingWordExample
}

@MainActor
struct ReadingPracticeView: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.scenePhase) private var scenePhase
    let passageID: String
    var initialQuestionID: String? = nil
    var initialAttemptID: UUID? = nil
    @State private var attemptID: UUID?
    @State private var lastParagraph = 0
    @State private var initialized = false
    @State private var askContext: StudyAskContext?
    @State private var wordDraft: ReadingWordDraft?
    private var passage: ReadingPassage? { learning.readingPassages.first { $0.id == passageID } }
    private var attempt: ReadingAttempt? { learning.state.readingAttempts?.first { $0.id == attemptID } }
    private var submitted: Bool { attempt?.submittedAt != nil }
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                if let passage {
                    LazyVStack(alignment: .leading, spacing: 25) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(passage.label).font(.caption).foregroundStyle(.secondary)
                            Text(passage.title).font(.custom("NotoSerifSC-Regular", size: 27))
                            Text(passage.source).font(.caption2).foregroundStyle(.secondary)
                            sourceLink(passage.sourceURL)
                        }.id("reading-top")
                        ForEach(Array(passage.paragraphs.enumerated()), id: \.offset) { index, paragraph in
                            VStack(alignment: .leading, spacing: 9) {
                                Text("P\(index + 1)").font(.caption.monospaced()).foregroundStyle(.secondary)
                                SelectableStudyText(text: paragraph, identifier: "reading-paragraph-\(index)", onCollect: { term, context in collect(term, paragraph: context, passage: passage) }) { quote in
                                    askContext = .reading(passage, quote: quote, attempt: attempt)
                                }
                            }.id("reading-paragraph-\(index)")
                                .onGeometryChange(for: CGRect.self, of: { $0.frame(in: .named("reading-scroll")) }) { frame in
                                    if frame.minY <= 30 && frame.maxY > 30 { lastParagraph = index }
                                }
                        }
                        Divider().padding(.vertical, 12)
                        VStack(alignment: .leading, spacing: 12) {
                            Text("配套题目").font(.title2)
                            if submitted {
                                Text("答对 \(attempt?.correct ?? 0)/\(attempt?.graded ?? 0) 道已核验题").font(.headline)
                                if passage.questions.contains(where: { !$0.canGrade }) { Text("答案待核验的题目只记录作答，不计入对错。").font(.caption).foregroundStyle(.secondary) }
                            }
                        }.id("reading-questions")
                        ForEach(passage.questions) { questionView($0, passage: passage).id("reading-target-" + $0.id) }
                        if passage.questions.isEmpty { Text("这份材料暂未包含配套题目，可以先阅读、收词或问 AI。").foregroundStyle(.secondary) }
                    }.padding(.horizontal, 22).padding(.top, 18).padding(.bottom, 125)
                }
            }.coordinateSpace(name: "reading-scroll").background(AppBackground())
                .overlay(alignment: .bottom) {
                    if let passage {
                        HStack(spacing: 16) {
                            Button("原文") { withAnimation { proxy.scrollTo("reading-paragraph-\(lastParagraph)", anchor: .top) } }
                            Button("题目") { withAnimation { proxy.scrollTo("reading-questions", anchor: .top) } }.accessibilityIdentifier("reading-jump-questions")
                            Spacer(minLength: 6)
                            if submitted {
                                Text("答对 \(attempt?.correct ?? 0)/\(attempt?.graded ?? 0)").font(.subheadline.monospacedDigit()).accessibilityIdentifier("reading-score")
                            } else {
                                Button("提交本篇") { if let attemptID { _ = learning.finishReading(attemptID) } }
                                    .buttonStyle(.glassProminent)
                                    .disabled(passage.questions.isEmpty || attempt?.selected.count != passage.questions.count)
                                    .accessibilityIdentifier("reading-submit")
                            }
                        }.padding(12).glassEffect(.regular.interactive(), in: .capsule).padding(.horizontal, 18).padding(.bottom, 12)
                    }
                }
                .onAppear {
                    if !initialized {
                        if let initialAttemptID, learning.state.readingAttempts?.contains(where: { $0.id == initialAttemptID && $0.passageID == passageID }) == true { attemptID = initialAttemptID }
                        else { attemptID = learning.openReading(passageID) }
                        initialized = true
                        lastParagraph = attempt?.paragraph ?? 0
                        if let initialQuestionID { DispatchQueue.main.async { proxy.scrollTo("reading-target-" + initialQuestionID, anchor: .top) } }
                        else if lastParagraph > 0 { DispatchQueue.main.async { proxy.scrollTo("reading-paragraph-\(lastParagraph)", anchor: .top) } }
                    }
                }
                .onChange(of: submitted) { _, value in
                    if value { DispatchQueue.main.async { withAnimation { proxy.scrollTo("reading-questions", anchor: .top) } } }
                }
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Menu {
                            Button("收录生词") { if let passage { collect("", paragraph: passage.paragraphs[min(lastParagraph, passage.paragraphs.count - 1)], passage: passage) } }
                            NavigationLink("打开生词本") { ReadingWordListView() }
                            if submitted {
                                Button("再做一遍") { attemptID = learning.openReading(passageID, restart: true); lastParagraph = 0; withAnimation { proxy.scrollTo("reading-top", anchor: .top) } }
                            }
                        } label: { Image(systemName: "ellipsis.circle") }.accessibilityLabel("阅读操作")
                    }
                }
        }.navigationTitle("阅读").navigationBarTitleDisplayMode(.inline).toolbar(.hidden, for: .tabBar)
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .sheet(item: $wordDraft) { ReadingWordEditor(term: $0.term, example: $0.example) }
            .onDisappear { if let attemptID { learning.rememberReadingPosition(attemptID, paragraph: lastParagraph) } }
            .onChange(of: scenePhase) { _, phase in if phase != .active, let attemptID { learning.rememberReadingPosition(attemptID, paragraph: lastParagraph) } }
    }
    private func collect(_ term: String, paragraph: String, passage: ReadingPassage) {
        wordDraft = ReadingWordDraft(term: term, example: ReadingWordExample(passageID: passage.id, passageTitle: passage.title, quote: String(paragraph.prefix(800))))
    }
    @ViewBuilder private func sourceLink(_ raw: String?) -> some View {
        if let raw, let url = URL(string: raw), ["https", "http"].contains(url.scheme ?? "") { Link("查看来源", destination: url).font(.caption) }
    }
    private func questionView(_ question: ReadingQuestion, passage: ReadingPassage) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text("\(question.number)").font(.headline.monospaced())
                Spacer()
                Button { askContext = .reading(passage, quote: question.stem, question: question, attempt: attempt) } label: { Image(systemName: "sparkles") }
                    .accessibilityLabel("询问第 \(question.number) 题")
            }
            SelectableStudyText(text: question.stem, identifier: "reading-question-\(question.id)") { quote in askContext = .reading(passage, quote: quote, question: question, attempt: attempt) }
            ForEach(question.options.indices, id: \.self) { index in
                Button {
                    if let attemptID { learning.selectReading(attemptID: attemptID, questionID: question.id, option: index) }
                } label: {
                    HStack(alignment: .top, spacing: 12) {
                        Text(String(UnicodeScalar(65 + index)!)).font(.headline)
                        Text(question.options[index]).font(.body).multilineTextAlignment(.leading)
                        Spacer(minLength: 0)
                        if attempt?.selected[question.id] == index { Image(systemName: "checkmark.circle.fill") }
                    }.padding(16).frame(maxWidth: .infinity, alignment: .leading)
                        .background(Ink.raised.opacity(attempt?.selected[question.id] == index ? 1 : 0.45), in: RoundedRectangle(cornerRadius: 18))
                }.buttonStyle(.plain).disabled(submitted).accessibilityIdentifier("reading-option-\(question.number)-\(index)")
            }
            if submitted {
                if question.canGrade, let answer = question.answer {
                    Text("参考答案：" + String(UnicodeScalar(65 + answer)!) + " · " + (attempt?.selected[question.id] == answer ? "答对了" : "再看原文"))
                        .font(.subheadline).accessibilityIdentifier("reading-answer-\(question.number)")
                    if let explanation = question.explanation, !explanation.isEmpty { Text(explanation).font(.subheadline).foregroundStyle(.secondary).textSelection(.enabled) }
                } else { Text("参考答案待核验，已保留你的选择。").font(.subheadline).foregroundStyle(.secondary) }
                Text(question.verification.title + " · " + question.source).font(.caption2).foregroundStyle(.secondary)
                sourceLink(question.sourceURL)
            }
        }.padding(.bottom, 26)
    }
}

@MainActor
struct ReadingWordEditor: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    @State var term: String
    let example: ReadingWordExample
    @State private var definition = ""
    private var existing: StudyCard? { learning.cardForReadingTerm(term) }
    var body: some View {
        NavigationStack {
            Form {
                Section("单词或词组") { TextField("例如 library", text: $term).textInputAutocapitalization(.never).autocorrectionDisabled().accessibilityIdentifier("reading-word-term") }
                Section("释义") {
                    if let existing {
                        Text(existing.back).textSelection(.enabled)
                        Text("已有词卡，保留原来的复习进度和释义。").font(.caption).foregroundStyle(.secondary)
                    } else { TextField("填写你理解的词义", text: $definition, axis: .vertical).lineLimit(3...7).accessibilityIdentifier("reading-word-definition") }
                }
                Section("原句与出处") { Text(example.quote).font(.subheadline).textSelection(.enabled); Text(example.passageTitle).font(.caption).foregroundStyle(.secondary) }
            }.navigationTitle("加入生词本").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存生词") {
                        if learning.saveReadingWord(term: term, definition: existing?.back ?? definition, example: example) { dismiss() }
                    }.disabled(ReadingWords.normalized(term).isEmpty || (existing == nil && definition.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty))
                        .accessibilityIdentifier("reading-word-save")
                }
            }
        }
    }
}

@MainActor
struct ReadingWordListView: View {
    @EnvironmentObject private var learning: LearningStore
    var body: some View {
        List {
            if !learning.readingWords.isEmpty {
                Section { NavigationLink { CardReviewView(subject: .english, onlyIDs: Set(learning.readingWords.map(\.cardID))) } label: { Label("复习阅读生词", systemImage: "arrow.clockwise") } }
            }
            Section("收录 \(learning.readingWords.count) 个词") {
                ForEach(learning.readingWords) { word in
                    if let card = learning.state.cards.first(where: { $0.id == word.cardID }) {
                        NavigationLink { ReadingWordDetailView(word: word, card: card) } label: {
                            VStack(alignment: .leading, spacing: 6) { Text(card.front).font(.headline); Text(card.back).font(.caption).foregroundStyle(.secondary).lineLimit(2); Text("来自 \(word.examples.count) 处原文 · 复习 \(card.reviews) 次").font(.caption2).foregroundStyle(.secondary) }
                        }.accessibilityIdentifier("reading-collected-" + word.normalizedTerm)
                    }
                }.onDelete { offsets in let words = learning.readingWords; for index in offsets { learning.removeReadingWord(words[index].cardID) } }
                if learning.readingWords.isEmpty { Text("阅读时长按单词，点“加入生词本”。").foregroundStyle(.secondary) }
            }
            Section { Text("生词复用已有词卡和复习进度。移出生词本会保留词卡与历史学习记录。").font(.caption).foregroundStyle(.secondary) }
        }.scrollContentBackground(.hidden).background(AppBackground()).navigationTitle("阅读生词本")
    }
}

@MainActor
private struct ReadingWordDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    let word: ReadingWord
    let card: StudyCard
    var body: some View {
        List {
            Section { NavigationLink("查看释义与复习记录") { CardDetailView(cardID: card.id) } }
            Section("在原文中") {
                ForEach(Array(word.examples.enumerated()), id: \.offset) { _, example in
                    if let resourceID = example.resourceID, let resource = learning.state.resources.first(where: { $0.id == resourceID }) {
                        NavigationLink {
                            if resource.fileName?.lowercased().hasSuffix(".pdf") == true { StudyPDFReader(resourceID: resourceID, initialPageOverride: example.page) }
                            else { ResourceDetailView(resourceID: resourceID) }
                        } label: { exampleRow(example) }
                    } else if learning.readingPassages.contains(where: { $0.id == example.passageID }) {
                        NavigationLink { ReadingPracticeView(passageID: example.passageID) } label: { exampleRow(example) }
                    } else { exampleRow(example) }
                }
            }
        }.scrollContentBackground(.hidden).background(AppBackground()).navigationTitle(card.front)
    }
    private func exampleRow(_ example: ReadingWordExample) -> some View {
        VStack(alignment: .leading, spacing: 10) { Text(example.quote).font(.body).lineLimit(6); Text(example.passageTitle + (example.page.map { " · 第 \($0 + 1) 页" } ?? "")).font(.caption).foregroundStyle(.secondary) }
    }
}
