import SwiftUI

/// 一句话记录面板。也用在计时结束时问「这一段学了什么？」。
@MainActor
struct QuickNoteSheet: View {
    enum Mode { case note, afterFocus }
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    var mode: Mode = .note
    /// 计时结束模式：用户保存或跳过后回调，参数是填的话（跳过为 nil）
    var onFinish: ((String?) -> Void)? = nil
    @State private var text = ""
    @State private var subject: StudySubject?
    @State private var minutes = 0
    @FocusState private var focused: Bool

    private static let durations = [0, 15, 30, 45, 60, 90, 120, 180]
    private var guessed: StudySubject? { QuickNote.guessSubject(text) }
    private var canSave: Bool { !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 0) {
                TextField(mode == .note ? "学了什么？比如：马原第一章看完，选择题错了 4 道" : "这一段学了什么？",
                          text: $text, axis: .vertical)
                    .font(TypeScale.serif(18)).foregroundStyle(Ink.ink)
                    .lineLimit(2...6).focused($focused)
                    .padding(.top, Space.l).accessibilityIdentifier("quick-note-field")
                Text("可以点键盘上的麦克风直接说。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.s)
                InkRule().padding(.top, Space.l)
                HStack(spacing: Space.s) {
                    Menu {
                        Button { subject = nil } label: { checkLabel("自动判断", subject == nil) }
                        ForEach(StudySubject.allCases) { item in
                            Button { subject = item } label: { checkLabel(item.title, subject == item) }
                        }
                    } label: {
                        Text(subjectLabel).font(TypeScale.serif(14)).padding(.horizontal, 14).frame(height: 36)
                    }
                    .glassEffect(.regular.interactive(), in: .capsule)
                    .accessibilityIdentifier("quick-note-subject")
                    if mode == .note {
                        Menu {
                            ForEach(Self.durations, id: \.self) { value in
                                Button { minutes = value } label: { checkLabel(durationLabel(value), minutes == value) }
                            }
                        } label: {
                            Text(minutes == 0 ? "不计时长" : durationLabel(minutes)).font(TypeScale.serif(14)).padding(.horizontal, 14).frame(height: 36)
                        }
                        .glassEffect(.regular.interactive(), in: .capsule)
                        .accessibilityIdentifier("quick-note-duration")
                    }
                    Spacer()
                }
                .foregroundStyle(Ink.ink).padding(.top, Space.l)
                Text(footnote).font(TypeScale.caption).foregroundStyle(Ink.ink3).lineSpacing(3).padding(.top, Space.m)
                Spacer()
            }
            .padding(.horizontal, Space.xl)
            .background(AppBackground())
            .navigationTitle(mode == .note ? "记一笔" : "这一段学了什么？")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(mode == .note ? "取消" : "跳过") { onFinish?(nil); dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { save() }.disabled(!canSave).accessibilityIdentifier("quick-note-save")
                }
            }
            .onAppear { focused = true }
        }
        .presentationDetents([.medium, .large])
    }

    @ViewBuilder private func checkLabel(_ title: String, _ on: Bool) -> some View {
        if on { Label(title, systemImage: "checkmark") } else { Text(title) }
    }
    private var subjectLabel: String {
        if let subject { return subject.title }
        if let guessed { return "自动 · \(guessed.title)" }
        return "自动判断"
    }
    private var footnote: String {
        mode == .afterFocus
            ? "会写进刚才这段计时的记录里；跳过就保持原来的科目名。"
            : (minutes == 0 ? "只记下这句话，不计入学习时长。纸质书学了多久，选一下时长就会算进今天。" : "会按「现在往前 \(durationLabel(minutes))」补记一段学习，计入今天的时长。")
    }
    private func durationLabel(_ value: Int) -> String {
        value == 0 ? "不计时长" : (value < 60 ? "\(value) 分钟" : (value % 60 == 0 ? "\(value / 60) 小时" : "\(value / 60) 小时 \(value % 60) 分"))
    }
    private func save() {
        switch mode {
        case .note:
            if learning.addNote(text, subject: subject, minutes: minutes == 0 ? nil : minutes) { dismiss() }
        case .afterFocus:
            onFinish?(text); dismiss()
        }
    }
}

/// 编辑一条笔记或补记的文字。
@MainActor
struct EditNoteSheet: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    let event: LearningEvent
    @State private var text = ""
    var body: some View {
        NavigationStack {
            TextField("内容", text: $text, axis: .vertical)
                .font(TypeScale.serif(18)).lineLimit(2...8)
                .padding(Space.xl)
                .frame(maxHeight: .infinity, alignment: .top)
                .background(AppBackground())
                .navigationTitle("修改记录").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("保存") { learning.updateNote(event.id, text: text); dismiss() }
                            .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
                .onAppear { text = ["", "手动补记", "专注学习"].contains(event.detail) ? event.title : event.detail }
        }
        .presentationDetents([.medium])
    }
}
