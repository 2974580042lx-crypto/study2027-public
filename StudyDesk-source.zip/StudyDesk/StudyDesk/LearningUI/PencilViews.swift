import SwiftUI
import PencilKit
import Vision

// MARK: - 笔迹存取

extension LearningStore {
    private static var previewDrawings: [String: Data] = [:]

    func drawing(_ key: String) -> PKDrawing {
        let data = preview ? Self.previewDrawings[key] : try? Data(contentsOf: drawingsURL.appendingPathComponent(key + ".drawing"))
        return data.flatMap { try? PKDrawing(data: $0) } ?? PKDrawing()
    }

    func saveDrawing(_ drawing: PKDrawing, key: String) {
        let data = drawing.dataRepresentation()
        if preview { Self.previewDrawings[key] = data; return }
        let url = drawingsURL.appendingPathComponent(key + ".drawing")
        do {
            try FileManager.default.createDirectory(at: drawingsURL, withIntermediateDirectories: true)
            if drawing.strokes.isEmpty { try? FileManager.default.removeItem(at: url) }
            else { try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]) }
        } catch { self.error = "笔迹没有保存成功：\(error.localizedDescription)" }
    }
}

// MARK: - 笔

/// 预设颜色：墨色（跟随深浅色模式，深色背景上自动变浅）、黑白灰和常用彩色；其余用调色盘选
enum PenPalette {
    static let presets: [(name: String, color: Color)] = [
        ("墨色", Ink.ink), ("黑", .black), ("白", .white), ("灰", Color(white: 0.55)),
        ("红", Color(red: 0.84, green: 0.18, blue: 0.15)), ("橙", Color(red: 0.95, green: 0.55, blue: 0.10)),
        ("黄", Color(red: 0.98, green: 0.80, blue: 0.10)), ("绿", Color(red: 0.16, green: 0.62, blue: 0.30)),
        ("蓝", Color(red: 0.13, green: 0.42, blue: 0.86)), ("紫", Color(red: 0.55, green: 0.27, blue: 0.78)),
    ]
}

/// 当前用的笔：工具（笔 / 荧光笔 / 橡皮）+ 颜色 + 粗细
struct PencilTool: Equatable {
    enum Kind: String, CaseIterable { case pen, marker, eraser }
    var kind: Kind = .pen
    var color: Color = Ink.ink
    /// 粗细档：0 细、1 中、2 粗
    var size = 1

    static let pen = PencilTool()
    static let red = PencilTool(color: Color(red: 0.84, green: 0.18, blue: 0.15))

    var pkTool: PKTool {
        let base: CGFloat = [1.4, 2.4, 4.0][min(max(size, 0), 2)]
        switch kind {
        case .pen: return PKInkingTool(.pen, color: UIColor(color), width: base)
        case .marker:
            // 墨色的荧光笔看不清，换成常见的黄色荧光
            let ui = color == Ink.ink ? UIColor(red: 0.98, green: 0.82, blue: 0.25, alpha: 1) : UIColor(color)
            return PKInkingTool(.marker, color: ui.withAlphaComponent(0.4), width: base * 6)
        case .eraser: return PKEraserTool(.vector)
        }
    }
}

/// 画布。笔模式下（drawingPolicy = .pencilOnly）只有 Apple Pencil 画线，手指的拖动交给外面的滚动视图；
/// 关掉 enabled 时整层不接触摸，下面的文字可以照常长按选字
final class PencilOnlyCanvas: PKCanvasView {}

/// PencilKit 画布：透明背景、不自己滚动，大小跟随外面的内容
struct PencilCanvas: UIViewRepresentable {
    let key: String
    var tool: PencilTool
    var fingersDraw = false
    /// 是否接收触摸（阅读原文：只有打开笔工具时才接收）
    var enabled = true
    /// 外面要求清空时自增
    var clearToken = 0
    var onChange: ((PKDrawing) -> Void)? = nil
    @EnvironmentObject private var learning: LearningStore

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> PencilOnlyCanvas {
        let view = PencilOnlyCanvas()
        view.backgroundColor = .clear
        view.isOpaque = false
        view.isScrollEnabled = false
        view.drawingPolicy = fingersDraw ? .anyInput : .pencilOnly
        view.isUserInteractionEnabled = enabled
        view.drawing = learning.drawing(key)
        view.tool = tool.pkTool
        view.delegate = context.coordinator
        context.coordinator.lastClear = clearToken
        context.coordinator.store = learning
        return view
    }

    func updateUIView(_ view: PencilOnlyCanvas, context: Context) {
        context.coordinator.parent = self
        context.coordinator.store = learning
        view.tool = tool.pkTool
        view.drawingPolicy = fingersDraw ? .anyInput : .pencilOnly
        view.isUserInteractionEnabled = enabled
        if context.coordinator.key != key {
            context.coordinator.key = key
            view.drawing = learning.drawing(key)
        }
        if context.coordinator.lastClear != clearToken {
            context.coordinator.lastClear = clearToken
            view.drawing = PKDrawing()
            learning.saveDrawing(view.drawing, key: key)
        }
    }

    @MainActor final class Coordinator: NSObject, PKCanvasViewDelegate {
        var parent: PencilCanvas
        weak var store: LearningStore?
        var key: String
        var lastClear = 0
        private var pending: Task<Void, Never>?
        init(_ parent: PencilCanvas) { self.parent = parent; key = parent.key }
        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            let drawing = canvasView.drawing, key = key, store = store
            parent.onChange?(drawing)
            // 停笔半秒后再存，写字时不频繁读写文件
            pending?.cancel()
            pending = Task { @MainActor in
                try? await Task.sleep(nanoseconds: 500_000_000)
                guard !Task.isCancelled else { return }
                store?.saveDrawing(drawing, key: key)
            }
        }
    }
}

/// 笔工具条：笔 / 荧光笔 / 橡皮 ｜ 颜色 ｜ 粗细 ｜ 清空。放不下时可以左右滑
struct PencilToolbar: View {
    @Binding var tool: PencilTool
    var clear: () -> Void
    var close: (() -> Void)? = nil
    @State private var confirmClear = false
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 4) {
                kindButton(.pen, symbol: "pencil.tip", title: "笔")
                kindButton(.marker, symbol: "highlighter", title: "荧光笔")
                kindButton(.eraser, symbol: "eraser", title: "橡皮")
                divider
                ForEach(PenPalette.presets.indices, id: \.self) { i in
                    let preset = PenPalette.presets[i]
                    Button { pick(preset.color) } label: {
                        Circle().fill(preset.color).frame(width: 20, height: 20)
                            .overlay(Circle().stroke(Ink.line, lineWidth: 1))
                            .overlay(Circle().stroke(Ink.ink2, lineWidth: tool.color == preset.color && tool.kind != .eraser ? 2 : 0).padding(-4))
                            .frame(width: 32, height: 36)
                    }.buttonStyle(.plain).accessibilityLabel(preset.name)
                }
                // 调色盘：任意颜色
                ColorPicker("调色盘", selection: Binding(get: { tool.color }, set: { pick($0) }), supportsOpacity: false)
                    .labelsHidden().frame(width: 36, height: 36).accessibilityIdentifier("pen-color-picker")
                divider
                ForEach(0..<3, id: \.self) { s in
                    Button { tool.size = s } label: {
                        Circle().fill(Ink.ink2).frame(width: [5, 9, 14][s], height: [5, 9, 14][s])
                            .frame(width: 30, height: 36)
                            .background(tool.size == s ? Ink.line : Color.clear, in: Capsule())
                    }.buttonStyle(.plain).accessibilityLabel(["细", "中", "粗"][s])
                }
                divider
                Button("清空") { confirmClear = true }.font(TypeScale.caption).foregroundStyle(Ink.ink2).padding(.horizontal, 8)
                if let close {
                    Button { close() } label: { Image(systemName: "xmark").frame(width: 32, height: 36) }
                        .buttonStyle(.plain).foregroundStyle(Ink.ink3).accessibilityLabel("收起笔工具")
                }
            }
            .padding(.horizontal, 8).padding(.vertical, 4)
        }
        .fixedSize(horizontal: false, vertical: true)
        .frame(maxWidth: 560, alignment: .leading)
        .glassEffect(.regular.interactive(), in: .capsule)
        .confirmationDialog("清空这一页的笔迹？", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("清空", role: .destructive) { clear() }
        }
    }

    private var divider: some View { Rectangle().fill(Ink.line).frame(width: 0.5, height: 22).padding(.horizontal, 4) }

    private func kindButton(_ kind: PencilTool.Kind, symbol: String, title: String) -> some View {
        Button { tool.kind = kind } label: {
            Image(systemName: symbol)
                .foregroundStyle(kind == .eraser ? Ink.ink : tool.color)
                .frame(width: 40, height: 36)
                .background(tool.kind == kind ? Ink.line : Color.clear, in: Capsule())
        }.buttonStyle(.plain).accessibilityLabel(title)
    }

    /// 选颜色时如果正拿着橡皮，自动换回笔
    private func pick(_ color: Color) {
        tool.color = color
        if tool.kind == .eraser { tool.kind = .pen }
    }
}

/// 草稿纸：浅色方格，手指和笔都能写；每篇文章一张
struct ScratchPadView: View {
    let key: String
    @State private var tool: PencilTool = .pen
    @State private var clearToken = 0
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("草稿纸").font(TypeScale.subject)
                Spacer()
                PencilToolbar(tool: $tool, clear: { clearToken += 1 })
            }.padding(.horizontal, Space.l).padding(.vertical, Space.s)
            ZStack {
                GridPaper(spacing: 28)
                PencilCanvas(key: key, tool: tool, fingersDraw: true, clearToken: clearToken)
            }
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Ink.line, lineWidth: 0.5))
            .padding(.horizontal, Space.l).padding(.bottom, Space.l)
        }
        .accessibilityIdentifier("scratch-pad")
    }
}

/// 方格或横线底纹
struct GridPaper: View {
    var spacing: CGFloat = 28
    var linesOnly = false
    var body: some View {
        Canvas { ctx, size in
            var path = Path()
            var y = spacing
            while y < size.height { path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)); y += spacing }
            if !linesOnly {
                var x = spacing
                while x < size.width { path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height)); x += spacing }
            }
            ctx.stroke(path, with: .color(Ink.line), lineWidth: 0.5)
        }
        .background(Ink.paper)
        .allowsHitTesting(false)
    }
}

// MARK: - 手写识别

enum HandwritingReader {
    /// 把笔迹渲染成图片，用系统自带的文字识别转成文字（中文 + 英文），按行从上到下拼起来
    static func recognize(_ drawing: PKDrawing) async throws -> String {
        guard !drawing.strokes.isEmpty else { throw StudyFailure.message("还没有写字。") }
        let bounds = drawing.bounds.insetBy(dx: -24, dy: -24)
        let image = await MainActor.run {
            let traits = UITraitCollection(userInterfaceStyle: .light)
            var img = UIImage()
            traits.performAsCurrent { img = drawing.image(from: bounds, scale: 2) }
            return img
        }
        guard let cg = whiteBackground(image).cgImage else { throw StudyFailure.message("没能读取笔迹。") }
        return try await withCheckedThrowingContinuation { cont in
            let request = VNRecognizeTextRequest { request, error in
                if let error { cont.resume(throwing: error); return }
                let lines = (request.results as? [VNRecognizedTextObservation] ?? [])
                    .sorted { $0.boundingBox.minY > $1.boundingBox.minY }
                    .compactMap { $0.topCandidates(1).first?.string }
                cont.resume(returning: lines.joined(separator: "\n"))
            }
            request.recognitionLevel = .accurate
            request.recognitionLanguages = ["zh-Hans", "en-US"]
            request.usesLanguageCorrection = true
            DispatchQueue.global(qos: .userInitiated).async {
                do { try VNImageRequestHandler(cgImage: cg).perform([request]) } catch { cont.resume(throwing: error) }
            }
        }
    }

    private static func whiteBackground(_ image: UIImage) -> UIImage {
        UIGraphicsImageRenderer(size: image.size, format: { let f = UIGraphicsImageRendererFormat(); f.scale = image.scale; return f }()).image { ctx in
            UIColor.white.setFill(); ctx.fill(CGRect(origin: .zero, size: image.size))
            image.draw(at: .zero)
        }
    }
}
