import SwiftUI
import PencilKit
import Vision

// MARK: - 笔迹存取

extension LearningStore {
    private static var previewDrawings: [String: Data] = [:]

    func drawing(_ key: String) -> PKDrawing {
        let data = preview ? Self.previewDrawings[key] : try? Data(contentsOf: drawingsURL.appendingPathComponent(key + ".drawing"))
        return data.flatMap { try? PKDrawing(data: $0) } ?? PKDrawing()
    }

    func saveDrawing(_ drawing: PKDrawing, key: String) {
        let data = drawing.dataRepresentation()
        if preview { Self.previewDrawings[key] = data; return }
        let url = drawingsURL.appendingPathComponent(key + ".drawing")
        do {
            try FileManager.default.createDirectory(at: drawingsURL, withIntermediateDirectories: true)
            if drawing.strokes.isEmpty { try? FileManager.default.removeItem(at: url) }
            else { try data.write(to: url, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication]) }
        } catch { self.error = "笔迹没有保存成功：\(error.localizedDescription)" }
    }
}

// MARK: - 笔

enum PencilTool: String, CaseIterable, Identifiable {
    case pen, red, marker, eraser
    var id: String { rawValue }
    var title: String {
        switch self { case .pen: "黑笔"; case .red: "红笔"; case .marker: "荧光笔"; case .eraser: "橡皮" }
    }
    var symbol: String {
        switch self { case .pen: "pencil.tip"; case .red: "pencil.tip"; case .marker: "highlighter"; case .eraser: "eraser" }
    }
    var pkTool: PKTool {
        switch self {
        case .pen: return PKInkingTool(.pen, color: UIColor(Ink.ink), width: 2.2)
        case .red: return PKInkingTool(.pen, color: UIColor(Ink.seal), width: 2.2)
        case .marker: return PKInkingTool(.marker, color: UIColor(red: 0.98, green: 0.82, blue: 0.25, alpha: 0.55), width: 14)
        case .eraser: return PKEraserTool(.vector)
        }
    }
}

/// 只有 Apple Pencil 的触碰会落到画布上；手指穿过去，照常滚动、长按选字
final class PencilOnlyCanvas: PKCanvasView {
    var fingersDraw = false
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        if fingersDraw { return super.point(inside: point, with: event) }
        guard let touches = event?.allTouches, !touches.isEmpty else { return false }
        return touches.contains { $0.type == .pencil } && super.point(inside: point, with: event)
    }
}

/// PencilKit 画布：透明背景、不自己滚动，大小跟随外面的内容
struct PencilCanvas: UIViewRepresentable {
    let key: String
    var tool: PencilTool
    var fingersDraw = false
    /// 外面要求清空时自增
    var clearToken = 0
    var onChange: ((PKDrawing) -> Void)? = nil
    @EnvironmentObject private var learning: LearningStore

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> PencilOnlyCanvas {
        let view = PencilOnlyCanvas()
        view.backgroundColor = .clear
        view.isOpaque = false
        view.isScrollEnabled = false
        view.drawingPolicy = fingersDraw ? .anyInput : .pencilOnly
        view.fingersDraw = fingersDraw
        view.drawing = learning.drawing(key)
        view.tool = tool.pkTool
        view.delegate = context.coordinator
        context.coordinator.lastClear = clearToken
        context.coordinator.store = learning
        return view
    }

    func updateUIView(_ view: PencilOnlyCanvas, context: Context) {
        context.coordinator.parent = self
        context.coordinator.store = learning
        view.tool = tool.pkTool
        view.fingersDraw = fingersDraw
        view.drawingPolicy = fingersDraw ? .anyInput : .pencilOnly
        if context.coordinator.key != key {
            context.coordinator.key = key
            view.drawing = learning.drawing(key)
        }
        if context.coordinator.lastClear != clearToken {
            context.coordinator.lastClear = clearToken
            view.drawing = PKDrawing()
            learning.saveDrawing(view.drawing, key: key)
        }
    }

    @MainActor final class Coordinator: NSObject, PKCanvasViewDelegate {
        var parent: PencilCanvas
        weak var store: LearningStore?
        var key: String
        var lastClear = 0
        private var pending: Task<Void, Never>?
        init(_ parent: PencilCanvas) { self.parent = parent; key = parent.key }
        func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
            let drawing = canvasView.drawing, key = key, store = store
            parent.onChange?(drawing)
            // 停笔半秒后再存，写字时不频繁读写文件
            pending?.cancel()
            pending = Task { @MainActor in
                try? await Task.sleep(nanoseconds: 500_000_000)
                guard !Task.isCancelled else { return }
                store?.saveDrawing(drawing, key: key)
            }
        }
    }
}

/// 笔工具条：黑笔 / 红笔 / 荧光笔 / 橡皮 / 清空
struct PencilToolbar: View {
    @Binding var tool: PencilTool
    var clear: () -> Void
    var close: (() -> Void)? = nil
    @State private var confirmClear = false
    var body: some View {
        HStack(spacing: 4) {
            ForEach(PencilTool.allCases) { t in
                Button { tool = t } label: {
                    Image(systemName: t.symbol)
                        .foregroundStyle(t == .red ? Ink.seal : (t == .marker ? Color(red: 0.85, green: 0.62, blue: 0.05) : Ink.ink))
                        .frame(width: 40, height: 36)
                        .background(tool == t ? Ink.line : Color.clear, in: Capsule())
                }.buttonStyle(.plain).accessibilityLabel(t.title)
            }
            Rectangle().fill(Ink.line).frame(width: 0.5, height: 22).padding(.horizontal, 4)
            Button("清空") { confirmClear = true }.font(TypeScale.caption).foregroundStyle(Ink.ink2).padding(.horizontal, 8)
            if let close {
                Button { close() } label: { Image(systemName: "xmark").frame(width: 32, height: 36) }
                    .buttonStyle(.plain).foregroundStyle(Ink.ink3).accessibilityLabel("收起笔工具")
            }
        }
        .padding(.horizontal, 8).padding(.vertical, 4)
        .glassEffect(.regular.interactive(), in: .capsule)
        .confirmationDialog("清空这一页的笔迹？", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("清空", role: .destructive) { clear() }
        }
    }
}

/// 草稿纸：浅色方格，手指和笔都能写；每篇文章一张
struct ScratchPadView: View {
    let key: String
    @State private var tool: PencilTool = .pen
    @State private var clearToken = 0
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("草稿纸").font(TypeScale.subject)
                Spacer()
                PencilToolbar(tool: $tool, clear: { clearToken += 1 })
            }.padding(.horizontal, Space.l).padding(.vertical, Space.s)
            ZStack {
                GridPaper(spacing: 28)
                PencilCanvas(key: key, tool: tool, fingersDraw: true, clearToken: clearToken)
            }
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Ink.line, lineWidth: 0.5))
            .padding(.horizontal, Space.l).padding(.bottom, Space.l)
        }
        .accessibilityIdentifier("scratch-pad")
    }
}

/// 方格或横线底纹
struct GridPaper: View {
    var spacing: CGFloat = 28
    var linesOnly = false
    var body: some View {
        Canvas { ctx, size in
            var path = Path()
            var y = spacing
            while y < size.height { path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y)); y += spacing }
            if !linesOnly {
                var x = spacing
                while x < size.width { path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height)); x += spacing }
            }
            ctx.stroke(path, with: .color(Ink.line), lineWidth: 0.5)
        }
        .background(Ink.paper)
        .allowsHitTesting(false)
    }
}

// MARK: - 手写识别

enum HandwritingReader {
    /// 把笔迹渲染成图片，用系统自带的文字识别转成文字（中文 + 英文），按行从上到下拼起来
    static func recognize(_ drawing: PKDrawing) async throws -> String {
        guard !drawing.strokes.isEmpty else { throw StudyFailure.message("还没有写字。") }
        let bounds = drawing.bounds.insetBy(dx: -24, dy: -24)
        let image = await MainActor.run {
            let traits = UITraitCollection(userInterfaceStyle: .light)
            var img = UIImage()
            traits.performAsCurrent { img = drawing.image(from: bounds, scale: 2) }
            return img
        }
        guard let cg = whiteBackground(image).cgImage else { throw StudyFailure.message("没能读取笔迹。") }
        return try await withCheckedThrowingContinuation { cont in
            let request = VNRecognizeTextRequest { request, error in
                if let error { cont.resume(throwing: error); return }
                let lines = (request.results as? [VNRecognizedTextObservation] ?? [])
                    .sorted { $0.boundingBox.minY > $1.boundingBox.minY }
                    .compactMap { $0.topCandidates(1).first?.string }
                cont.resume(returning: lines.joined(separator: "\n"))
            }
            request.recognitionLevel = .accurate
            request.recognitionLanguages = ["zh-Hans", "en-US"]
            request.usesLanguageCorrection = true
            DispatchQueue.global(qos: .userInitiated).async {
                do { try VNImageRequestHandler(cgImage: cg).perform([request]) } catch { cont.resume(throwing: error) }
            }
        }
    }

    private static func whiteBackground(_ image: UIImage) -> UIImage {
        UIGraphicsImageRenderer(size: image.size, format: { let f = UIGraphicsImageRendererFormat(); f.scale = image.scale; return f }()).image { ctx in
            UIColor.white.setFill(); ctx.fill(CGRect(origin: .zero, size: image.size))
            image.draw(at: .zero)
        }
    }
}
