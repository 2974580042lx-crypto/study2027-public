import SwiftUI

extension HistoryDictionary {
    /// 随 App 打包的史事词典，第一次用到时读入
    static let bundled: HistoryDictionary = {
        guard let url = Bundle.main.url(forResource: "history-entries", withExtension: "json"),
              let data = try? Data(contentsOf: url), let dict = try? HistoryDictionary(data: data) else { return .empty }
        return dict
    }()
}

private enum HistoryTab: Hashable { case chinaTimeline, worldTimeline, chapters }

/// 史事：搜索 + 年表 + 按章节浏览。点任何一条进入条目页。
@MainActor
struct HistoryDictionaryView: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var query = ""
    @State private var tab: HistoryTab = .chinaTimeline
    private let dict = HistoryDictionary.bundled

    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text("史事").font(TypeScale.serif(29, relativeTo: .title)).padding(.top, Space.xl)
                Text("\(dict.entries.count) 条名词与事件 · 正文里带下划线的词可以点开")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.xs).padding(.bottom, Space.l)
                let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
                if !q.isEmpty {
                    let results = dict.search(q)
                    InkSectionHeader(title: results.isEmpty ? "没有找到「\(q)」" : "找到 \(results.count) 条").padding(.bottom, Space.s)
                    ForEach(results) { HistoryEntryRow(entry: $0, showYear: true) }
                    if results.isEmpty {
                        Text("换个说法试试，比如只搜关键的两三个字。词典里没有的，可以问 AI。")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    }
                } else {
                    InkTabs(items: [(HistoryTab.chinaTimeline, "中国史年表"), (.worldTimeline, "世界史年表"), (.chapters, "按章节")], selection: $tab)
                        .padding(.bottom, Space.s)
                    switch tab {
                    case .chinaTimeline: timeline(china: true)
                    case .worldTimeline: timeline(china: false)
                    case .chapters: chapters
                    }
                }
                Text("词条由 AI 整理，用来快速回忆和查找，具体表述以教材为准。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.xl)
            }
        }
        .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜名词、事件、人物")
        .navigationTitle("史事").navigationBarTitleDisplayMode(.inline)
        .accessibilityIdentifier("history-dictionary")
    }

    private func timeline(china: Bool) -> some View {
        let items = dict.timeline(china: china)
        let blocks = learning.syllabusNodes
        return LazyVStack(alignment: .leading, spacing: 0) {
            ForEach(Array(items.enumerated()), id: \.element.id) { i, entry in
                let block = blocks.first { $0.id == entry.nodeID }?.block
                if i == 0 || blocks.first(where: { $0.id == items[i - 1].nodeID })?.block != block, let block {
                    InkSectionHeader(title: block).padding(.top, i == 0 ? Space.m : Space.section).padding(.bottom, Space.xs)
                }
                HistoryEntryRow(entry: entry, showYear: true)
            }
        }
    }

    private var chapters: some View {
        let nodes = learning.syllabusNodes.filter { $0.subject == .history }.sorted { $0.order < $1.order }
        return LazyVStack(alignment: .leading, spacing: 0) {
            ForEach(nodes) { node in
                let entries = dict.entries(inNode: node.id)
                if !entries.isEmpty {
                    NavigationLink { HistoryNodeEntriesView(nodeID: node.id) } label: {
                        InkRow(title: node.title, detail: node.block, value: "\(entries.count) 条", chevron: true)
                    }.buttonStyle(.plain)
                }
            }
        }
    }
}

/// 一行：左边年份，右边名称和类别
struct HistoryEntryRow: View {
    let entry: HistoryEntry
    var showYear = false
    var body: some View {
        NavigationLink { HistoryEntryView(entryID: entry.id) } label: {
            VStack(spacing: 0) {
                HStack(alignment: .firstTextBaseline, spacing: Space.m) {
                    if showYear {
                        Text(entry.yearText ?? "—").font(TypeScale.caption).foregroundStyle(Ink.ink3).monospacedDigit()
                            .frame(width: 92, alignment: .leading).lineLimit(2)
                    }
                    Text(entry.title).font(TypeScale.serif(16)).foregroundStyle(Ink.ink).multilineTextAlignment(.leading)
                    Spacer(minLength: Space.s)
                    Text(entry.kind).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }.padding(.vertical, 13).contentShape(Rectangle())
                InkRule()
            }
        }.buttonStyle(.plain).accessibilityIdentifier("history-entry-\(entry.id)")
    }
}

/// 某一节的全部条目（考纲页和「按章节」都会进来）
struct HistoryNodeEntriesView: View {
    @EnvironmentObject private var learning: LearningStore
    let nodeID: String
    var body: some View {
        let node = learning.syllabusNodes.first { $0.id == nodeID }
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text(node?.block ?? "").font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
                Text(node?.title ?? "").font(TypeScale.serif(26, relativeTo: .title)).padding(.top, Space.xs).padding(.bottom, Space.l)
                ForEach(HistoryDictionary.bundled.entries(inNode: nodeID)) { HistoryEntryRow(entry: $0, showYear: true) }
            }
        }.navigationTitle(node?.title ?? "史事").navigationBarTitleDisplayMode(.inline)
    }
}

/// 条目页：正文中提到的其他条目可以直接点开；下面列出同一节的条目和提到它的条目。
@MainActor
struct HistoryEntryView: View {
    @EnvironmentObject private var learning: LearningStore
    let entryID: String
    @State private var next: HistoryEntry?
    @State private var addedCard = false
    @State private var askContext: StudyAskContext?
    private let dict = HistoryDictionary.bundled

    var body: some View {
        Group {
            if let entry = dict.entry(entryID) {
                InkPage(spacing: 0) { content(entry) }
                    .navigationTitle(entry.title).navigationBarTitleDisplayMode(.inline)
            } else {
                ContentUnavailableView("找不到这一条", systemImage: "questionmark")
            }
        }
        .navigationDestination(item: $next) { HistoryEntryView(entryID: $0.id) }
        .sheet(item: $askContext) { StudyAskSheet(context: $0) }
        .environment(\.openURL, OpenURLAction { url in
            guard url.scheme == "studydesk-entry",
                  let id = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "id" })?.value,
                  let target = dict.entry(id) else { return .systemAction }
            next = target
            return .handled
        })
    }

    @ViewBuilder private func content(_ entry: HistoryEntry) -> some View {
        let node = learning.syllabusNodes.first { $0.id == entry.nodeID }
        VStack(alignment: .leading, spacing: 0) {
            Text([entry.yearText, entry.kind, node.map { "\($0.block) · \($0.title)" }].compactMap { $0 }.joined(separator: " · "))
                .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.l)
            Text(entry.title).font(TypeScale.hero).foregroundStyle(Ink.ink).padding(.top, Space.s)
                .textSelection(.enabled).accessibilityIdentifier("history-entry-title")
            if !entry.aliases.isEmpty {
                Text("也叫：" + entry.aliases.joined(separator: "、")).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.xs)
            }
            Text(linkedText(entry)).font(TypeScale.serif(17, relativeTo: .body)).foregroundStyle(Ink.ink).lineSpacing(8)
                .tint(Ink.seal).textSelection(.enabled).padding(.top, Space.xl).accessibilityIdentifier("history-entry-text")
            HStack(spacing: Space.l) {
                Button(addedCard || hasCard(entry) ? "已加入背诵" : "加入背诵卡") { addCard(entry) }
                    .buttonStyle(.inkGlass).disabled(addedCard || hasCard(entry)).accessibilityIdentifier("history-add-card")
                Button("✦ 问 AI") {
                    askContext = StudyAskContext(referenceID: "history:" + entry.id, subject: .history, title: entry.title, quote: "",
                                                 background: entry.title + "\n" + entry.text, source: "研习史事词典（AI 整理，以教材为准）")
                }.buttonStyle(.inkGlass)
            }.padding(.top, Space.xl)

            let mentions = dict.mentions(of: entry.id)
            if !mentions.isEmpty {
                InkSectionHeader(title: "提到这一条的").padding(.top, Space.section).padding(.bottom, Space.xs)
                ForEach(mentions) { HistoryEntryRow(entry: $0, showYear: true) }
            }
            let siblings = dict.entries(inNode: entry.nodeID).filter { $0.id != entry.id }
            if !siblings.isEmpty {
                InkSectionHeader(title: "同一节 · \(node?.title ?? "")").padding(.top, Space.section).padding(.bottom, Space.xs)
                ForEach(siblings) { HistoryEntryRow(entry: $0, showYear: true) }
            }
        }
    }

    /// 正文里的链接词加下划线，点击走 studydesk-entry://open?id=条目ID
    private func linkedText(_ entry: HistoryEntry) -> AttributedString {
        var text = AttributedString(entry.text)
        for link in entry.links {
            var components = URLComponents()
            components.scheme = "studydesk-entry"; components.host = "open"
            components.queryItems = [URLQueryItem(name: "id", value: link.id)]
            guard let range = text.range(of: link.text), let url = components.url else { continue }
            text[range].link = url
            text[range].underlineStyle = .single
            text[range].foregroundColor = Ink.seal
        }
        return text
    }

    private func cardID(_ entry: HistoryEntry) -> String { "history:" + entry.id }
    private func hasCard(_ entry: HistoryEntry) -> Bool { learning.state.cards.contains { $0.id == cardID(entry) } }
    private func addCard(_ entry: HistoryEntry) {
        let front = entry.yearText.map { "\(entry.title)（\($0)）" } ?? entry.title
        learning.updateCard(StudyCard(id: cardID(entry), front: front, back: entry.text, subject: .history, deck: "史事词典",
                                      source: "研习史事词典 · 以教材为准"))
        addedCard = true
    }
}
