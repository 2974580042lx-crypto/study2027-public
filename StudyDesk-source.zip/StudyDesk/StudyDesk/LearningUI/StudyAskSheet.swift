import SwiftUI
import UIKit

@MainActor
struct StudyAskSheet: View {
    @EnvironmentObject private var chat: AppStore
    @Environment(\.dismiss) private var dismiss
    let context: StudyAskContext
    @State private var input = ""
    @State private var settings = false
    @State private var expandedQuote = false
    @State private var ownThreadID: UUID?
    @FocusState private var focused: Bool
    private var messages: [ChatMessage] { chat.threads.first(where: { $0.id == ownThreadID })?.messages ?? [] }
    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 18) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text(context.title).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                            if !context.quote.isEmpty {
                                Text(context.quote).font(.subheadline).lineLimit(expandedQuote ? nil : 3)
                                    .textSelection(.enabled).accessibilityIdentifier("study-selected-quote")
                                if context.quote.count > 90 { Button(expandedQuote ? "收起引用" : "展开引用") { expandedQuote.toggle() }.font(.caption) }
                            }
                        }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 18))
                        if messages.isEmpty {
                            HStack {
                                Button(context.mode == .hint ? "先给我提示" : "解释这段") {
                                    send(context.mode == .hint ? "给我下一步思路，先不要直接公布正确选项。" : "请解释我选中的这段内容。")
                                }.buttonStyle(.glass)
                                if context.subject == .english { Button("翻译") { send("请结合上下文翻译我选中的内容，并简短解释难点。") }.buttonStyle(.glass) }
                            }.disabled(!chat.canUseAI || chat.isGenerating)
                            if context.mode == .hint { Text("交卷前默认先给提示，你也可以直接输入想问的问题。").font(.caption).foregroundStyle(.secondary) }
                        }
                        ForEach(messages) { message in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(message.role == .user ? "我" : (message.providerName ?? "DeepSeek")).font(.caption).foregroundStyle(.secondary)
                                if !message.content.isEmpty { Text(message.content).readingStyle(adjustment: -1).lineSpacing(5).textSelection(.enabled) }
                                if message.state == .streaming {
                                    HStack(spacing: 8) { ProgressView(); Text(message.reasoning.isEmpty ? "正在准备回答" : "正在思考").font(.caption).foregroundStyle(.secondary) }
                                }
                                if let note = message.note { Text(note).font(.caption).foregroundStyle(.secondary) }
                                if let usage = message.usage { Text("\(usage.totalTokens) Tokens").font(.caption2).foregroundStyle(.secondary) }
                            }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.white.opacity(message.role == .user ? 0.06 : 0.015), in: RoundedRectangle(cornerRadius: 18))
                                .id(message.id)
                        }
                        Color.clear.frame(height: 1).id("end")
                    }.padding(18)
                }
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: messages.last?.content) { _, _ in if chat.isGenerating { proxy.scrollTo("end", anchor: .bottom) } }
                .onChange(of: messages.count) { _, _ in proxy.scrollTo("end", anchor: .bottom) }
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    VStack(spacing: 10) {
                        if !chat.canUseAI {
                            Button("连接 AI 后提问") { settings = true }.font(.subheadline).buttonStyle(.glass)
                        }
                        HStack(alignment: .bottom, spacing: 12) {
                            TextField("你的问题…", text: $input, axis: .vertical).lineLimit(1...4).focused($focused)
                                .accessibilityIdentifier("study-question-input").submitLabel(.send)
                            Button {
                                if chat.isGenerating { chat.stopGeneration() } else { send(input) }
                            } label: { Image(systemName: chat.isGenerating ? "stop.fill" : "arrow.up").frame(width: 34, height: 34) }
                                .buttonStyle(.glassProminent)
                                .disabled(!chat.isGenerating && (!chat.canUseAI || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty))
                                .accessibilityLabel(chat.isGenerating ? "停止回答" : "发送学习问题")
                        }.padding(12).glassEffect(.regular, in: .rect(cornerRadius: 24))
                    }.padding(.horizontal, 14).padding(.bottom, 10)
                }
            }
            .navigationTitle("问 AI").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { settings = true } label: { Text(chat.modelTitle).font(.caption) }.accessibilityLabel("AI 设置") }
                ToolbarItem(placement: .topBarTrailing) { Button("完成") { focused = false; dismiss() } }
            }
        }
        .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
        .presentationBackground(.regularMaterial)
        .sheet(isPresented: $settings) { SettingsView() }
        .alert("暂时没有完成", isPresented: Binding(get: { chat.errorMessage != nil }, set: { if !$0 { chat.errorMessage = nil } })) {
            Button("知道了") { chat.errorMessage = nil }
        } message: { Text(chat.errorMessage ?? "") }
        .onAppear { if chat.openStudyConversation(context) { ownThreadID = chat.activeThreadID; input = chat.activeDraft } }
        .onChange(of: input) { _, value in if chat.activeThreadID == ownThreadID { chat.setDraft(value) } }
        .onDisappear { if chat.activeThreadID == ownThreadID && !input.isEmpty { chat.setDraft(input) } }
    }
    private func send(_ question: String) {
        let clean = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, chat.activeThreadID == ownThreadID else { return }
        if chat.send(context.message(for: clean)) { input = ""; focused = false }
    }
}

@MainActor
struct SelectableStudyText: UIViewRepresentable {
    var text: String
    var identifier = "selectable-study-text"
    var onCollect: ((String, String) -> Void)? = nil
    var onAsk: (String) -> Void
    @AppStorage("study2027.reading.serif") private var serif = true
    @AppStorage("study2027.reading.size") private var size = 18.0
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let view = UITextView(); view.delegate = context.coordinator
        view.isEditable = false; view.isSelectable = true; view.isScrollEnabled = false
        view.backgroundColor = .clear; view.textColor = .white; view.tintColor = .systemGray
        view.textContainerInset = .zero; view.textContainer.lineFragmentPadding = 0
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.adjustsFontForContentSizeCategory = true
        updateUIView(view, context: context); return view
    }
    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self; view.accessibilityIdentifier = identifier
        let base = serif ? (UIFont(name: "NotoSerifSC-Regular", size: size) ?? .systemFont(ofSize: size)) : .systemFont(ofSize: size)
        let font = UIFontMetrics(forTextStyle: .body).scaledFont(for: base)
        if view.text != text || view.font != font {
            let style = NSMutableParagraphStyle(); style.lineSpacing = 7
            view.attributedText = NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: UIColor.white, .paragraphStyle: style])
        }
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
        guard let width = proposal.width, width > 0 else { return nil }
        let fit = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude))
        return CGSize(width: width, height: ceil(fit.height))
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: SelectableStudyText
        init(_ parent: SelectableStudyText) { self.parent = parent }
        func textView(_ textView: UITextView, editMenuForTextIn range: NSRange, suggestedActions: [UIMenuElement]) -> UIMenu? {
            guard range.length > 0, NSMaxRange(range) <= (textView.text as NSString).length else { return nil }
            let quote = (textView.text as NSString).substring(with: range)
            let ask = UIAction(title: "问 AI", image: UIImage(systemName: "sparkles")) { [weak self] _ in self?.parent.onAsk(quote) }
            var actions: [UIMenuElement] = [ask]
            if parent.onCollect != nil {
                let context = ReadingWords.context(textView.text, selection: range)
                actions.append(UIAction(title: "加入生词本", image: UIImage(systemName: "character.book.closed")) { [weak self] _ in self?.parent.onCollect?(quote, context) })
            }
            return UIMenu(children: actions + suggestedActions)
        }
    }
}
