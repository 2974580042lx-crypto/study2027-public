import SwiftUI
import UIKit

@MainActor
struct StudyAskSheet: View {
    @EnvironmentObject private var chat: AppStore
    @Environment(\.dismiss) private var dismiss
    let context: StudyAskContext
    @State private var input = ""
    @State private var settings = false
    @State private var expandedQuote = false
    @State private var ownThreadID: UUID?
    @FocusState private var focused: Bool
    private var messages: [ChatMessage] { chat.threads.first(where: { $0.id == ownThreadID })?.messages ?? [] }
    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: Space.xl) {
                        HStack(alignment: .top, spacing: Space.m) {
                            Text("“").font(TypeScale.serif(30)).foregroundStyle(Ink.seal).padding(.top, -6)
                            VStack(alignment: .leading, spacing: Space.s) {
                                if !context.quote.isEmpty {
                                    Text(context.quote).font(TypeScale.note).foregroundStyle(Ink.ink).lineSpacing(6).lineLimit(expandedQuote ? nil : 4)
                                        .textSelection(.enabled).accessibilityIdentifier("study-selected-quote")
                                    if context.quote.count > 90 { Button(expandedQuote ? "收起引用" : "展开引用") { expandedQuote.toggle() }.font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                                }
                                Text("\(context.subject.title) · \(context.title) · \(context.source)")
                                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(2)
                            }
                        }.frame(maxWidth: .infinity, alignment: .leading)
                        if messages.isEmpty {
                            ScrollView(.horizontal, showsIndicators: false) { HStack(spacing: Space.s) {
                                Button(context.mode == .hint ? "先给我提示" : "解释这段") {
                                    send(context.mode == .hint ? "给我下一步思路，先不要直接公布正确选项。" : "请解释我选中的这段内容。")
                                }.buttonStyle(.inkChip)
                                Button("讲讲思路") { send("请讲清这一步的思路和判断依据。") }.buttonStyle(.inkChip)
                                if context.mode != .hint { Button("直接看答案") { send("请直接给出答案，并说明理由。") }.buttonStyle(.inkChip) }
                                if context.subject == .english { Button("翻译") { send("请结合上下文翻译我选中的内容，并简短解释难点。") }.buttonStyle(.inkChip) }
                            }}.disabled(!chat.canUseAI || chat.isGenerating)
                            if context.mode == .hint { Text("交卷前默认先给提示，你也可以直接输入想问的问题。").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                        }
                        ForEach(messages) { message in
                            studyMessage(message)
                                .id(message.id)
                        }
                        Color.clear.frame(height: 1).id("end")
                    }.padding(.horizontal, Space.xl).padding(.top, Space.l).padding(.bottom, Space.xxl)
                }
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: messages.last?.content) { _, _ in if chat.isGenerating { proxy.scrollTo("end", anchor: .bottom) } }
                .onChange(of: messages.count) { _, _ in proxy.scrollTo("end", anchor: .bottom) }
                .inkBottomBar {
                    VStack(spacing: Space.s) {
                        if !chat.canUseAI {
                            Button("连接 AI 后提问") { settings = true }.buttonStyle(.inkChip)
                        }
                        InkComposer(text: $input, placeholder: "继续追问…", isGenerating: chat.isGenerating,
                                    canSend: chat.canUseAI, fieldIdentifier: "study-question-input", focus: $focused,
                                    onSend: { send(input) }, onStop: { chat.stopGeneration() })
                    }
                }
            }
            .navigationTitle("问 AI").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { settings = true } label: { Text(chat.modelTitle).font(TypeScale.serif(12, relativeTo: .caption)) }.accessibilityLabel("AI 设置") }
                ToolbarItem(placement: .topBarTrailing) { Button("完成") { focused = false; dismiss() } }
            }
        }
        .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
        .sheet(isPresented: $settings) { SettingsView() }
        .alert("暂时没有完成", isPresented: Binding(get: { chat.errorMessage != nil }, set: { if !$0 { chat.errorMessage = nil } })) {
            Button("知道了") { chat.errorMessage = nil }
        } message: { Text(chat.errorMessage ?? "") }
        .onAppear { if chat.openStudyConversation(context) { ownThreadID = chat.activeThreadID; input = chat.activeDraft } }
        .onChange(of: input) { _, value in if chat.activeThreadID == ownThreadID { chat.setDraft(value) } }
        .onDisappear { if chat.activeThreadID == ownThreadID && !input.isEmpty { chat.setDraft(input) } }
    }
    private func send(_ question: String) {
        let clean = question.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, chat.activeThreadID == ownThreadID else { return }
        if chat.send(context.message(for: clean)) { input = ""; focused = false }
    }

    @ViewBuilder private func studyMessage(_ message: ChatMessage) -> some View {
        if message.role == .user {
            HStack {
                Spacer(minLength: 42)
                Text(message.content).font(TypeScale.serif(15)).foregroundStyle(Ink.ink).lineSpacing(5).textSelection(.enabled)
                    .padding(.horizontal, Space.l).padding(.vertical, Space.m)
                    .background(Ink.raised, in: RoundedRectangle(cornerRadius: 20))
            }
        } else {
            VStack(alignment: .leading, spacing: Space.m) {
                Text(message.providerName ?? "DeepSeek").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                if !message.reasoning.isEmpty, let threadID = ownThreadID { ReasoningView(message: message, threadID: threadID) }
                if !message.content.isEmpty {
                    Text(message.content).font(TypeScale.answer).foregroundStyle(Ink.ink).lineSpacing(9).textSelection(.enabled)
                }
                if message.state == .streaming {
                    HStack(spacing: Space.s) { ProgressView().controlSize(.small); Text(message.reasoning.isEmpty ? "正在准备回答" : "正在思考…") }
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                } else {
                    HStack(spacing: 20) {
                        Button { UIPasteboard.general.string = message.content } label: { Image(systemName: "doc.on.doc") }.accessibilityLabel("复制回答")
                        if messages.last?.id == message.id {
                            Button { chat.regenerate() } label: { Image(systemName: "arrow.clockwise") }
                                .disabled(chat.isGenerating || !chat.canUseAI).accessibilityLabel("重新回答")
                        }
                        Text("已记入今日学习").font(TypeScale.caption)
                        Spacer()
                        if let usage = message.usage { Text("\(usage.totalTokens) Tokens").font(.system(size: 10)).monospacedDigit() }
                    }.font(TypeScale.serif(13)).foregroundStyle(Ink.ink3).buttonStyle(.plain)
                }
                if let note = message.note { Text(note).font(TypeScale.caption).foregroundStyle(Ink.ink3) }
            }.frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

@MainActor
struct SelectableStudyText: UIViewRepresentable {
    var text: String
    var identifier = "selectable-study-text"
    var onCollect: ((String, String) -> Void)? = nil
    var onAsk: (String) -> Void
    @AppStorage("study2027.reading.serif") private var serif = true
    @AppStorage("study2027.reading.size") private var size = 18.0
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> UITextView {
        let view = UITextView(); view.delegate = context.coordinator
        view.isEditable = false; view.isSelectable = true; view.isScrollEnabled = false
        view.backgroundColor = .clear; view.textColor = UIColor(Ink.ink); view.tintColor = UIColor(Ink.ink2)
        view.textContainerInset = .zero; view.textContainer.lineFragmentPadding = 0
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        view.adjustsFontForContentSizeCategory = true
        updateUIView(view, context: context); return view
    }
    func updateUIView(_ view: UITextView, context: Context) {
        context.coordinator.parent = self; view.accessibilityIdentifier = identifier
        let base = serif ? (UIFont(name: "NotoSerifSC-Regular", size: size) ?? .systemFont(ofSize: size)) : .systemFont(ofSize: size)
        let font = UIFontMetrics(forTextStyle: .body).scaledFont(for: base)
        if view.text != text || view.font != font {
            let style = NSMutableParagraphStyle(); style.lineSpacing = 7
            view.attributedText = NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: UIColor(Ink.ink), .paragraphStyle: style])
        }
    }
    func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
        guard let width = proposal.width, width > 0 else { return nil }
        let fit = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude))
        return CGSize(width: width, height: ceil(fit.height))
    }
    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: SelectableStudyText
        init(_ parent: SelectableStudyText) { self.parent = parent }
        func textView(_ textView: UITextView, editMenuForTextIn range: NSRange, suggestedActions: [UIMenuElement]) -> UIMenu? {
            guard range.length > 0, NSMaxRange(range) <= (textView.text as NSString).length else { return nil }
            let quote = (textView.text as NSString).substring(with: range)
            let ask = UIAction(title: "问 AI", image: UIImage(systemName: "sparkles")) { [weak self] _ in self?.parent.onAsk(quote) }
            var actions: [UIMenuElement] = [ask]
            if parent.onCollect != nil {
                let context = ReadingWords.context(textView.text, selection: range)
                actions.append(UIAction(title: "加入生词本", image: UIImage(systemName: "character.book.closed")) { [weak self] _ in self?.parent.onCollect?(quote, context) })
            }
            return UIMenu(children: actions + suggestedActions)
        }
    }
}
