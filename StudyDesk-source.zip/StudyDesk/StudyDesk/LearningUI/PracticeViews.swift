import SwiftUI
import AVFoundation

@MainActor
struct SubjectHub: View {
    @EnvironmentObject private var learning: LearningStore
    let subject: StudySubject
    @State private var showNewCard = false
    private var decks: [String] { Array(Set(learning.state.cards.filter { $0.subject == subject }.map(\.deck))).sorted() }
    private var groups: [String] { Array(Set(learning.state.questions.filter { $0.subject == subject }.map(\.group))).sorted { a, b in
        if subject == .politics {
            let ay = Int(a.prefix(4)) ?? 0, by = Int(b.prefix(4)) ?? 0
            if ay != by { return ay > by }
        }
        return a < b
    } }
    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                Text(subject == .english ? "词汇与阅读" : subject == .history ? "历史与史料" : "知识与练习")
                    .font(TypeScale.serif(28, relativeTo: .title)).padding(.vertical, Space.xl)
                if subject == .english {
                    NavigationLink { ReadingLibraryView() } label: {
                        InkRow(title: "英语阅读", value: "原文 · 真题 · 生词")
                    }.buttonStyle(.plain).accessibilityIdentifier("english-reading-library")
                    NavigationLink { ReadingWordListView() } label: {
                        InkRow(title: "阅读生词本", value: "\(learning.readingWords.count) 个词")
                    }.buttonStyle(.plain).accessibilityIdentifier("reading-word-list")
                }
                VStack(alignment: .leading, spacing: 0) {
                    InkSectionHeader(title: subject == .english ? "背单词" : "知识卡").padding(.top, Space.section).padding(.bottom, Space.s)
                    ForEach(decks, id: \.self) { deck in
                        NavigationLink { DeckDetailView(subject: subject, deck: deck) } label: {
                            InkRow(title: deck, value: "\(learning.state.cards.filter { $0.subject == subject && $0.deck == deck }.count) 张 · 到期 \(learning.queue(subject: subject, deck: deck, reviewsOnly: true).count) 张")
                        }.buttonStyle(.plain)
                    }
                    Button { showNewCard = true } label: { Label("添加自己的知识卡", systemImage: "plus") }.buttonStyle(.inkGlass).padding(.top, Space.l)
                }
                VStack(alignment: .leading, spacing: 0) {
                    InkSectionHeader(title: "练习").padding(.top, Space.section).padding(.bottom, Space.s)
                    ForEach(groups, id: \.self) { group in
                        NavigationLink { QuestionPracticeView(questions: learning.state.questions.filter { $0.subject == subject && $0.group == group }) } label: {
                            InkRow(title: group, value: "\(learning.state.questions.filter { $0.subject == subject && $0.group == group }.count) 题")
                        }.buttonStyle(.plain)
                    }
                    Text(subject == .politics ? "历年题按最近年份优先排列。公开整理题尚待原卷逐题校核；已发现跨来源答案差异的题暂未收录。2025—2026 年仍在补齐。" : "基础练习和导入真题分别保留来源与年份。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.m)
                }
                NavigationLink { StudyLibrary(initialSubject: subject) } label: { InkRow(title: "\(subject.title)资料与真题来源", divider: false) }
                    .buttonStyle(.plain).padding(.top, Space.section)
            }
        }.navigationTitle(subject.title).navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showNewCard) { CardEditor(subject: subject) }
    }
}

@MainActor
struct DeckDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    let subject: StudySubject
    let deck: String
    @State private var search = ""
    private var cards: [StudyCard] { learning.state.cards.filter { $0.subject == subject && $0.deck == deck && (search.isEmpty || $0.front.localizedCaseInsensitiveContains(search) || $0.back.localizedCaseInsensitiveContains(search)) } }
    var body: some View {
        List {
            Section {
                NavigationLink { CardReviewView(subject: subject, deck: deck) } label: { Label("开始学习", systemImage: "play.fill") }.accessibilityIdentifier("start-word-review")
                NavigationLink { CardReviewView(subject: subject, deck: deck, reviewsOnly: true) } label: { Label("只复习到期内容", systemImage: "arrow.clockwise") }
                if subject == .english {
                    Text("每日新词目标 \(learning.state.preferences.dailyWords) 个；先复习，再学习新词。到达目标后可以在设置中调整。").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
            }
            Section("词条与卡片 · \(cards.count)") {
                ForEach(cards) { card in
                    NavigationLink { CardDetailView(cardID: card.id) } label: {
                        HStack { VStack(alignment: .leading, spacing: 5) { Text(card.front).font(TypeScale.subject); Text(card.reviews == 0 ? "未学习" : "复习 \(card.reviews) 次").font(TypeScale.caption).foregroundStyle(Ink.ink3) }; Spacer(); if card.reviews > 0 { Image(systemName: card.due <= Date() ? "clock" : "checkmark").foregroundStyle(Ink.ink3) } }
                    }
                }
            }
        }.scrollContentBackground(.hidden).background(AppBackground()).listRowBackground(Color.clear).listRowSeparatorTint(Ink.line)
            .searchable(text: $search, prompt: "搜索单词或释义")
            .navigationTitle(deck).navigationBarTitleDisplayMode(.inline)
    }
}

@MainActor
struct CardReviewView: View {
    @EnvironmentObject private var learning: LearningStore
    var subject: StudySubject? = nil
    var deck: String? = nil
    var reviewsOnly = false
    var onlyIDs: Set<String>? = nil
    @State private var ids: [String] = []
    @State private var index = 0
    @State private var revealed = false
    @State private var initialized = false
    @State private var askContext: StudyAskContext?
    @State private var speech = AVSpeechSynthesizer()
    private var current: StudyCard? { guard ids.indices.contains(index) else { return nil }; return learning.state.cards.first { $0.id == ids[index] } }
    var body: some View {
        InkPage(spacing: Space.xl) {
            VStack(alignment: .leading, spacing: Space.xl) {
                if let card = current {
                    HStack(spacing: Space.s) {
                        SealTag(text: card.deck.contains("阅读") ? "阅读生词" : (card.reviews == 0 ? "新学" : "复习"))
                        Text(card.reviews == 0 ? card.deck : "第 \(card.reviews + 1) 次复习")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(1)
                    }
                    Text(card.front)
                        .font(card.subject == .english ? TypeScale.word : TypeScale.serif(34, relativeTo: .largeTitle))
                        .minimumScaleFactor(0.5).lineLimit(2)
                        .frame(maxWidth: .infinity, alignment: .center).multilineTextAlignment(.center)
                        .padding(.top, Space.xl).textSelection(.enabled).accessibilityIdentifier("review-front")
                    if card.subject == .english {
                        HStack(spacing: Space.s) {
                            Text(card.phonetic.isEmpty ? "音标待补" : card.phonetic)
                            Button { pronounce(card.front, using: speech) } label: { Image(systemName: "speaker.wave.2") }
                                .accessibilityLabel("朗读单词")
                        }.font(TypeScale.serif(15)).foregroundStyle(Ink.ink3).frame(maxWidth: .infinity)
                    }
                    if revealed {
                        InkRule().padding(.top, Space.s)
                        SelectableStudyText(text: card.back, identifier: "review-answer") { quote in ask(card, quote: quote) }
                        if !card.note.isEmpty {
                            HStack(alignment: .top, spacing: Space.s) {
                                Text("“").font(TypeScale.serif(34)).foregroundStyle(Ink.seal)
                                Text(card.note).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).textSelection(.enabled)
                            }
                        }
                        Text(card.source).font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    } else {
                        Button("显示释义") { revealed = true }.buttonStyle(.inkGlass)
                            .frame(maxWidth: .infinity).padding(.top, Space.xl).accessibilityIdentifier("reveal-card")
                        Text("先在心里回忆，再展开答案。")
                            .font(TypeScale.caption).foregroundStyle(Ink.ink3).frame(maxWidth: .infinity)
                    }
                } else {
                    ContentUnavailableView(index > 0 ? "这一轮完成了" : "暂时没有待复习内容", systemImage: "checkmark.circle", description: Text(index > 0 ? "已完成 \(index) 张卡片，学习记录已保存。" : "到期内容会自动出现；新词数量可在学习设置中调整。"))
                }
            }
        }
        .inkBottomBar {
            if revealed, let card = current {
                HStack(spacing: 4) {
                    ForEach(RecallGrade.allCases, id: \.self) { grade in
                        Button {
                            learning.review(id: card.id, grade: grade); index += 1; revealed = false
                            UISelectionFeedbackGenerator().selectionChanged()
                        } label: {
                            VStack(spacing: 3) {
                                Text(grade.title).font(TypeScale.serif(14).weight(grade == .good ? .semibold : .regular))
                                Text(gradeInterval(grade, for: card)).font(TypeScale.serif(10)).opacity(0.72)
                            }
                            .foregroundStyle(grade == .good ? Ink.onSolid : Ink.ink2)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(grade == .good ? Ink.solid : Color.clear, in: Capsule())
                        }.buttonStyle(.plain).accessibilityIdentifier("grade-\(grade.rawValue)")
                    }
                }.padding(6).glassEffect(.regular.interactive(), in: .capsule)
            }
        }
        .navigationTitle(subject == .english ? "背单词" : "回忆与复习").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    if current != nil { Text("\(index + 1) / \(ids.count)").font(TypeScale.label).foregroundStyle(Ink.ink3).monospacedDigit() }
                }
                ToolbarItem(placement: .topBarTrailing) { if let card = current { Button { ask(card, quote: card.front) } label: { Image(systemName: "sparkles") }.accessibilityLabel("问这个单词或知识点") } }
            }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .onAppear { if !initialized { ids = learning.queue(subject: subject, deck: deck, reviewsOnly: reviewsOnly, onlyIDs: onlyIDs).map(\.id); initialized = true } }
            .onDisappear { speech.stopSpeaking(at: .immediate) }
    }
    /// 按 FSRS 预演这一档评分后的下次复习时间（只在副本上计算，不改动真实卡片）。
    private func gradeInterval(_ grade: RecallGrade, for card: StudyCard) -> String {
        let now = Date()
        var preview = card
        guard (try? preview.review(grade, at: now)) != nil else { return "" }
        let minutes = max(1, Int(preview.due.timeIntervalSince(now) / 60))
        if minutes < 60 { return "\(minutes) 分" }
        if minutes < 60 * 24 { return "\(minutes / 60) 小时" }
        let days = minutes / (60 * 24)
        return days < 60 ? "\(days) 天" : "\(days / 30) 个月"
    }
    private func ask(_ card: StudyCard, quote: String) {
        askContext = StudyAskContext(referenceID: "card:" + card.id, subject: card.subject, title: card.front, quote: quote,
                                     background: card.front + "\n" + card.back, source: card.source, mode: card.subject == .english ? .vocabulary : .explain)
    }
}

@MainActor
private func pronounce(_ word: String, using speech: AVSpeechSynthesizer) {
    speech.stopSpeaking(at: .immediate); let utterance = AVSpeechUtterance(string: word)
    utterance.voice = AVSpeechSynthesisVoice(language: "en-US"); utterance.rate = 0.42; speech.speak(utterance)
}

@MainActor
struct CardDetailView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let cardID: String
    @State private var editing = false
    @State private var assistant = false
    @State private var askContext: StudyAskContext?
    @State private var speech = AVSpeechSynthesizer()
    private var card: StudyCard? { learning.state.cards.first { $0.id == cardID } }
    var body: some View {
        StudyPage {
            if let card {
                VStack(alignment: .leading, spacing: 22) {
                    Text(card.front).font(TypeScale.serif(32)).textSelection(.enabled)
                    if card.subject == .english { Button { pronounce(card.front, using: speech) } label: { Label(card.phonetic.isEmpty ? "朗读" : card.phonetic, systemImage: "speaker.wave.2") }.buttonStyle(.glass) }
                    SelectableStudyText(text: card.back) { quote in askContext = cardContext(card, quote: quote) }
                    if !card.note.isEmpty {
                        InkRule()
                        Text(card.note).font(TypeScale.note).foregroundStyle(Ink.ink2).lineSpacing(6).textSelection(.enabled)
                    }
                    Text(card.source).font(TypeScale.serif(12, relativeTo: .caption)).foregroundStyle(.secondary)
                    if card.reviews > 0 { Text("复习 \(card.reviews) 次 · 下次 \(card.due.formatted(date: .abbreviated, time: .shortened))").font(TypeScale.serif(12, relativeTo: .caption)).foregroundStyle(.secondary) }
                    Button("问 AI") { askContext = cardContext(card, quote: card.front) }.buttonStyle(.glass)
                }
            }
        }.navigationTitle("学习卡").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("编辑") { editing = true } } }
            .sheet(isPresented: $editing) { if let card { CardEditor(subject: card.subject, existing: card) } }
            .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .onDisappear { speech.stopSpeaking(at: .immediate) }
    }
    private func cardContext(_ card: StudyCard, quote: String) -> StudyAskContext {
        StudyAskContext(referenceID: "card:" + card.id, subject: card.subject, title: card.front, quote: quote,
                        background: card.front + "\n" + card.back, source: card.source, mode: card.subject == .english ? .vocabulary : .explain)
    }
}

@MainActor
struct CardEditor: View {
    @EnvironmentObject private var learning: LearningStore
    @Environment(\.dismiss) private var dismiss
    let subject: StudySubject
    var existing: StudyCard? = nil
    @State private var front = ""
    @State private var back = ""
    @State private var note = ""
    @State private var deck = "我的卡片"
    var body: some View {
        NavigationStack { Form {
            Section("正面") { TextField("单词或问题", text: $front, axis: .vertical) }
            Section("背面") { TextEditor(text: $back).frame(minHeight: 130) }
            Section("我的笔记") { TextEditor(text: $note).frame(minHeight: 80) }
            Section("分组") { TextField("例如：红宝书 2027 · 第 1 单元", text: $deck) }
        }.navigationTitle(existing == nil ? "新建卡片" : "编辑卡片").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("保存") {
                var card = existing ?? StudyCard(front: front, back: back, subject: subject, deck: deck, source: "个人整理")
                card.front = front; card.back = back; card.note = note; card.deck = deck
                if existing != nil && existing?.back != back { card.source += " · 个人修订" }
                learning.updateCard(card); dismiss()
            }.disabled(front.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || back.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
        } }.onAppear { if let card = existing { front = card.front; back = card.back; note = card.note; deck = card.deck } }
    }
}

@MainActor
struct QuestionPracticeView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    let questions: [StudyQuestion]
    @State private var index = 0
    @State private var selected: Set<Int> = []
    @State private var submitted = false
    @State private var assistant = false
    @State private var askContext: StudyAskContext?
    var body: some View {
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                if questions.indices.contains(index) {
                    let q = questions[index]
                    HStack(spacing: 5) {
                        ForEach(0..<min(6, questions.count), id: \.self) { step in
                            Capsule().fill(step <= index ? Ink.ink : Ink.line).frame(width: 18, height: 2)
                        }
                        Spacer()
                        Text("\(index + 1) / \(questions.count)").monospacedDigit()
                    }.font(TypeScale.caption).foregroundStyle(Ink.ink3)
                    Text("\(q.subject.title) · \(q.group) · \(q.multiple ? "多选题" : "单选题")")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.xl)
                    Text(String(format: "%02d", index + 1)).font(TypeScale.serif(38)).foregroundStyle(Ink.ink3).padding(.top, Space.s)
                    SelectableStudyText(text: q.stem, identifier: "selectable-question-stem") { quote in ask(q, quote: quote) }
                        .padding(.top, Space.s)
                    InkRule().padding(.top, Space.l)
                    ForEach(q.options.indices, id: \.self) { i in
                        Button {
                            guard !submitted else { return }
                            if q.multiple { if selected.contains(i) { selected.remove(i) } else { selected.insert(i) } }
                            else { selected = [i] }
                        } label: { InkOptionRow(letter: String(UnicodeScalar(65+i)!), text: q.options[i], state: optionState(q, at: i), divider: i < q.options.count - 1) }
                        .buttonStyle(.plain).accessibilityIdentifier("option-\(i)")
                            .contextMenu { Button("问这个选项", systemImage: "sparkles") { ask(q, quote: String(UnicodeScalar(65+i)!) + ". " + q.options[i]) } }
                    }
                    if submitted {
                        Group {
                            if q.isCorrect(selected) {
                                VStack(alignment: .leading, spacing: Space.m) {
                                    Text("答对了").font(TypeScale.note).foregroundStyle(Ink.seal)
                                    SelectableStudyText(text: q.explanation) { quote in ask(q, quote: quote) }
                                }
                            } else {
                                SealNote {
                                    VStack(alignment: .leading, spacing: Space.s) {
                                        Text("错选 \(selectedLetters)。\(q.explanation)")
                                        Text("已记录到错题本").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                                    }
                                }
                            }
                        }.padding(.top, 28).accessibilityIdentifier("question-result")
                    }
                    Text(q.source).font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.xl)
                    if let raw = q.sourceURL, let url = URL(string: raw), url.scheme == "https" { Link("查看资料来源", destination: url).font(TypeScale.caption) }
                } else { ContentUnavailableView("本组练习完成", systemImage: "checkmark.circle", description: Text("答案与错题已保存，可在复习页继续。")) }
            }
        }
        .inkBottomBar {
            if questions.indices.contains(index) {
                let q = questions[index]
                if submitted {
                    InkActionBar {
                        Button("✦ 问 AI") { ask(q, quote: q.stem) }
                    } primary: {
                        Button(index + 1 == questions.count ? "完成本组" : "下一题 ›") { index += 1; submitted = false; selected = [] }
                    }
                } else {
                    HStack { Spacer(minLength: 70); Button("提交答案") { learning.recordAnswer(q, selected: selected); submitted = true }.buttonStyle(.inkPrimary).disabled(selected.isEmpty).accessibilityIdentifier("submit-question") }
                }
            }
        }
        .navigationTitle("练习").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { if questions.indices.contains(index) {
                Button { ask(questions[index], quote: questions[index].stem) } label: { Label("问整题", systemImage: "sparkles") }.accessibilityIdentifier("ask-current-question")
            } } }
            .sheet(item: $askContext) { StudyAskSheet(context: $0) }
            .fullScreenCover(isPresented: $assistant) { StudyAssistantView() }
    }
    private func ask(_ q: StudyQuestion, quote: String) {
        askContext = .question(q, quote: quote, submitted: submitted, selected: selected)
    }
    private func optionState(_ question: StudyQuestion, at index: Int) -> InkOptionState {
        if !submitted { return selected.contains(index) ? .selected : .idle }
        if question.answers.contains(index) { return .correct }
        if selected.contains(index) { return .wrongPick }
        return .other
    }
    private var selectedLetters: String {
        selected.sorted().map { String(UnicodeScalar(65 + $0)!) }.joined(separator: "、")
    }
}

@MainActor
struct ReviewHub: View {
    @EnvironmentObject private var learning: LearningStore
    var body: some View {
        InkPage(spacing: 0) { VStack(alignment: .leading, spacing: 0) {
            Text("今日复习").font(TypeScale.serif(29, relativeTo: .title)).padding(.vertical, Space.xl)
            NavigationLink { CardReviewView(reviewsOnly: true) } label: {
                InkRow(title: "到期复习", value: "\(learning.queue(reviewsOnly: true).count) 张卡片")
            }.buttonStyle(.plain)
            NavigationLink { QuestionPracticeView(questions: learning.wrongQuestions) } label: {
                InkRow(title: "错题重做", value: "\(learning.wrongQuestions.count) 道题待巩固")
            }.buttonStyle(.plain)
            Text("答对后会退出待重做列表，原来的作答记录仍保留在学习时间轴。")
                .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.top, Space.m)
            InkSectionHeader(title: "按科目查看").padding(.top, Space.section)
            ForEach(StudySubject.allCases) { subject in
                NavigationLink { SubjectHub(subject: subject) } label: { InkRow(title: subject.title) }.buttonStyle(.plain)
            }
        } }.navigationTitle("复习").navigationBarTitleDisplayMode(.inline)
    }
}
