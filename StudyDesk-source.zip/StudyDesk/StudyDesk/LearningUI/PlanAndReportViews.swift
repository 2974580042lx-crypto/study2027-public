import SwiftUI

/// 首页的今日计划：AI 汇总的「明天做什么」+ 昨天没做完的 + 自己加的，点一下打勾
@MainActor
struct TodayPlanSection: View {
    @EnvironmentObject private var learning: LearningStore
    @State private var adding = false
    @State private var newText = ""
    @State private var editing: PlanItem?
    @State private var editText = ""

    var body: some View {
        let plan = learning.todayPlan()
        VStack(alignment: .leading, spacing: 0) {
            InkSectionHeader(title: "今日计划", trailing: plan.items.isEmpty ? nil : "\(plan.items.filter(\.done).count) / \(plan.items.count)")
            ForEach(plan.items) { item in
                Button { learning.togglePlanItem(item.id) } label: {
                    HStack(alignment: .firstTextBaseline, spacing: Space.m) {
                        Image(systemName: item.done ? "checkmark.square" : "square").font(.system(size: 15))
                            .foregroundStyle(item.done ? Ink.seal : Ink.ink3)
                        Text(item.text).font(TypeScale.serif(15)).foregroundStyle(item.done ? Ink.ink3 : Ink.ink)
                            .strikethrough(item.done, color: Ink.ink3).multilineTextAlignment(.leading)
                        Spacer(minLength: 0)
                        if item.origin == .carried { Text("昨天的").font(TypeScale.caption).foregroundStyle(Ink.ink3) }
                    }.padding(.vertical, 9).contentShape(Rectangle())
                }
                .buttonStyle(.plain).accessibilityIdentifier("plan-item")
                .contextMenu {
                    Button("修改") { editText = item.text; editing = item }
                    Button("删除", role: .destructive) { learning.deletePlanItem(item.id) }
                }
            }
            if plan.items.isEmpty {
                Text("AI 汇总完昨天，会把「明天做什么」放到这里；也可以自己加。")
                    .font(TypeScale.caption).foregroundStyle(Ink.ink3).padding(.vertical, Space.s)
            }
            Button { newText = ""; adding = true } label: {
                Label("加一件事", systemImage: "plus").font(TypeScale.label).foregroundStyle(Ink.ink3)
            }.buttonStyle(.plain).padding(.top, Space.xs).accessibilityIdentifier("plan-add")
        }
        .alert("加一件事", isPresented: $adding) {
            TextField("比如：313 论述题一道", text: $newText)
            Button("取消", role: .cancel) {}
            Button("加上") { learning.addPlanItem(newText) }
        }
        .alert("修改", isPresented: Binding(get: { editing != nil }, set: { if !$0 { editing = nil } })) {
            TextField("计划", text: $editText)
            Button("取消", role: .cancel) {}
            Button("保存") { if let item = editing { learning.editPlanItem(item.id, text: editText) } }
        }
    }
}

/// 周报：本周数据 + 和上周对比 + AI 错因诊断
@MainActor
struct WeeklyReportView: View {
    @EnvironmentObject private var learning: LearningStore
    @EnvironmentObject private var chat: AppStore
    @State private var weekStart = WeeklyReport.weekStart(for: Date())
    @State private var running = false
    @State private var issue: String?

    var body: some View {
        let r = learning.weeklyReport(weekStart: weekStart)
        let isThisWeek = weekStart == WeeklyReport.weekStart(for: Date())
        InkPage(spacing: 0) {
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    Button { shift(-1) } label: { Image(systemName: "chevron.left") }.accessibilityLabel("上一周")
                    Spacer()
                    Text(rangeText(r)).font(TypeScale.label).foregroundStyle(Ink.ink2)
                    Spacer()
                    Button { shift(1) } label: { Image(systemName: "chevron.right") }.disabled(isThisWeek).accessibilityLabel("下一周")
                }.buttonStyle(.plain).foregroundStyle(Ink.ink2).padding(.top, Space.l)

                Text(hours(r.seconds)).font(TypeScale.hero).foregroundStyle(Ink.ink).padding(.top, Space.l)
                    .accessibilityIdentifier("weekly-hours")
                Text("学习 \(r.studyDays) 天" + compare(r.seconds, r.previousSeconds))
                    .font(TypeScale.label).foregroundStyle(Ink.ink3).padding(.top, Space.xs)
                VStack(spacing: 0) {
                    ForEach(StudySubject.allCases) { s in
                        InkRow(title: s.title, value: hours(r.subjectSeconds[s] ?? 0))
                    }
                }.padding(.top, Space.l)

                InkSectionHeader(title: "做题").padding(.top, Space.section).padding(.bottom, Space.xs)
                InkRow(title: "选择题", detail: r.previousAccuracy.map { "上周 \(pct($0))" },
                       value: r.answered == 0 ? "没做" : "\(r.answered) 道 · \(r.accuracy.map(pct) ?? "")")
                InkRow(title: "大题批改", value: r.essayCount == 0 ? "没做" : "\(r.essayCount) 次 · 平均得分率 \(r.essayRatio.map(pct) ?? "")")
                InkRow(title: "单词复习", value: "\(r.wordsReviewed) 次")
                InkRow(title: "考纲掌握度变化", value: "\(r.masteryChanges) 处", divider: false)

                if !r.weakGroups.isEmpty {
                    InkSectionHeader(title: "错得最集中").padding(.top, Space.section).padding(.bottom, Space.xs)
                    ForEach(r.weakGroups, id: \.group) { g in
                        InkRow(title: g.group, detail: g.subject.title, value: "错 \(g.wrong) / \(g.answered)", valueIsSeal: true)
                    }
                }

                InkSectionHeader(title: "AI 诊断").padding(.top, Space.section).padding(.bottom, Space.s)
                if let d = learning.weeklyDiagnosis(weekStart: weekStart) {
                    Text(d.diagnosis).font(TypeScale.note).foregroundStyle(Ink.ink).lineSpacing(6).accessibilityIdentifier("weekly-diagnosis")
                    ForEach(Array(d.errorTypes.enumerated()), id: \.offset) { _, e in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(e.type).font(TypeScale.serif(15).weight(.semibold)).foregroundStyle(Ink.seal)
                            Text(e.detail).font(TypeScale.serif(15)).foregroundStyle(Ink.ink2).lineSpacing(4)
                        }.padding(.top, Space.m)
                    }
                    if !d.focus.isEmpty {
                        Text("下周重点").font(TypeScale.label.weight(.semibold)).foregroundStyle(Ink.ink2).padding(.top, Space.l)
                        ForEach(Array(d.focus.enumerated()), id: \.offset) { i, f in
                            HStack(alignment: .firstTextBaseline, spacing: Space.s) {
                                Text("\(i + 1).").font(TypeScale.serif(15)).foregroundStyle(Ink.ink3)
                                Text(f).font(TypeScale.serif(15)).foregroundStyle(Ink.ink).lineSpacing(4)
                                Spacer(minLength: 0)
                                if isThisWeek || weekStart == WeeklyReport.weekStart(for: Date()).addingTimeInterval(-7 * 86_400) {
                                    Button { learning.addPlanItem(f) } label: { Image(systemName: "plus.circle") }
                                        .buttonStyle(.plain).foregroundStyle(Ink.ink3).accessibilityLabel("加进今日计划")
                                }
                            }.padding(.top, Space.s)
                        }
                    }
                } else {
                    Text(r.answered + r.essayCount == 0 && r.seconds == 0 ? "这周还没有记录。" : "根据这周的错题和批改，判断主要错在哪一类，给出下周重点。")
                        .font(TypeScale.caption).foregroundStyle(Ink.ink3)
                }
                Button {
                    running = true; issue = nil
                    Task {
                        defer { running = false }
                        do { try await learning.runWeeklyDiagnosis(weekStart: weekStart, chat: chat) } catch { issue = error.localizedDescription }
                    }
                } label: {
                    HStack(spacing: Space.s) {
                        if running { ProgressView().controlSize(.small) }
                        Text(running ? "正在分析…" : (learning.weeklyDiagnosis(weekStart: weekStart) == nil ? "✦ 让 AI 诊断这一周" : "重新诊断"))
                    }
                }
                .buttonStyle(.inkGlass).disabled(running || !(chat.canUseAI || chat.isPreview) || (r.answered + r.essayCount == 0 && r.seconds == 0))
                .padding(.top, Space.l).accessibilityIdentifier("weekly-diagnose")
                if let issue { Text(issue).font(TypeScale.caption).foregroundStyle(Ink.seal).padding(.top, Space.s) }
            }
        }
        .navigationTitle("周报").navigationBarTitleDisplayMode(.inline)
    }

    private func shift(_ weeks: Int) {
        if let d = Calendar.current.date(byAdding: .day, value: 7 * weeks, to: weekStart) { weekStart = WeeklyReport.weekStart(for: d) }
    }
    private func rangeText(_ r: WeeklyReport) -> String {
        let last = r.weekEnd.addingTimeInterval(-1)
        return "\(r.weekStart.formatted(.dateTime.month().day())) — \(last.formatted(.dateTime.month().day()))"
    }
    private func hours(_ s: TimeInterval) -> String {
        s < 3600 ? "\(Int(s / 60)) 分钟" : String(format: "%.1f 小时", s / 3600)
    }
    private func pct(_ v: Double) -> String { "\(Int((v * 100).rounded()))%" }
    private func compare(_ now: TimeInterval, _ before: TimeInterval) -> String {
        guard before > 0 else { return "" }
        let diff = (now - before) / before
        return abs(diff) < 0.05 ? " · 和上周差不多" : " · 比上周" + (diff > 0 ? "多" : "少") + " \(Int(abs(diff * 100).rounded()))%"
    }
}
