import SwiftUI

private final class DigestBuffer { var value = TranslationAccumulator() }

extension AppStore {
    /// 一次性请求：不进聊天记录，不带学习档案，只返回完整文本。用于每日汇总。
    func completeOnce(system: String, user: String, previewReply: String = StudyDigestPreview.reply) async throws -> String {
        guard canUseAI else { throw ChatError.server(aiConnectionMessage) }
        var config = AppSettings()
        config.model = .flash
        config.thinkingEnabled = false
        config.maxOutputTokens = 4096
        config.systemPrompt = system
        let request = ChatRequest(settings: config, messages: [ChatMessage(role: .user, content: user)])
        let buffer = DigestBuffer()
        if isPreview {
            buffer.value.consume(StreamEvent(content: previewReply, finishReason: "stop", isDone: true))
        } else if settings.selectedProvider == .chatGPT {
            try await subscription.stream(request: request, model: settings.subscriptionModelID, effort: .automatic, onProgress: { _ in }) { event in buffer.value.consume(event) }
        } else {
            try await DeepSeekClient().stream(request: request, key: apiKey) { event in buffer.value.consume(event) }
        }
        return try buffer.value.result()
    }
}

enum StudyDigestPreview {
    static let reply = """
    {"summary":"昨天主要在 313 上推进了秦汉，政治做了一组马原选择题。郡国并行一处没写出来，其余顺利。",
     "progress":[{"nodeID":"h-cn-ancient-02","mastery":2},{"nodeID":"p-mayuan-02","mastery":1}],
     "weakPoints":["秦汉：郡国并行的原因没写出来"],
     "tomorrow":["313：先默写秦汉框架，再往下推三国两晋南北朝","政治：重做昨天的错题"],
     "memories":{"add":[{"text":"秦汉郡国并行的原因容易忘","category":"weakPoints"}],"remove":[]}}
    """
}

extension LearningStore {
    var syllabusNodes: [SyllabusNode] { state.syllabus ?? SyllabusSeed.nodes() }
    var memoryItems: [MemoryItem] { state.memories ?? [] }
    var digestList: [DailyDigest] { state.digests ?? [] }
    var autoDigestEnabled: Bool { state.autoDigest != false }
    /// 最近一条还没看过的自动汇总
    var unseenDigest: DailyDigest? { digestList.last(where: { !$0.seen }) }
    func digest(on day: Date) -> DailyDigest? { digestList.first { $0.id == StudyDigest.id(for: day) } }

    /// 首次升级时补上考纲章节和记忆（旧学习档案按行拆成记忆，原文保留）。
    func preparePlanData() {
        guard writable else { return }
        var changed = false
        if state.syllabus == nil { state.syllabus = SyllabusSeed.nodes(); changed = true }
        if state.memories == nil { state.memories = StudyMemory.migrate(profile: state.personalMemory); changed = true }
        if changed { save() }
    }

    func digestInput(for day: Date) -> StudyDigest.Input {
        StudyDigest.Input(day: day, events: state.events, nodes: syllabusNodes, memories: memoryItems, examDate: state.preferences.examDate)
    }

    /// 汇总一天。automatic 为 true 时不弹错误，只记失败。
    func runDigest(for day: Date, chat: AppStore, automatic: Bool) async throws {
        guard writable else { return }
        let input = digestInput(for: day)
        let count = StudyDigest.relevantEvents(input.events, day: day).count
        guard count > 0 else { throw StudyFailure.message("这一天还没有记录，先学一会儿或记一笔再汇总。") }
        let text = try await chat.completeOnce(system: StudyDigest.systemPrompt, user: StudyDigest.userMessage(input))
        let result = try StudyDigest.parse(text)
        StudyDigest.apply(result, to: &state, day: day, eventCount: count, automatic: automatic)
        save()
    }

    /// 每天第一次打开时，补汇总最近几天没整理的记录。失败就安静地等下次。
    func runPendingDigests(chat: AppStore) async {
        guard autoDigestEnabled, !digesting, chat.canUseAI || chat.isPreview else { return }
        let days = StudyDigest.pendingDays(events: state.events, digests: digestList)
        guard !days.isEmpty else { return }
        digesting = true
        defer { digesting = false }
        for day in days {
            do { try await runDigest(for: day, chat: chat, automatic: true) }
            catch { break }
        }
    }

    func markDigestSeen(_ id: String) {
        guard let i = state.digests?.firstIndex(where: { $0.id == id }), state.digests?[i].seen == false else { return }
        state.digests?[i].seen = true; save()
    }

    // MARK: 考纲与记忆的编辑

    func setMastery(nodeID: String, level: Int) {
        guard writable else { return }
        var nodes = syllabusNodes
        guard let i = nodes.firstIndex(where: { $0.id == nodeID }) else { return }
        nodes[i].setMastery(level); state.syllabus = nodes; save()
    }
    func renameNode(_ nodeID: String, title: String) {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard writable, !t.isEmpty, let i = state.syllabus?.firstIndex(where: { $0.id == nodeID }) else { return }
        state.syllabus?[i].title = String(t.prefix(40)); save()
    }
    func addNode(subject: StudySubject, block: String, title: String) {
        let t = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard writable, !t.isEmpty else { return }
        var nodes = syllabusNodes
        let order = (nodes.filter { $0.subject == subject && $0.block == block }.map(\.order).max() ?? nodes.count) + 1
        nodes.append(SyllabusNode(id: "user-\(UUID().uuidString.prefix(8))", subject: subject, block: block, title: String(t.prefix(40)), order: order))
        state.syllabus = nodes; save()
    }
    func deleteNode(_ nodeID: String) {
        guard writable else { return }
        var nodes = syllabusNodes; nodes.removeAll { $0.id == nodeID }; state.syllabus = nodes; save()
    }
    /// 今天到了「下次回顾」的章节
    func reviewDueNodes(at now: Date = Date()) -> [SyllabusNode] {
        syllabusNodes.filter { node in node.nextReview.map { $0 <= now } ?? false }.sorted { ($0.nextReview ?? .distantPast) < ($1.nextReview ?? .distantPast) }
    }

    func saveMemory(_ item: MemoryItem) {
        guard writable else { return }
        var list = memoryItems
        var item = item; item.text = String(item.text.trimmingCharacters(in: .whitespacesAndNewlines).prefix(200))
        guard !item.text.isEmpty else { return }
        item.updatedAt = Date()
        if let i = list.firstIndex(where: { $0.id == item.id }) { list[i] = item } else { list.append(item) }
        state.memories = list; save()
    }
    func deleteMemory(_ id: String) {
        guard writable else { return }
        state.memories?.removeAll { $0.id == id }; save()
    }
    func setAutoDigest(_ on: Bool) { guard writable else { return }; state.autoDigest = on; save() }

    // MARK: 每周自动备份

    var autoBackupFolder: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("自动备份", isDirectory: true)
    }
    /// 已有的自动备份，新的在前
    var autoBackups: [URL] {
        let files = (try? FileManager.default.contentsOfDirectory(at: autoBackupFolder, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        return files.filter { $0.pathExtension == "json" }.sorted { $0.lastPathComponent > $1.lastPathComponent }
    }
    /// 距上次自动备份满 7 天就备份一次（不弹窗、失败不打扰）。最多保留 4 份。
    func autoBackupIfNeeded(now: Date = Date()) {
        guard writable, !preview, !state.events.isEmpty else { return }
        let key = "study2027.lastAutoBackup"
        let last = UserDefaults.standard.object(forKey: key) as? Date ?? .distantPast
        guard now.timeIntervalSince(last) >= 7 * 86_400 else { return }
        let previousError = error
        guard let temp = exportBackup() else { error = previousError; return }
        do {
            try FileManager.default.createDirectory(at: autoBackupFolder, withIntermediateDirectories: true)
            let target = autoBackupFolder.appendingPathComponent("研习自动备份-\(StudyDigest.id(for: now)).json")
            if FileManager.default.fileExists(atPath: target.path) { try FileManager.default.removeItem(at: target) }
            try FileManager.default.moveItem(at: temp, to: target)
            for old in autoBackups.dropFirst(4) { try? FileManager.default.removeItem(at: old) }
            UserDefaults.standard.set(now, forKey: key)
        } catch { self.error = previousError }
    }
}
