import Foundation
import ActivityKit

/// 跟着 App 里的计时状态，启动 / 更新 / 结束灵动岛计时。
/// 不改计时本身的逻辑；用户关掉实时活动时安静地跳过。
@MainActor
final class FocusLiveActivityController {
    static let shared = FocusLiveActivityController()
    private var activity: Activity<StudyFocusAttributes>?
    private var runID: UUID?
    /// 这次打包是否带了灵动岛扩展（描述文件不支持时会不带）
    private static let hasExtension: Bool = {
        guard let url = Bundle.main.builtInPlugInsURL?.appendingPathComponent("StudyDeskWidgets.appex") else { return false }
        return FileManager.default.fileExists(atPath: url.path)
    }()

    func sync(focus: FocusRun?, todaySeconds: TimeInterval, now: Date = Date()) {
        guard Self.hasExtension, ActivityAuthorizationInfo().areActivitiesEnabled else { return }
        guard let focus else { end(); endStale(); return }
        let state = StudyFocusAttributes.ContentState(
            countingFrom: focus.segmentStart.map { $0.addingTimeInterval(-focus.elapsed) },
            pausedSeconds: focus.total(at: now),
            isPaused: focus.isPaused,
            targetSeconds: focus.targetSeconds,
            todaySeconds: todaySeconds)
        let content = ActivityContent(state: state, staleDate: nil)
        if let activity, runID == focus.id {
            Task { await activity.update(content) }
            return
        }
        end(); endStale()
        let attributes = StudyFocusAttributes(subject: focus.subject.title, label: focus.label, isRest: focus.isRest)
        activity = try? Activity.request(attributes: attributes, content: content, pushType: nil)
        runID = focus.id
    }

    /// App 上次被关掉时可能留下的旧计时
    private func endStale() {
        for old in Activity<StudyFocusAttributes>.activities where old.id != activity?.id {
            Task { await old.end(nil, dismissalPolicy: .immediate) }
        }
    }
    private func end() {
        guard let activity else { return }
        self.activity = nil; runID = nil
        Task { await activity.end(nil, dismissalPolicy: .immediate) }
    }
}
