import SwiftUI

extension AppStore {
    func prepareStudyDraft(_ text: String, subject: StudySubject = .english, title: String = "学习复盘") -> Bool {
        guard !isGenerating else { errorMessage = "当前回答尚未结束，请先停止或等待完成。"; return false }
        createThread(); setStudyContext(subject: subject, title: title); setDraft(text); return canPersist
    }
}

extension LearningStore {
    var memoryContext: String {
        guard state.memoryEnabled != false else { return "" }
        let recent = state.events.suffix(10).map { "\($0.start.formatted(date: .numeric, time: .omitted)) · \($0.subject.title)：\($0.title)（\($0.detail)）" }.joined(separator: "\n")
        let weak = wrongQuestions.prefix(6).map { "\($0.subject.title)：\($0.stem)" }.joined(separator: "\n")
        return String((state.personalMemory ?? "").prefix(4000)) + "\n近期学习事实：\n" + recent + "\n最近一次仍答错的题：\n" + weak
    }
    func recordAssistant(thread: ChatThread, answer: ChatMessage) {
        guard !state.events.contains(where: { $0.referenceID == answer.id.uuidString }) else { return }
        let text = thread.messages.last(where: { $0.role == .user })?.content ?? ""
        let subject: StudySubject = thread.studySubject ?? (text.contains("历史") || text.contains("史料") ? .history : text.contains("政治") || text.contains("马克思") ? .politics : state.preferences.preferredSubject)
        let now = Date()
        state.events.append(LearningEvent(subject: subject, kind: .assistant, title: thread.title,
                                         detail: "AI 讲解已保存 · 点击回看", start: now, end: now,
                                         referenceID: answer.id.uuidString))
        save()
    }
}

@MainActor
struct StudyAssistantView: View {
    @EnvironmentObject private var chat: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var history = false
    @State private var settings = false
    @State private var keyboard = false
    @State private var composerHeight: CGFloat = 130
    var threadID: UUID? = nil
    var body: some View {
        GeometryReader { geometry in
            NavigationStack {
                ChatScreen(openHistory: { history = true }, openSettings: { settings = true },
                           keyboardVisible: $keyboard, composerPanelHeight: $composerHeight,
                           bottomInset: geometry.safeAreaInsets.bottom, closeStudy: { dismiss() })
            }
        }.sheet(isPresented: $history) {
            NavigationStack {
                List(chat.sortedThreads) { thread in
                    Button { chat.select(thread.id); history = false } label: { VStack(alignment: .leading, spacing: 6) { Text(thread.title); Text(thread.preview).font(.caption).foregroundStyle(.secondary).lineLimit(2) } }
                }.navigationTitle("学习对话").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { history = false } } }
            }
        }
        .sheet(isPresented: $settings) { SettingsView() }
        .onAppear { if let threadID { chat.select(threadID) } }
    }
}
