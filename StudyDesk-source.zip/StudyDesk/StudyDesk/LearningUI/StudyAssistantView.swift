import SwiftUI

extension AppStore {
    func prepareStudyDraft(_ text: String, subject: StudySubject = .english, title: String = "学习复盘") -> Bool {
        guard !isGenerating else { errorMessage = "当前回答尚未结束，请先停止或等待完成。"; return false }
        createThread(); setStudyContext(subject: subject, title: title); setDraft(text); return canPersist
    }
}

extension LearningStore {
    var memoryContext: String {
        guard state.memoryEnabled != false else { return "" }
        // 每次提问都会附带这段，所以只保留精简摘要，避免每题都多花上千 token。
        let recent = state.events.filter { $0.kind != .assistant }.suffix(6)
            .map { "\($0.subject.title)：\(String($0.title.prefix(24)))" }.joined(separator: "\n")
        let weak = wrongQuestions.prefix(4).map { "\($0.subject.title)：\(String($0.stem.prefix(30)))" }.joined(separator: "\n")
        let remembered = StudyMemory.context(items: memoryItems)
        let digests = digestList.suffix(3).map { "\($0.id)：\($0.summary.prefix(80))" }.joined(separator: "\n")
        let shaky = syllabusNodes.filter { (1...2).contains($0.mastery) }.prefix(5).map { "\($0.block)·\($0.title)" }.joined(separator: "、")
        var parts = [remembered.isEmpty ? String((state.personalMemory ?? "").prefix(800)) : "长期记忆：\n" + remembered]
        if !digests.isEmpty { parts.append("最近几天的汇总：\n" + digests) }
        if !shaky.isEmpty { parts.append("还不牢的章节：" + shaky) }
        parts.append("近期学习：\n" + recent)
        parts.append("仍答错的题：\n" + weak)
        return parts.joined(separator: "\n")
    }
    func recordAssistant(thread: ChatThread, answer: ChatMessage) {
        guard !state.events.contains(where: { $0.referenceID == answer.id.uuidString }) else { return }
        let text = thread.messages.last(where: { $0.role == .user })?.content ?? ""
        let subject: StudySubject = thread.studySubject ?? (text.contains("历史") || text.contains("史料") ? .history : text.contains("政治") || text.contains("马克思") ? .politics : state.preferences.preferredSubject)
        let now = Date()
        state.events.append(LearningEvent(subject: subject, kind: .assistant, title: thread.title,
                                         detail: "AI 讲解已保存 · 点击回看", start: now, end: now,
                                         referenceID: answer.id.uuidString))
        save()
    }
}

@MainActor
struct StudyAssistantView: View {
    @EnvironmentObject private var chat: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var history = false
    @State private var settings = false
    @State private var keyboard = false
    @State private var composerHeight: CGFloat = 130
    var threadID: UUID? = nil
    var body: some View {
        GeometryReader { geometry in
            NavigationStack {
                ChatScreen(openHistory: { history = true }, openSettings: { settings = true },
                           keyboardVisible: $keyboard, composerPanelHeight: $composerHeight,
                           bottomInset: geometry.safeAreaInsets.bottom, closeStudy: { dismiss() })
            }
        }.sheet(isPresented: $history) {
            NavigationStack {
                List(chat.sortedThreads) { thread in
                    Button { chat.select(thread.id); history = false } label: { VStack(alignment: .leading, spacing: 6) { Text(thread.title); Text(thread.preview).font(TypeScale.serif(12, relativeTo: .caption)).foregroundStyle(.secondary).lineLimit(2) } }
                }.navigationTitle("学习对话").toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { history = false } } }
            }
        }
        .sheet(isPresented: $settings) { SettingsView() }
        .onAppear { if let threadID { chat.select(threadID) } }
    }
}
