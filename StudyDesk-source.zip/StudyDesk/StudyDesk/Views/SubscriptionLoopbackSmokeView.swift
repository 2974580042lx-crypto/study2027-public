#if targetEnvironment(simulator)
import SwiftUI
import AuthenticationServices

/// Simulator-only check: synthetic callback, no credentials or provider traffic.
@MainActor
private final class SubscriptionLoopbackSmoke: NSObject, ObservableObject, ASWebAuthenticationPresentationContextProviding {
    @Published var message = "等待测试"
    @Published var passed = false
    private var session: ASWebAuthenticationSession?
    private var server: SubscriptionLoopback?
    func run() {
        message = "正在打开系统登录窗口"
        Task {
            do {
                let state = UUID().uuidString
                let server = SubscriptionLoopback(state: state); self.server = server
                let redirect = try await server.start()
                let transaction = SubscriptionTransaction(state: state, nonce: "synthetic", verifier: "synthetic", redirectURI: redirect.absoluteString)
                let callback = URL(string: redirect.absoluteString + "?state=\(state)&code=synthetic&client_id=oaiapp_simulator")!
                let session = ASWebAuthenticationSession(url: callback, callbackURLScheme: nil) { [weak self] _, error in
                    Task { @MainActor [weak self] in if error != nil && self?.session != nil { self?.server?.cancel() } }
                }
                self.session = session; session.presentationContextProvider = self
                guard session.start() else { throw SubscriptionError.cancelled }
                let result = try await server.result()
                self.session = nil; session.cancel()
                _ = try transaction.validateCallback(result, savedClientID: nil)
                passed = true; message = "本机授权回跳通过"
            } catch { message = error.localizedDescription }
            self.session?.cancel(); self.session = nil; self.server?.cancel(); self.server = nil
        }
    }
    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.flatMap(\.windows).first(where: \.isKeyWindow) ?? UIWindow()
    }
}
struct SubscriptionLoopbackSmokeView: View {
    @StateObject private var test = SubscriptionLoopbackSmoke()
    var body: some View {
        VStack(spacing: 24) {
            Text("手机授权回跳检查").font(.title2)
            Text(test.message).accessibilityIdentifier(test.passed ? "loopback-success" : "loopback-status")
            Button("开始回跳测试") { test.run() }.accessibilityIdentifier("loopback-start")
        }.padding()
    }
}
#endif
