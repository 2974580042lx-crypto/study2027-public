import SwiftUI
import UIKit

// 「墨与印」设计系统。规格见 研习-墨与印-规格/实施规格书.md。
// 颜色全部跟随系统浅色 / 深色；页面只用这里的令牌和组件，不要再写死 Color.white / .black。

enum FloatingChrome {
    static let navigationHeight: CGFloat = 75
}

// MARK: - 颜色

private extension Color {
    static func adaptive(light: UInt32, dark: UInt32, lightAlpha: CGFloat = 1, darkAlpha: CGFloat = 1) -> Color {
        Color(UIColor { trait in
            let isDark = trait.userInterfaceStyle == .dark
            let hex = isDark ? dark : light
            return UIColor(red: CGFloat((hex >> 16) & 0xFF) / 255, green: CGFloat((hex >> 8) & 0xFF) / 255,
                           blue: CGFloat(hex & 0xFF) / 255, alpha: isDark ? darkAlpha : lightAlpha)
        })
    }
}

enum Ink {
    /// 页面底色：白天宣纸，夜间暖墨
    static let paper = Color.adaptive(light: 0xF5F2EB, dark: 0x141311)
    /// 侧栏（后面那张书页）
    static let sheet = Color.adaptive(light: 0xE9E5DB, dark: 0x1C1B18)
    /// 用户气泡、选中行、代码块底色
    static let raised = Color.adaptive(light: 0xE9E5DB, dark: 0x2A2825)
    static let ink = Color.adaptive(light: 0x1B1A17, dark: 0xECE8DF)
    static let ink2 = Color.adaptive(light: 0x4A4740, dark: 0xB5B0A5)
    /// 说明小字；对比度在两种模式下都不低于 4.5:1
    static let ink3 = Color.adaptive(light: 0x6F6B62, dark: 0x8F8A7F)
    static let line = Color.adaptive(light: 0x1B1A17, dark: 0xECE8DF, lightAlpha: 0.12, darkAlpha: 0.13)
    /// 朱红：只用于印章、日历的今天与考试日、批改
    static let seal = Color.adaptive(light: 0xB83A26, dark: 0xE0664C)
    static let onSeal = Color.adaptive(light: 0xF5F2EB, dark: 0x141311)
    static let solid = ink
    static let onSolid = paper
    /// 阅读底栏等需要压住下方正文的玻璃叠色
    static let denseGlass = Color.adaptive(light: 0xFAF8F3, dark: 0x24221F, lightAlpha: 0.90, darkAlpha: 0.88)

    /// 备考日历 5 档：0 没学 … 4 达到每日目标
    static func dot(_ level: Int) -> Color {
        let light: [CGFloat] = [0.07, 0.20, 0.40, 0.65, 1.0]
        let dark: [CGFloat] = [0.07, 0.22, 0.42, 0.66, 1.0]
        let i = max(0, min(4, level))
        return Color.adaptive(light: 0x1B1A17, dark: 0xECE8DF, lightAlpha: light[i], darkAlpha: dark[i])
    }
}

/// 旧名字，保留给尚未迁移的页面；新代码请用 Ink。
enum Palette {
    static let green = Ink.ink
    static let paper = Ink.paper
    static let surface = Ink.sheet
    static let softGreen = Ink.line
    static let secondary = Ink.ink3
}

// MARK: - 间距、圆角、字体

enum Space {
    static let xs: CGFloat = 4, s: CGFloat = 8, m: CGFloat = 12, l: CGFloat = 16
    static let xl: CGFloat = 24, xxl: CGFloat = 32, section: CGFloat = 40
    /// 内容区左右边距
    static let page: CGFloat = 24
}

enum Radius {
    static let control: CGFloat = 14, field: CGFloat = 20, sheet: CGFloat = 34
    static let pageFront: CGFloat = 42, pageBack: CGFloat = 32
}

enum TypeScale {
    static let serifName = "NotoSerifSC-Regular"
    static func serif(_ size: CGFloat, relativeTo style: Font.TextStyle = .body) -> Font {
        .custom(serifName, size: size, relativeTo: style)
    }
    static let pageTitle = serif(32, relativeTo: .largeTitle)
    static let hero = serif(30, relativeTo: .title)
    static let stem = serif(25, relativeTo: .title2)
    static let word = serif(68, relativeTo: .largeTitle)
    static let subject = serif(20, relativeTo: .title3)
    static let option = serif(18)
    static let answer = serif(17)
    static let note = serif(16, relativeTo: .callout)
    static let body = serif(16)
    static let label = serif(13, relativeTo: .footnote)
    static let caption = serif(12, relativeTo: .caption)
    static let tiny = serif(11, relativeTo: .caption2)
}

/// 导航栏标题改为宋体。只改字体和颜色，不碰背景，系统玻璃保持原样。
/// 在 App 启动时调用一次（例如 StudyDeskApp.init）。
enum InkAppearance {
    @MainActor static func apply() {
        let ink = UIColor(Ink.ink)
        let bar = UINavigationBar.appearance()
        if let large = UIFont(name: TypeScale.serifName, size: 32) {
            bar.largeTitleTextAttributes = [.font: UIFontMetrics(forTextStyle: .largeTitle).scaledFont(for: large), .foregroundColor: ink]
        }
        if let inline = UIFont(name: TypeScale.serifName, size: 17) {
            bar.titleTextAttributes = [.font: UIFontMetrics(forTextStyle: .headline).scaledFont(for: inline), .foregroundColor: ink]
        }
    }
}

// MARK: - 页面底色与滚动页

struct AppBackground: View {
    var body: some View { Ink.paper.ignoresSafeArea() }
}

/// 标准滚动页：宣纸底、左右 24、内容最宽 900（为 iPad 预留）。
/// 底部有浮动控件时配合 `.inkBottomBar { }` 使用，内容会自动留出空间。
struct InkPage<Content: View>: View {
    var spacing: CGFloat = Space.xl
    @ViewBuilder var content: Content
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: spacing) { content }
                .frame(maxWidth: 900, alignment: .leading).frame(maxWidth: .infinity)
                .padding(.horizontal, Space.page).padding(.top, Space.m).padding(.bottom, Space.xxl)
        }
        .background(AppBackground())
        .scrollDismissesKeyboard(.interactively)
    }
}

/// 页面边缘的渐隐，让内容滑到玻璃控件下方时不糊在一起。功能性，不是装饰。
struct InkEdgeFade: View {
    var edge: VerticalEdge = .bottom
    var height: CGFloat = 150
    var body: some View {
        LinearGradient(stops: [.init(color: Ink.paper, location: 0), .init(color: Ink.paper, location: 0.42),
                               .init(color: Ink.paper.opacity(0), location: 1)],
                       startPoint: edge == .bottom ? .bottom : .top, endPoint: edge == .bottom ? .top : .bottom)
            .frame(height: height).allowsHitTesting(false).accessibilityHidden(true)
    }
}

extension View {
    /// 底部浮动控件（操作按钮组、输入框）。用 safeAreaInset 实现，滚动内容的最后一行一定能完整露出。
    func inkBottomBar<Bar: View>(@ViewBuilder _ bar: () -> Bar) -> some View {
        safeAreaInset(edge: .bottom, spacing: 0) {
            bar().padding(.horizontal, Space.l).padding(.top, Space.m).padding(.bottom, Space.s)
                .frame(maxWidth: 900).frame(maxWidth: .infinity)
                .background(alignment: .bottom) { InkEdgeFade(edge: .bottom, height: 150).ignoresSafeArea(edges: .bottom) }
        }
    }
}

// MARK: - 细线与列表

struct InkRule: View {
    var body: some View { Rectangle().fill(Ink.line).frame(height: 0.5).accessibilityHidden(true) }
}

/// 分组小标题：「科目」「今日记录」「目标」……
struct InkSectionHeader: View {
    let title: String
    var trailing: String? = nil
    var trailingAction: (() -> Void)? = nil
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(TypeScale.label.weight(.semibold)).foregroundStyle(Ink.ink2)
                .accessibilityAddTraits(.isHeader)
            Spacer()
            if let trailing {
                if let trailingAction {
                    Button(trailing, action: trailingAction).font(TypeScale.label).foregroundStyle(Ink.ink3).buttonStyle(.plain)
                } else {
                    Text(trailing).font(TypeScale.label).foregroundStyle(Ink.ink3)
                }
            }
        }
    }
}

/// 无框列表行：宋体标题 + 说明 + 右侧状态，底部一条细线。
/// 包在 NavigationLink / Button 里使用，标识加在外层。
struct InkRow: View {
    let title: String
    var detail: String? = nil
    var value: String? = nil
    var valueIsSeal = false
    var serif = true
    var chevron = false
    var divider = true
    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center, spacing: Space.m) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(serif ? TypeScale.subject : TypeScale.body).foregroundStyle(Ink.ink)
                        .multilineTextAlignment(.leading)
                    if let detail { Text(detail).font(TypeScale.caption).foregroundStyle(Ink.ink3).lineLimit(2) }
                }
                Spacer(minLength: Space.s)
                if let value {
                    Text(value).font(valueIsSeal ? TypeScale.label.weight(.semibold) : TypeScale.label)
                        .foregroundStyle(valueIsSeal ? Ink.seal : Ink.ink2).monospacedDigit()
                }
                if chevron {
                    Image(systemName: "chevron.right").font(.system(size: 13, weight: .semibold)).foregroundStyle(Ink.ink3)
                        .accessibilityHidden(true)
                }
            }
            .padding(.vertical, Space.l).frame(minHeight: 60)
            .contentShape(Rectangle())
            if divider { InkRule() }
        }
    }
}

// MARK: - 朱红：印章、标签、批改

/// 品牌印章：朱红圆角方块里的宋体「研」。
struct SealStamp: View {
    var text = "研"
    var size: CGFloat = 30
    var body: some View {
        Text(text).font(.custom(TypeScale.serifName, size: size * 0.57)).fontWeight(.semibold)
            .foregroundStyle(Ink.onSeal)
            .frame(width: size, height: size)
            .background(Ink.seal, in: RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// 朱红描边小标签：「阅读生词」；square = true 时是解析前的「批」字章。
struct SealTag: View {
    let text: String
    var square = false
    var body: some View {
        Text(text).font(TypeScale.serif(square ? 13 : 12))
            .foregroundStyle(Ink.seal)
            .padding(.horizontal, square ? 0 : 5).padding(.vertical, square ? 0 : 1)
            .frame(width: square ? 22 : nil, height: square ? 22 : nil)
            .overlay(RoundedRectangle(cornerRadius: square ? 4 : 3).stroke(Ink.seal, lineWidth: square ? 1.2 : 1))
    }
}

/// 手绘勾（34×30）：标出正确答案。
struct SealCheckShape: Shape {
    func path(in r: CGRect) -> Path {
        let sx = r.width / 34, sy = r.height / 30
        var p = Path()
        p.move(to: CGPoint(x: 3 * sx, y: 16 * sy))
        p.addCurve(to: CGPoint(x: 12 * sx, y: 26 * sy), control1: CGPoint(x: 6 * sx, y: 18 * sy), control2: CGPoint(x: 9 * sx, y: 21 * sy))
        p.addCurve(to: CGPoint(x: 31 * sx, y: 3 * sy), control1: CGPoint(x: 17 * sx, y: 15 * sy), control2: CGPoint(x: 23 * sx, y: 8 * sy))
        return p
    }
}

/// 手绘圈（44×40，不完全闭合）：圈出错选的字母。
struct SealCircleShape: Shape {
    func path(in r: CGRect) -> Path {
        let sx = r.width / 44, sy = r.height / 40
        var p = Path()
        p.move(to: CGPoint(x: 30 * sx, y: 6 * sy))
        p.addCurve(to: CGPoint(x: 4 * sx, y: 19 * sy), control1: CGPoint(x: 18 * sx, y: 2 * sy), control2: CGPoint(x: 5 * sx, y: 8 * sy))
        p.addCurve(to: CGPoint(x: 29 * sx, y: 34 * sy), control1: CGPoint(x: 3 * sx, y: 30 * sy), control2: CGPoint(x: 17 * sx, y: 37 * sy))
        p.addCurve(to: CGPoint(x: 37 * sx, y: 11 * sy), control1: CGPoint(x: 40 * sx, y: 31 * sy), control2: CGPoint(x: 43 * sx, y: 20 * sy))
        p.addCurve(to: CGPoint(x: 20 * sx, y: 5 * sy), control1: CGPoint(x: 33 * sx, y: 6 * sy), control2: CGPoint(x: 26 * sx, y: 4 * sy))
        return p
    }
}

/// 朱批记号。出现时像落笔一样在 0.35 秒内画出；「减少动态效果」开启时直接显示。
struct SealMark: View {
    enum Kind { case check, circle }
    let kind: Kind
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var progress: CGFloat = 0
    var body: some View {
        Group {
            switch kind {
            case .check:
                SealCheckShape().trim(from: 0, to: progress)
                    .stroke(Ink.seal, style: StrokeStyle(lineWidth: 2.4, lineCap: .round, lineJoin: .round))
                    .frame(width: 34, height: 30)
            case .circle:
                SealCircleShape().trim(from: 0, to: progress)
                    .stroke(Ink.seal, style: StrokeStyle(lineWidth: 1.6, lineCap: .round, lineJoin: .round))
                    .frame(width: 44, height: 40)
            }
        }
        .accessibilityHidden(true)
        .onAppear {
            if reduceMotion { progress = 1 } else { withAnimation(.easeOut(duration: 0.35)) { progress = 1 } }
        }
    }
}

/// 交卷后的朱批：「批」字章 + 朱红宋体批语。正文可传入 SelectableStudyText 等任意视图。
struct SealNote<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        HStack(alignment: .top, spacing: Space.m) {
            SealTag(text: "批", square: true).padding(.top, 3).accessibilityHidden(true)
            content.font(TypeScale.note).foregroundStyle(Ink.seal).lineSpacing(6)
        }
    }
}

// MARK: - 选项（刷题、阅读题共用）

enum InkOptionState: Equatable {
    case idle, selected
    /// 交卷后：correct 正确答案；wrongPick 错选；other 其他
    case correct, wrongPick, other
}

/// 无框选项行：字母 + 宋体选项文字，底部细线。外层 Button 负责点击和 accessibilityIdentifier。
struct InkOptionRow: View {
    let letter: String
    let text: String
    let state: InkOptionState
    var divider = true
    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .center, spacing: Space.l) {
                ZStack {
                    if state == .selected {
                        Circle().fill(Ink.solid).frame(width: 26, height: 26)
                        Text(letter).font(TypeScale.serif(15)).foregroundStyle(Ink.onSolid)
                    } else {
                        Text(letter).font(TypeScale.option).foregroundStyle(Ink.ink2)
                    }
                    if state == .wrongPick { SealMark(kind: .circle) }
                }.frame(width: 26, height: 26)
                Text(text).font(TypeScale.option)
                    .foregroundStyle(state == .selected || state == .correct ? Ink.ink : Ink.ink2)
                    .multilineTextAlignment(.leading).frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
                switch state {
                case .correct: SealMark(kind: .check)
                case .wrongPick: Text("你选的").font(TypeScale.caption).foregroundStyle(Ink.ink3)
                default: EmptyView()
                }
            }
            .padding(.vertical, Space.m).frame(minHeight: 58)
            .contentShape(Rectangle())
            if divider { InkRule() }
        }
        .accessibilityElement(children: .combine)
        .accessibilityValue(state == .correct ? "正确答案" : state == .wrongPick ? "错误" : "")
        .accessibilityAddTraits(state == .selected ? .isSelected : [])
    }
}

// MARK: - 按钮

/// 主操作：墨色实心胶囊（白天黑底浅字，夜间浅底黑字）。
struct InkPrimaryButtonStyle: ButtonStyle {
    var height: CGFloat = 54
    var fill = true
    @Environment(\.isEnabled) private var isEnabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(TypeScale.serif(17).weight(.semibold))
            .foregroundStyle(Ink.onSolid)
            .padding(.horizontal, 22)
            .frame(maxWidth: fill ? .infinity : nil).frame(height: height)
            .background(Ink.solid, in: Capsule())
            .opacity(isEnabled ? (configuration.isPressed ? 0.82 : 1) : 0.4)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
            .animation(.snappy(duration: 0.18), value: configuration.isPressed)
    }
}

/// 次操作：原生液态玻璃胶囊。
struct InkGlassButtonStyle: ButtonStyle {
    var height: CGFloat = 54
    @Environment(\.isEnabled) private var isEnabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(TypeScale.serif(16))
            .foregroundStyle(Ink.ink)
            .padding(.horizontal, 22).frame(height: height)
            .glassEffect(.regular.interactive(), in: .capsule)
            .opacity(isEnabled ? 1 : 0.4)
    }
}

/// 快捷提问等小胶囊：原生玻璃胶囊，正常墨色文字（不能看起来像禁用，也不要细描边的安卓式小胶囊）。
struct InkChipButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(TypeScale.serif(14)).foregroundStyle(Ink.ink).lineLimit(1)
            .padding(.horizontal, 15).frame(height: 36)
            .glassEffect(.regular.interactive(), in: .capsule)
            .opacity(configuration.isPressed ? 0.85 : 1)
    }
}

extension ButtonStyle where Self == InkPrimaryButtonStyle {
    static var inkPrimary: InkPrimaryButtonStyle { InkPrimaryButtonStyle() }
}
extension ButtonStyle where Self == InkGlassButtonStyle {
    static var inkGlass: InkGlassButtonStyle { InkGlassButtonStyle() }
}
extension ButtonStyle where Self == InkChipButtonStyle {
    static var inkChip: InkChipButtonStyle { InkChipButtonStyle() }
}

/// 底部操作组：左玻璃次按钮 + 右墨色主按钮。放进 `.inkBottomBar { }`。
struct InkActionBar<Secondary: View, Primary: View>: View {
    @ViewBuilder var secondary: Secondary
    @ViewBuilder var primary: Primary
    var body: some View {
        HStack(spacing: 10) {
            secondary.buttonStyle(.inkGlass)
            primary.buttonStyle(.inkPrimary)
        }
    }
}

// MARK: - 输入框

/// 底部玻璃输入框（首页、问 AI、学习助手）。标识由调用方用 fieldIdentifier 传入。
struct InkComposer: View {
    @Binding var text: String
    var placeholder = "问点什么…"
    var isGenerating = false
    var canSend = true
    var fieldIdentifier = "ink-composer-field"
    var sendLabel = "发送"
    var stopLabel = "停止回答"
    var focus: FocusState<Bool>.Binding? = nil
    var onAttach: (() -> Void)? = nil
    let onSend: () -> Void
    var onStop: () -> Void = {}

    private var sendDisabled: Bool {
        !isGenerating && (!canSend || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
    }

    var body: some View {
        HStack(alignment: .bottom, spacing: Space.s) {
            if let onAttach {
                Button(action: onAttach) {
                    Image(systemName: "plus").font(.system(size: 18)).frame(width: 40, height: 40)
                }.buttonStyle(.plain).foregroundStyle(Ink.ink2).accessibilityLabel("更多输入操作")
            }
            field
                .padding(.leading, onAttach == nil ? 10 : 0)
                .padding(.vertical, 9)
            Button {
                if isGenerating { onStop() } else { onSend() }
            } label: {
                Group {
                    if isGenerating {
                        RoundedRectangle(cornerRadius: 2).frame(width: 11, height: 11)
                    } else {
                        Image(systemName: "arrow.up").font(.system(size: 16, weight: .bold))
                    }
                }
                .foregroundStyle(Ink.onSolid).frame(width: 40, height: 40)
                .background(Ink.solid, in: Circle())
            }
            .buttonStyle(.plain)
            .disabled(sendDisabled)
            .opacity(sendDisabled ? 0.35 : 1)
            .accessibilityLabel(isGenerating ? stopLabel : sendLabel)
        }
        .padding(8)
        .frame(minHeight: 56)
        .glassEffect(.regular.interactive(), in: .rect(cornerRadius: 28))
    }

    @ViewBuilder private var field: some View {
        if let focus {
            baseField.focused(focus)
        } else {
            baseField
        }
    }

    private var baseField: some View {
        TextField("", text: $text, prompt: Text(placeholder).foregroundStyle(Ink.ink3), axis: .vertical)
            .font(TypeScale.note).foregroundStyle(Ink.ink).tint(Ink.ink)
            .lineLimit(1...5).submitLabel(.send)
            .accessibilityIdentifier(fieldIdentifier)
    }
}

// MARK: - 设置用小控件

/// 「− | +」细描边步进器；数值显示在左侧。
struct InkStepper: View {
    let title: String
    @Binding var value: Int
    let range: ClosedRange<Int>
    var step = 1
    var format: (Int) -> String = { "\($0)" }
    var body: some View {
        HStack(spacing: Space.m) {
            Text(title).font(TypeScale.body).foregroundStyle(Ink.ink)
            Spacer()
            Text(format(value)).font(TypeScale.serif(15)).foregroundStyle(Ink.ink2).monospacedDigit()
            HStack(spacing: 0) {
                stepButton("minus", label: "减少") { value = max(range.lowerBound, value - step) }
                    .disabled(value <= range.lowerBound)
                Rectangle().fill(Ink.line).frame(width: 0.5, height: 16)
                stepButton("plus", label: "增加") { value = min(range.upperBound, value + step) }
                    .disabled(value >= range.upperBound)
            }
            .frame(height: 32)
            .overlay(Capsule().stroke(Ink.ink.opacity(0.16), lineWidth: 0.5))
        }
        .frame(minHeight: 52)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(title)
        .accessibilityValue(format(value))
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: value = min(range.upperBound, value + step)
            case .decrement: value = max(range.lowerBound, value - step)
            @unknown default: break
            }
        }
    }
    private func stepButton(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 13, weight: .medium)).frame(width: 34, height: 32)
        }.buttonStyle(.plain).foregroundStyle(Ink.ink2).accessibilityLabel(label)
    }
}

/// 文字标签式筛选（资料页的科目）：选中项墨色半粗 + 下划线。
struct InkTabs<Value: Hashable>: View {
    let items: [(value: Value, title: String)]
    @Binding var selection: Value
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 22) {
                    ForEach(items.indices, id: \.self) { i in
                        tab(items[i].value, title: items[i].title)
                    }
                }
            }
            InkRule()
        }
    }
    private func tab(_ value: Value, title: String) -> some View {
        let on = value == selection
        return Button { selection = value } label: {
            Text(title).font(TypeScale.serif(15).weight(on ? .semibold : .regular))
                .foregroundStyle(on ? Ink.ink : Ink.ink3)
                .padding(.bottom, 7)
                .overlay(alignment: .bottom) { Rectangle().fill(on ? Ink.ink : Color.clear).frame(height: 1.5) }
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(on ? .isSelected : [])
    }
}

// MARK: - 备考日历

struct PrepCalendarDay: Identifiable {
    enum Kind: Equatable { case past(level: Int), today(level: Int), future, exam }
    let id: Int
    let date: Date
    let kind: Kind
    let seconds: TimeInterval
    var isPast: Bool { if case .past = kind { return true } else { return false } }
    var isSelectable: Bool {
        switch kind {
        case .past, .today: return true
        case .future, .exam: return false
        }
    }
}

enum PrepCalendar {
    static let cells = 108
    static let columns = 12

    /// 学习时长相对每日目标的深浅档：0 没学，(0,25%) 1，[25%,50%) 2，[50%,100%) 3，≥100% 4
    static func level(seconds: TimeInterval, goalSeconds: TimeInterval) -> Int {
        guard seconds > 0 else { return 0 }
        let ratio = seconds / max(60, goalSeconds)
        if ratio < 0.25 { return 1 }
        if ratio < 0.5 { return 2 }
        if ratio < 1 { return 3 }
        return 4
    }

    /// 生成 108 格：过去 → 今天 → 未来；距考试 ≤ 77 天时最后一格是考试日。
    /// 每天只调用一次 secondsOn。调用方应在进入页面或数据变化时缓存结果，不要在 body 里反复计算。
    static func days(today: Date, examDate: Date, goalMinutes: Int, calendar: Calendar = .current,
                     secondsOn: (Date) -> TimeInterval) -> [PrepCalendarDay] {
        let start = calendar.startOfDay(for: today)
        let left = max(0, StudyPreferences.daysUntil(examDate, from: today, calendar: calendar))
        let future = min(left, cells - 31)
        let past = cells - 1 - future
        let goal = TimeInterval(goalMinutes * 60)
        var result: [PrepCalendarDay] = []
        result.reserveCapacity(cells)
        for offset in -past...future {
            guard let date = calendar.date(byAdding: .day, value: offset, to: start) else { continue }
            let index = offset + past
            if offset <= 0 {
                let s = secondsOn(date)
                let lvl = level(seconds: s, goalSeconds: goal)
                result.append(PrepCalendarDay(id: index, date: date, kind: offset == 0 ? .today(level: lvl) : .past(level: lvl), seconds: s))
            } else if offset == future && left == future {
                result.append(PrepCalendarDay(id: index, date: date, kind: .exam, seconds: 0))
            } else {
                result.append(PrepCalendarDay(id: index, date: date, kind: .future, seconds: 0))
            }
        }
        return result
    }
}

/// 首页主角：圆点网格。过去按学习时长深浅着色，今天朱红，未来空心，考试日朱红方块。
struct PrepCalendarView: View {
    let days: [PrepCalendarDay]
    let examDate: Date
    var onSelect: ((Date) -> Void)? = nil

    private var pastCount: Int { days.filter(\.isPast).count }
    private var studiedCount: Int { days.filter { $0.isPast && $0.seconds > 0 }.count }

    var body: some View {
        VStack(alignment: .leading, spacing: Space.l) {
            HStack(alignment: .firstTextBaseline) {
                Text("备考日历").font(TypeScale.label.weight(.semibold)).foregroundStyle(Ink.ink2)
                Spacer()
                HStack(spacing: 4) {
                    Text("少")
                    ForEach(1...4, id: \.self) { level in Circle().fill(Ink.dot(level)).frame(width: 8, height: 8) }
                    Text("多")
                }
                .font(TypeScale.tiny).foregroundStyle(Ink.ink3).accessibilityHidden(true)
            }
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 0), count: PrepCalendar.columns), spacing: 12) {
                ForEach(days) { day in
                    dot(day)
                        .frame(width: 22, height: 22)
                        .contentShape(Rectangle())
                        .onTapGesture { if day.isSelectable { onSelect?(day.date) } }
                }
            }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("备考日历")
            .accessibilityValue("过去 \(pastCount) 天学了 \(studiedCount) 天")
            HStack {
                Text("过去 \(pastCount) 天学了 \(studiedCount) 天")
                Spacer()
                HStack(spacing: 6) {
                    RoundedRectangle(cornerRadius: 2).fill(Ink.seal).frame(width: 8, height: 8)
                    Text("\(examDate.formatted(.dateTime.month().day()))初试")
                }
            }
            .font(TypeScale.caption).foregroundStyle(Ink.ink3)
        }
    }

    @ViewBuilder private func dot(_ day: PrepCalendarDay) -> some View {
        switch day.kind {
        case .past(let level):
            Circle().fill(Ink.dot(level)).frame(width: 14, height: 14)
        case .today:
            Circle().fill(Ink.seal).frame(width: 14, height: 14)
                .padding(3).overlay(Circle().stroke(Ink.seal, lineWidth: 1))
        case .future:
            Circle().stroke(Ink.dot(1), lineWidth: 1).frame(width: 13, height: 13)
        case .exam:
            RoundedRectangle(cornerRadius: 3).fill(Ink.seal).frame(width: 14, height: 14)
        }
    }
}

// MARK: - 沿用的旧组件（接口不变）

struct ClearGlass: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var radius: CGFloat = 28
    func body(content: Content) -> some View {
        content.glassEffect(.regular, in: .rect(cornerRadius: radius))
    }
}

// Clip the whole page, including its top and bottom safe-area drawing.
struct PageContour: Shape {
    var radius: CGFloat
    var topInset: CGFloat
    var bottomInset: CGFloat
    var animatableData: CGFloat {
        get { radius }
        set { radius = newValue }
    }
    func path(in rect: CGRect) -> Path {
        let page = CGRect(x: rect.minX, y: rect.minY - topInset, width: rect.width,
                          height: rect.height + topInset + bottomInset)
        return RoundedRectangle(cornerRadius: radius, style: .continuous).path(in: page)
    }
}

struct ReadingStyle: ViewModifier {
    @AppStorage("study2027.reading.serif") private var serif = true
    @AppStorage("study2027.reading.size") private var size = 18.0
    var adjustment: Double = 0
    func body(content: Content) -> some View {
        content.font(serif
            ? .custom(TypeScale.serifName, size: size + adjustment, relativeTo: .body)
            : .system(size: size + adjustment))
    }
}

extension View {
    func readingStyle(adjustment: Double = 0) -> some View { modifier(ReadingStyle(adjustment: adjustment)) }
    func clearGlass(radius: CGFloat = 28) -> some View { modifier(ClearGlass(radius: radius)) }
}

struct GlassCircle: View {
    let symbol: String
    let label: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 17, weight: .medium))
                .frame(width: 44, height: 44)
        }
        .buttonStyle(.plain)
        .glassEffect(.regular.interactive(), in: .circle)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(label)
        .accessibilityIdentifier(label)
        .accessibilityAddTraits(.isButton)
    }
}
