import SwiftUI
import UIKit
import UniformTypeIdentifiers

enum MainTab: Hashable { case chat, settings }

@MainActor
struct ContentView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var tab: MainTab = ProcessInfo.processInfo.arguments.contains("--preview-settings") || ProcessInfo.processInfo.arguments.contains("--preview-profile") ? .settings : .chat
    @State private var showSidebar = ProcessInfo.processInfo.arguments.contains("--preview-sidebar")
    @State private var keyboardVisible = false
    @State private var composerPanelHeight: CGFloat = 130
    @State private var sidebarDrag: CGFloat = 0
    @AppStorage("study2027.haptics") private var hapticsEnabled = true

    var body: some View {
        GeometryReader { geometry in
            let width = min(geometry.size.width * 0.76, 340)
            let position = min(width, max(0, (showSidebar ? width : 0) + sidebarDrag))
            let progress = position / width
            let frontPage = PageContour(radius: 42 * progress, topInset: geometry.safeAreaInsets.top, bottomInset: geometry.safeAreaInsets.bottom)
            let backPage = PageContour(radius: 32 * progress, topInset: geometry.safeAreaInsets.top, bottomInset: geometry.safeAreaInsets.bottom)
            ZStack(alignment: .leading) {
                Palette.paper.ignoresSafeArea()
                HistorySidebar(close: {
                    tab = .chat
                    showSidebar = false
                }, openSettings: {
                    tab = .settings
                    showSidebar = false
                })
                .frame(width: width)
                .background(Color(white: 0.06).ignoresSafeArea())
                .clipShape(backPage)
                .overlay(backPage.stroke(Color.white.opacity(0.045 * progress), lineWidth: 0.5).allowsHitTesting(false))
                .offset(x: -width * 0.2 * (1 - progress))
                .opacity(min(1, progress * 3))
                .allowsHitTesting(showSidebar)
                .accessibilityHidden(!showSidebar)

                TabView(selection: $tab) {
                            NavigationStack {
                                ChatScreen(openHistory: { showSidebar = true }, openSettings: { tab = .settings }, keyboardVisible: $keyboardVisible,
                                           composerPanelHeight: $composerPanelHeight, bottomInset: geometry.safeAreaInsets.bottom)
                            }
                            .tabItem { Label("聊天", systemImage: "bubble.left.and.bubble.right") }.tag(MainTab.chat)
                            SettingsView(embedded: true)
                                .tabItem { Label("设置", systemImage: "slider.horizontal.3") }.tag(MainTab.settings)
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                .scrollDisabled(sidebarDrag != 0)
                .tint(.white)
                .background(AppBackground())
                .overlay {
                    if progress > 0 {
                        Color.black.opacity(0.26 * progress)
                            .contentShape(Rectangle())
                            .onTapGesture { showSidebar = false }
                    }
                }
                .clipShape(frontPage)
                .overlay(frontPage.stroke(Color.white.opacity(0.12 * progress), lineWidth: 0.6).allowsHitTesting(false))
                // Both controls float above one full-height content surface.
                .scaleEffect(reduceMotion ? 1 : 1 - 0.01 * progress, anchor: .trailing)
                .offset(x: position)
                .shadow(color: .black.opacity(0.35 * progress), radius: 14, x: -5)
                .accessibilityHidden(showSidebar)
            }
            .contentShape(Rectangle())
            .animation(reduceMotion ? nil : .snappy(duration: 0.28), value: showSidebar)
            .background(SidebarPan(enabled: tab == .chat || showSidebar, isOpen: showSidebar,
                maximumStartY: geometry.frame(in: .global).maxY - composerPanelHeight - (keyboardVisible ? 0 : FloatingChrome.navigationHeight),
                changed: { distance in
                    sidebarDrag = showSidebar ? max(-width, min(0, distance)) : min(width, max(0, distance))
                }, ended: { distance, prediction in
                    let threshold = min(65, width * 0.18)
                    let open = showSidebar ? !(distance < -threshold || prediction < -width * 0.45) :
                        (distance > threshold || prediction > width * 0.45)
                    if open {
                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    }
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { showSidebar = open; sidebarDrag = 0 }
                }, cancelled: {
                    withAnimation(reduceMotion ? nil : .snappy(duration: 0.28)) { sidebarDrag = 0 }
                }))
        }
        .preferredColorScheme(.dark)
        .onChange(of: tab) { _, _ in
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            keyboardVisible = false
        }
        .onChange(of: showSidebar) { _, _ in
            if hapticsEnabled { UIImpactFeedbackGenerator(style: .soft).impactOccurred(intensity: 0.65) }
        }
        .onAppear {
            if store.isPreview {
                let result = "STUDYDESK_SONGTI_LOADED=\(UIFont(name: "NotoSerifSC-Regular", size: 18) != nil)\n"
                FileHandle.standardOutput.write(Data(result.utf8))
            }
        }
    }

}

@MainActor
struct ChatScreen: View {
    @EnvironmentObject private var store: AppStore
    let openHistory: () -> Void
    let openSettings: () -> Void
    @Binding var keyboardVisible: Bool
    @Binding var composerPanelHeight: CGFloat
    let bottomInset: CGFloat
    var closeStudy: (() -> Void)? = nil
    @FocusState private var composerFocused: Bool
    @State private var previewComposerFocused = false
    @StateObject private var keyboardBoundary = KeyboardBoundary()
    @State private var composerFrame = CGRect.zero
    @State private var keyboardLift: CGFloat = 0
    private var isComposerFocused: Bool { composerFocused || previewComposerFocused }
    private var usesPreviewKeyboard: Bool { store.isPreview && ProcessInfo.processInfo.arguments.contains("--preview-tall-keyboard") }
    private func focusComposer(_ focused: Bool) {
        if usesPreviewKeyboard { previewComposerFocused = focused } else { composerFocused = focused }
    }
    private func updateKeyboardLift() {
        guard isComposerFocused, let top = keyboardBoundary.top, composerFrame != .zero else {
            if keyboardLift != 0 { keyboardLift = 0 }
            return
        }
        // Subtract the previous correction from the observation so this cannot
        // keep adding the same overlap on successive layout passes.
        let originalBottom = composerFrame.maxY + keyboardLift
        let required = max(0, originalBottom - top + 8)
        if abs(required - keyboardLift) > 0.5 { keyboardLift = required }
    }
    @State private var editedMessage: ChatMessage?
    @State private var followsOutput = true
    @State private var nearBottom = true
    @State private var importingText = false
    @State private var scrollPosition = ScrollPosition(edge: .top)
    @State private var visibleMessageCount = 100
    @State private var hasPositionedInitially = false
    private var visibleMessages: [ChatMessage] { Array((store.activeThread?.messages ?? []).suffix(visibleMessageCount)) }
    private var navigationSpace: CGFloat { 0 }
    private var scrollBottomSpace: CGFloat { composerPanelHeight + (keyboardVisible ? 0 : FloatingChrome.navigationHeight) + bottomInset + 12 }

    private var draft: Binding<String> { Binding(get: { store.activeDraft }, set: { store.setDraft($0) }) }
    private var errorPresented: Binding<Bool> {
        Binding(get: { store.errorMessage != nil && editedMessage == nil },
                set: { if !$0 { store.errorMessage = nil } })
    }

    var body: some View {
        Group {
            if store.activeThread?.messages.isEmpty != false {
                VStack(spacing: 0) {
                    welcome.frame(maxWidth: .infinity, maxHeight: .infinity)
                    liftedComposer.padding(.bottom, navigationSpace)
                }
            } else {
            ZStack(alignment: .bottom) {
            ScrollView {
                VStack(alignment: .leading, spacing: 30) {
                    if (store.activeThread?.messages.count ?? 0) > visibleMessageCount {
                        Button("查看更早消息") {
                            visibleMessageCount += 100
                            scrollPosition.scrollTo(edge: .top)
                        }.font(.system(size: 12)).foregroundStyle(Palette.secondary)
                            .frame(maxWidth: .infinity)
                    }
                    ForEach(visibleMessages) { message in
                        MessageView(message: message) {
                            focusComposer(false)
                            editedMessage = message
                        }.id(message.id)
                    }
                    Color.clear.frame(height: 2)
                }
                .scrollTargetLayout()
                .padding(.horizontal, 22).padding(.top, 24).padding(.bottom, 22)
            }
            .accessibilityIdentifier("chat-scroll")
            .scrollPosition($scrollPosition)
            .contentMargins(.bottom, scrollBottomSpace, for: .scrollContent)
            .contentMargins(.bottom, scrollBottomSpace, for: .scrollIndicators)
            .ignoresSafeArea(.container, edges: .bottom)
            .scrollDismissesKeyboard(.interactively)
            .onAppear {
                if !hasPositionedInitially && !store.isPreview {
                    DispatchQueue.main.async { scrollPosition.scrollTo(edge: .bottom) }
                }
                hasPositionedInitially = true
            }
            .onScrollGeometryChange(for: Bool.self) { g in
                g.contentSize.height + g.contentInsets.bottom - g.contentOffset.y - g.containerSize.height < 80
            } action: { _, value in nearBottom = value }
            .onScrollPhaseChange { _, phase in
                if phase == .interacting { followsOutput = false }
                if phase == .idle && nearBottom { followsOutput = true }
            }
            .onChange(of: store.activeThread?.messages.count) { _, _ in
                if followsOutput { scrollPosition.scrollTo(edge: .bottom) }
            }
            .onChange(of: store.activeThread?.messages.last?.content) { _, _ in
                if followsOutput && store.generatingThreadID == store.activeThreadID {
                    scrollPosition.scrollTo(edge: .bottom)
                }
            }
            .onChange(of: store.activeThreadID) { _, _ in
                visibleMessageCount = 100
                followsOutput = true
                DispatchQueue.main.async { scrollPosition.scrollTo(edge: .bottom) }
            }
            liftedComposer.padding(.bottom, navigationSpace)
            }
            .overlay(alignment: .bottomTrailing) {
                if !isComposerFocused && !nearBottom && store.activeThread?.messages.isEmpty == false {
                    GlassCircle(symbol: "arrow.down", label: "回到最新消息") {
                        followsOutput = true
                        withAnimation(.easeOut(duration: 0.2)) { scrollPosition.scrollTo(edge: .bottom) }
                    }.padding(.trailing, 22).padding(.bottom, composerPanelHeight + navigationSpace + 12)
                }
            }
            }
        }
        .background(AppBackground())
        .navigationTitle(store.providerTitle)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button { focusComposer(false); openHistory() } label: { Image(systemName: "line.3.horizontal") }
                    .accessibilityLabel("打开历史对话")
            }
            ToolbarItem(placement: .principal) {
                Text(store.providerTitle).font(.system(size: 17, weight: .semibold)).foregroundStyle(.white)
            }
            ToolbarItem(placement: .topBarTrailing) {
                HStack {
                    Button { store.createThread(); followsOutput = true } label: { Image(systemName: "square.and.pencil") }.accessibilityLabel("新建对话")
                    if let closeStudy { Button(action: closeStudy) { Image(systemName: "xmark") }.accessibilityLabel("返回学习") }
                }
            }
        }
        .toolbar(isComposerFocused ? .hidden : .visible, for: .tabBar)
                .background(KeyboardWindowProbe(boundary: keyboardBoundary))
        .onChange(of: isComposerFocused) { _, focused in keyboardVisible = focused; updateKeyboardLift() }
        .onChange(of: keyboardBoundary.top) { _, _ in updateKeyboardLift() }
        .onDisappear { keyboardVisible = false }
        .sheet(item: $editedMessage) { message in EditMessageView(message: message) }
        .fileImporter(isPresented: $importingText, allowedContentTypes: [.plainText, .text]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard size <= 1024 * 1024 else { throw ChatError.server("请选择小于 1 MB 的文字文件。") }
                let text = try String(contentsOf: url, encoding: .utf8)
                store.setDraft(store.activeDraft.isEmpty ? text : store.activeDraft + "\n\n" + text)
                focusComposer(true)
            } catch { store.errorMessage = error.localizedDescription }
        }
        .alert("暂时没有完成", isPresented: errorPresented) {
            Button("知道了") { store.errorMessage = nil }
        } message: { Text(store.errorMessage ?? "") }
        .task {
            if ProcessInfo.processInfo.arguments.contains("--preview-multiline-keyboard") {
                store.setDraft("第一行输入\n第二行输入\n第三行输入\n第四行输入\n第五行输入\n第六行输入")
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-keyboard") || ProcessInfo.processInfo.arguments.contains("--preview-multiline-keyboard") {
                try? await Task.sleep(nanoseconds: 350_000_000)
                focusComposer(true)
            }
            if ProcessInfo.processInfo.arguments.contains("--preview-edit") {
                editedMessage = store.activeThread?.messages.last
            }
        }
    }

    private var welcome: some View {
        TimelineView(.periodic(from: .now, by: 60)) { timeline in
            let hour = Calendar.current.component(.hour, from: timeline.date)
            let greeting = (5..<12).contains(hour) ? "Good morning." :
                ((12..<18).contains(hour) ? "Good afternoon." : "Good evening.")
            Text(greeting)
                .font(.custom("NotoSerifSC-Regular", size: 30, relativeTo: .title))
                .lineLimit(1).minimumScaleFactor(0.8).multilineTextAlignment(.center)
                .foregroundStyle(Color.white.opacity(0.94))
                .accessibilityIdentifier("time-greeting")
        }.padding(.horizontal, 24)
    }

    private var liftedComposer: some View {
        composer
            .fixedSize(horizontal: false, vertical: true)
            .onGeometryChange(for: CGRect.self) { $0.frame(in: .global) } action: { frame in
                composerFrame = frame
                keyboardBoundary.refresh()
                updateKeyboardLift()
            }
            .offset(y: -keyboardLift)
    }

    private var composer: some View {
        VStack(spacing: 8) {
            if !store.canUseAI {
                Button { focusComposer(false); openSettings() } label: {
                    Label("连接 AI，开始聊天", systemImage: "key")
                        .font(.system(size: 12)).foregroundStyle(Palette.secondary)
                }.padding(.bottom, 2)
            }
            VStack(alignment: .leading, spacing: 14) {
                Group {
                    if usesPreviewKeyboard {
                        PreviewKeyboardField(text: draft, isFocused: previewComposerFocused, focusChanged: { previewComposerFocused = $0 })
                    } else {
                        TextField("输入消息…", text: draft, axis: .vertical)
                            .readingStyle(adjustment: -1).lineLimit(1...5)
                            .focused($composerFocused).tint(.white)
                    }
                }
                    .disabled(!store.canPersist)
                    .accessibilityIdentifier("chat-composer")
                HStack(spacing: 16) {
                    Menu {
                        Button("导入文字文件", systemImage: "doc.text") { importingText = true }
                        Button("粘贴文字", systemImage: "doc.on.clipboard") {
                            if let text = UIPasteboard.general.string { store.setDraft(store.activeDraft + text) }
                        }
                        Button("系统提示词", systemImage: "text.alignleft") { focusComposer(false); openSettings() }
                    } label: {
                        Image(systemName: "plus").font(.system(size: 17, weight: .medium))
                            .frame(width: 34, height: 40).contentShape(Rectangle())
                    }
                    .accessibilityLabel("更多输入操作")
                    Menu {
                        if store.settings.selectedProvider == .chatGPT {
                            ForEach(store.subscription.models) { model in
                                Button(model.displayName) { store.setSubscriptionModel(model.slug) }
                            }
                            Button("AI 连接设置") { openSettings() }
                        } else {
                            Picker("模型", selection: Binding(get: { store.settings.model }, set: { store.setModel($0) })) {
                                ForEach(DeepSeekModel.allCases) { model in Text(model.title).tag(model) }
                            }
                        }
                    } label: {
                        HStack(spacing: 5) {
                            Text(store.modelTitle).lineLimit(1)
                            Image(systemName: "chevron.down").font(.system(size: 9, weight: .semibold))
                        }.font(.system(size: 12)).foregroundStyle(Palette.secondary).frame(minHeight: 40)
                    }.accessibilityLabel("选择模型")
                    Menu {
                        if store.settings.selectedProvider == .chatGPT {
                            Picker("思考程度", selection: Binding(get: { store.settings.selectedSubscriptionEffort }, set: { store.setSubscriptionEffort($0) })) {
                                ForEach(SubscriptionEffort.allCases) { effort in Text(effort.title).tag(effort) }
                            }
                        } else {
                        Toggle("深度思考", isOn: Binding(get: { store.settings.thinkingEnabled }, set: { value in
                            if value != store.settings.thinkingEnabled { store.toggleThinking() }
                        }))
                        Picker("思考程度", selection: Binding(get: { store.settings.effort }, set: { store.setThinkingEffort($0) })) {
                            ForEach(ThinkingEffort.allCases) { effort in Text(effort.title).tag(effort) }
                        }
                        }
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "sparkle")
                            Text(store.settings.selectedProvider == .chatGPT ? "思考·\(store.settings.selectedSubscriptionEffort.title)" : (store.settings.thinkingEnabled ? "思考·\(store.settings.effort.title)" : "思考"))
                            Image(systemName: "chevron.down").font(.system(size: 8))
                        }.font(.system(size: 12)).frame(minHeight: 40).contentShape(Rectangle())
                            .foregroundStyle(store.settings.thinkingEnabled ? Color.white : Palette.secondary)
                    }.accessibilityLabel("选择思考开关和程度")
                    Spacer(minLength: 0)
                    Button {
                        if store.isGenerating { store.stopGeneration() }
                        else {
                            followsOutput = true
                            if store.send(store.activeDraft) { focusComposer(false) }
                        }
                    } label: {
                        Image(systemName: store.isGenerating ? "stop.fill" : "arrow.up")
                            .font(.system(size: 15, weight: .semibold)).foregroundStyle(.black)
                            .frame(width: 36, height: 36).background(.white, in: Circle()).padding(4).contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .disabled(!store.isGenerating && (!store.canUseAI || store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !store.canPersist))
                    .opacity(!store.isGenerating && store.activeDraft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.35 : 1)
                    .accessibilityLabel(store.isGenerating ? "停止生成" : "发送消息")
                }
            }
            .padding(.horizontal, 17).padding(.top, 16).padding(.bottom, 12)
            .clearGlass(radius: 28)
            if store.isGenerating && store.generatingThreadID != store.activeThreadID {
                Text("另一个对话正在生成，右侧按钮可停止。")
                    .font(.system(size: 10)).foregroundStyle(Palette.secondary)
            }
        }
        .padding(.horizontal, 14).padding(.top, 8).padding(.bottom, 10)
        .accessibilityElement(children: .contain).accessibilityIdentifier("chat-composer-panel")
        .onGeometryChange(for: CGFloat.self) { $0.size.height } action: { composerPanelHeight = $0 }
    }
}

@MainActor
struct MessageView: View {
    @EnvironmentObject private var store: AppStore
    @AppStorage("study2027.reading.aiBubble") private var aiBubble = false
    let message: ChatMessage
    let edit: () -> Void
    @State private var copied = false
    private var isLast: Bool { store.activeThread?.messages.last?.id == message.id }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if message.role == .user {
                HStack {
                    Spacer(minLength: 36)
                    Text(message.content).readingStyle().lineSpacing(6).textSelection(.enabled)
                        .padding(.horizontal, 17).padding(.vertical, 14)
                        .background(Color.white.opacity(0.075), in: RoundedRectangle(cornerRadius: 22))
                }
            } else {
                HStack(spacing: 7) {
                    Image(systemName: "sparkle").font(.system(size: 12))
                    Text(message.providerName ?? "DeepSeek").font(.system(size: 11, weight: .medium))
                }.foregroundStyle(Palette.secondary)
                if !message.reasoning.isEmpty, let threadID = store.activeThreadID {
                    ReasoningView(message: message, threadID: threadID)
                }
                if !message.content.isEmpty {
                    MarkdownAnswer(content: message.content)
                        .padding(aiBubble ? 16 : 0)
                        .background(aiBubble ? Color.white.opacity(0.05) : .clear, in: RoundedRectangle(cornerRadius: 20))
                }
                if message.state == .streaming {
                    StreamActivityView(message: message)
                } else {
                    HStack(spacing: 22) {
                        Button {
                            UIPasteboard.general.string = message.content; copied = true
                        } label: { Image(systemName: copied ? "checkmark" : "doc.on.doc") }
                            .accessibilityLabel("复制回答")
                        Button { edit() } label: { Image(systemName: "pencil") }
                            .disabled(store.isGenerating).accessibilityLabel("编辑回答")
                        if isLast {
                            Button { store.regenerate() } label: { Image(systemName: "arrow.clockwise") }
                                .disabled(store.isGenerating || !store.canUseAI).accessibilityLabel("重新生成")
                        }
                        Spacer(minLength: 4)
                        if let usage = message.usage {
                            Text("\(usage.totalTokens.formatted()) Tokens").font(.system(size: 10)).monospacedDigit()
                                .accessibilityLabel("本次请求共 \(usage.totalTokens) 个 Token")
                        }
                    }.font(.system(size: 12)).foregroundStyle(Palette.secondary).buttonStyle(.plain).padding(.top, 2)
                }
            }
            if let note = message.note {
                Text(note).font(.system(size: 11)).foregroundStyle(Palette.secondary)
                    .frame(maxWidth: .infinity, alignment: message.role == .user ? .trailing : .leading)
            }
        }
        .contextMenu {
            Button("复制", systemImage: "doc.on.doc") { UIPasteboard.general.string = message.content }
            Button("编辑文字", systemImage: "pencil") { edit() }.disabled(store.isGenerating)
            if isLast && message.role == .assistant {
                Button("重新生成", systemImage: "arrow.clockwise") { store.regenerate() }
                    .disabled(store.isGenerating || !store.canUseAI)
            }
        }
    }

}

struct MarkdownAnswer: View {
    let content: String
    private var segments: [String] { content.components(separatedBy: "```") }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            ForEach(Array(segments.enumerated()), id: \.offset) { index, segment in
                if index.isMultiple(of: 2) {
                    ForEach(Array(segment.components(separatedBy: "\n\n").enumerated()), id: \.offset) { _, paragraph in
                        if !paragraph.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            if paragraph.hasPrefix("#") {
                                Text(paragraph.drop(while: { $0 == "#" || $0 == " " }))
                                    .readingStyle(adjustment: 1).padding(.top, 6)
                            } else {
                                Text(attributed(paragraph)).readingStyle().lineSpacing(7).textSelection(.enabled)
                                    .foregroundStyle(Color.white.opacity(0.89))
                            }
                        }
                    }
                } else {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("代码").font(.system(size: 10)).foregroundStyle(Palette.secondary)
                            Spacer()
                            Button { UIPasteboard.general.string = codeBody(segment) } label: { Image(systemName: "doc.on.doc") }
                                .font(.system(size: 11)).accessibilityLabel("复制代码")
                        }
                        ScrollView(.horizontal) {
                            Text(codeBody(segment)).font(.system(size: 13, design: .monospaced)).textSelection(.enabled)
                        }
                    }.padding(14).background(Palette.surface, in: RoundedRectangle(cornerRadius: 16))
                }
            }
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
    private func attributed(_ text: String) -> AttributedString {
        (try? AttributedString(markdown: text, options: .init(interpretedSyntax: .inlineOnlyPreservingWhitespace))) ?? AttributedString(text)
    }
    private func codeBody(_ segment: String) -> String {
        guard let newline = segment.firstIndex(of: "\n") else { return segment }
        let first = segment[..<newline].trimmingCharacters(in: .whitespaces)
        return first.isEmpty || (!first.contains(" ") && first.count < 24) ? String(segment[segment.index(after: newline)...]) : segment
    }
}

@MainActor
struct EditMessageView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let message: ChatMessage
    @State private var text = ""
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                Text(message.role == .user ? "保存会直接修改这条消息；重新发送会替换其后的内容。" : "直接修改当前回答，不新建对话。")
                    .font(.system(size: 12)).foregroundStyle(Palette.secondary)
                TextEditor(text: $text).readingStyle().scrollContentBackground(.hidden)
                    .padding(12).background(Palette.surface, in: RoundedRectangle(cornerRadius: 20))
                    .accessibilityIdentifier("message-editor")
                if message.role == .user {
                    Button {
                        if store.editMessage(message.id, text: text, resend: true) { dismiss() }
                    } label: {
                        Text("保存并重新发送").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }.buttonStyle(.glassProminent).tint(.white).foregroundStyle(.black)
                        .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.padding(20).background(Palette.paper)
                .navigationTitle(message.role == .user ? "编辑你的消息" : "编辑回答")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("取消") { dismiss() } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("保存") {
                            if store.editMessage(message.id, text: text, resend: false) { dismiss() }
                        }.disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }
        }.preferredColorScheme(.dark).presentationDragIndicator(.visible)
            .onAppear { text = message.content }
            .alert("暂时没有完成", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("知道了") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
    }
}

