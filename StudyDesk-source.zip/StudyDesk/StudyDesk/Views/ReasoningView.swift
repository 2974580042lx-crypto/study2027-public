import SwiftUI

@MainActor
struct ReasoningView: View {
    @EnvironmentObject private var store: AppStore
    let message: ChatMessage
    let threadID: UUID
    @State private var expanded = ProcessInfo.processInfo.arguments.contains(where: { $0.hasPrefix("--preview-reasoning") })
    @State private var display: Display = ProcessInfo.processInfo.arguments.contains("--preview-reasoning-bilingual") ? .bilingual : .translated
    private enum Display: String, CaseIterable { case original = "原文", translated = "中文", bilingual = "双语" }
    private var busy: Bool { store.isTranslating(threadID: threadID, messageID: message.id) }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Button { withAnimation(.easeOut(duration: 0.2)) { expanded.toggle() } } label: {
                    HStack(spacing: 6) {
                        Image(systemName: expanded ? "chevron.down" : "chevron.right").font(.system(size: 9, weight: .semibold))
                        Text(message.state == .streaming && message.content.isEmpty ? "正在思考" : "思考过程")
                    }.frame(minHeight: 36)
                }.accessibilityLabel(expanded ? "收起思考过程" : "展开思考过程")
                Spacer(minLength: 8)
                if busy {
                    ProgressView().controlSize(.mini)
                    Text("翻译中")
                    Button("取消") { store.cancelTranslation() }.frame(minHeight: 36)
                } else if message.reasoningTranslation != nil {
                    Button { display = .translated; expanded = true } label: {
                        Label("译文", systemImage: "checkmark").frame(minHeight: 36)
                    }.accessibilityLabel("查看已保存的译文")
                } else if message.state != .streaming {
                    Button {
                        expanded = true
                        store.translateReasoning(threadID: threadID, messageID: message.id)
                    } label: {
                        Label(store.translationError(threadID: threadID, messageID: message.id) == nil ? "翻译" : "重试", systemImage: "translate")
                            .frame(minHeight: 36)
                    }
                    .disabled(store.isTranslating || !store.canPersist)
                    .accessibilityLabel("将思考过程翻译成中文")
                    .accessibilityHint("使用当前密钥单独请求翻译，译文会保存在本机")
                }
            }
            .font(.system(size: 12)).foregroundStyle(Ink.ink3).buttonStyle(.plain)

            if expanded {
                if let translated = message.reasoningTranslation {
                    Picker("思考过程显示方式", selection: $display) {
                        ForEach(Display.allCases, id: \.self) { Text($0.rawValue).tag($0) }
                    }.pickerStyle(.segmented)
                    if display != .translated {
                        if display == .bilingual { caption("原文") }
                        bodyText(message.reasoning)
                    }
                    if display != .original {
                        if display == .bilingual { Divider().padding(.vertical, 3); caption("中文译文") }
                        bodyText(translated)
                    }
                } else {
                    bodyText(message.reasoning)
                    if message.state != .streaming && !busy {
                        Text(store.isTranslating ? "另一段思考正在翻译，完成后可继续。" : "按需翻译 · 使用当前 Key · 译文保存后不重复请求")
                            .font(.system(size: 10)).foregroundStyle(Ink.ink3)
                    }
                }
            }
            if let error = store.translationError(threadID: threadID, messageID: message.id) {
                Text(error).font(.system(size: 11)).foregroundStyle(Ink.ink3)
            }
        }
        .onChange(of: message.reasoningTranslation) { old, new in
            if old == nil && new != nil { display = .translated; expanded = true }
        }
    }

    private func bodyText(_ value: String) -> some View {
        Text(value).readingStyle(adjustment: -3).lineSpacing(5)
            .textSelection(.enabled).foregroundStyle(Ink.ink2)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func caption(_ value: String) -> some View {
        Text(value).font(.system(size: 10, weight: .medium)).foregroundStyle(Ink.ink2)
    }
}
