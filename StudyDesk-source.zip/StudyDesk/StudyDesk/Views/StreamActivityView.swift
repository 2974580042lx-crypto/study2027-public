import SwiftUI

struct StreamActivityView: View {
    @EnvironmentObject private var store: AppStore
    let message: ChatMessage
    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { timeline in
            let seconds = max(0, Int(timeline.date.timeIntervalSince(message.createdAt)))
            let phase = !message.content.isEmpty ? ChatStreamPhase.answering :
                (!message.reasoning.isEmpty ? .thinking : (store.generationProgress?.phase ?? .connecting))
            VStack(alignment: .leading, spacing: 7) {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text(phase.title).font(.system(size: 12))
                    Text("\(seconds) 秒").font(.system(size: 11)).monospacedDigit()
                }
                if phase == .thinking {
                    Text("已收到 \(message.reasoning.count.formatted()) 字思考内容，可展开上方查看。")
                        .font(.system(size: 11))
                } else if seconds >= 30 && (phase == .connecting || phase == .waiting) {
                    Text(phase == .connecting ? "尚未收到服务器响应，可以停止，或到设置运行实际对话测试。" :
                        "连接已建立，模型还没有开始返回内容。你可以停止后关闭思考再试。")
                        .font(.system(size: 11))
                }
            }.foregroundStyle(Palette.secondary).padding(.vertical, 4)
                .accessibilityIdentifier("stream-activity")
        }
    }
}
