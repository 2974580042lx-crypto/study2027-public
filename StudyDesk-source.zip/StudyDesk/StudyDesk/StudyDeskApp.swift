import SwiftUI

@main
@MainActor
struct StudyDeskApp: App {
    @StateObject private var store = AppStore()
    @StateObject private var profile = ProfileStore()
    @StateObject private var learning = LearningStore()
    @Environment(\.scenePhase) private var scenePhase
    init() { InkAppearance.apply() }
    var body: some Scene {
        WindowGroup {
            root.environmentObject(store).environmentObject(profile).environmentObject(learning).tint(Ink.ink)
                .font(TypeScale.serif(17))
                .onAppear {
                    store.studyMemoryProvider = { [weak learning] in learning?.memoryContext ?? "" }
                    store.studyAnswerCompleted = { [weak learning] thread, answer in learning?.recordAssistant(thread: thread, answer: answer) }
                }
                .onChange(of: scenePhase) { _, phase in
                    if phase != .active { store.persistNow(); learning.save() }
                }
        }
    }
    @ViewBuilder private var root: some View {
        #if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--subscription-loopback-smoke") {
            SubscriptionLoopbackSmokeView()
        } else { StudyRootView() }
        #else
        StudyRootView()
        #endif
    }
}
