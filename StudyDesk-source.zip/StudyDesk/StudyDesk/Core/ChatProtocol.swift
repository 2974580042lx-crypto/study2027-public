import Foundation

struct APIMessage: Encodable, Equatable, Sendable {
    let role: String
    let content: String
}

struct ChatRequest: Encodable, Sendable {
    // Conservative UTF-8 payload ceiling, not an exact tokenizer estimate.
    // Keep ample room inside the provider's 1M-token context for output.
    static let contextByteBudget = 512000
    let model: String
    let messages: [APIMessage]
    let stream = true
    let streamOptions = StreamOptions()
    let thinking: Thinking
    let reasoningEffort: String?
    let maxTokens: Int

    var diagnosticSummary: String {
        "思考：\(thinking.type)\n档位：\(reasoningEffort ?? "关闭")\n消息数：\(messages.count)\n输入字节：\(messages.reduce(0) { $0 + $1.content.utf8.count })\n输出上限：\(maxTokens)"
    }
    struct Thinking: Encodable, Sendable { let type: String }
    struct StreamOptions: Encodable, Sendable {
        let includeUsage = true
        enum CodingKeys: String, CodingKey { case includeUsage = "include_usage" }
    }
    enum CodingKeys: String, CodingKey {
        case model, messages, stream, thinking
        case streamOptions = "stream_options"
        case reasoningEffort = "reasoning_effort"
        case maxTokens = "max_tokens"
    }
    init(settings: AppSettings, messages: [ChatMessage]) {
        let config = settings.validated()
        model = config.model.rawValue
        thinking = Thinking(type: config.thinkingEnabled ? "enabled" : "disabled")
        reasoningEffort = config.thinkingEnabled ? config.effort.rawValue : nil
        maxTokens = config.maxOutputTokens
        // Failed/unfinished answers remain visible locally, but do not masquerade
        // as complete assistant responses in subsequent API calls.
        var history = messages.filter {
            !$0.content.isEmpty && ($0.role == .user || $0.state == .complete)
        }
        history = Array(history.suffix(config.contextMessageLimit))
        var contentBytes = config.systemPrompt.utf8.count + history.reduce(0) { $0 + $1.content.utf8.count }
        while contentBytes > Self.contextByteBudget && history.count > 1 {
            contentBytes -= history.removeFirst().content.utf8.count
        }
        while history.first?.role == .assistant { history.removeFirst() }
        var outgoing: [APIMessage] = []
        if !config.systemPrompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            outgoing.append(APIMessage(role: "system", content: config.systemPrompt))
        }
        outgoing.append(contentsOf: history.map { APIMessage(role: $0.role.rawValue, content: $0.content) })
        self.messages = outgoing
    }
}

struct StreamEvent: Equatable, Sendable {
    var content = ""
    var reasoning = ""
    var usage: TokenUsage?
    var finishReason: String?
    var isDone = false
}

// Reads SSE events, including comments, CRLF and multi-line data fields.
// The network transport must preserve empty lines: they delimit SSE events.
struct SSEDecoder {
    private var dataLines: [String] = []
    mutating func consume(line rawLine: String) throws -> StreamEvent? {
        let line = rawLine.hasSuffix("\r") ? String(rawLine.dropLast()) : rawLine
        if line.isEmpty { return try flush() }
        if line.hasPrefix("data:") {
            var value = String(line.dropFirst(5))
            if value.hasPrefix(" ") { value.removeFirst() }
            dataLines.append(value)
        }
        return nil
    }
    mutating func flush() throws -> StreamEvent? {
        guard !dataLines.isEmpty else { return nil }
        let payload = dataLines.joined(separator: "\n")
        dataLines.removeAll(keepingCapacity: true)
        if payload.trimmingCharacters(in: .whitespacesAndNewlines) == "[DONE]" {
            return StreamEvent(isDone: true)
        }
        guard let data = payload.data(using: .utf8) else { throw ChatError.malformedStream }
        let chunk: APIChunk
        do { chunk = try JSONDecoder().decode(APIChunk.self, from: data) }
        catch { throw ChatError.malformedStream }
        if chunk.error != nil { throw ChatError.server("DeepSeek 在生成过程中返回错误，请重试。") }
        guard chunk.choices != nil || chunk.usage != nil else { throw ChatError.malformedStream }
        let choice = chunk.choices?.first
        return StreamEvent(content: choice?.delta?.content ?? "",
                           reasoning: choice?.delta?.reasoningContent ?? "",
                           usage: chunk.usage, finishReason: choice?.finishReason)
    }
    private struct APIChunk: Decodable {
        let choices: [Choice]?
        let usage: TokenUsage?
        let error: APIError?
        struct APIError: Decodable { let message: String? }
        struct Choice: Decodable {
            let delta: Delta?
            let finishReason: String?
            enum CodingKeys: String, CodingKey { case delta; case finishReason = "finish_reason" }
        }
        struct Delta: Decodable {
            let content: String?
            let reasoningContent: String?
            enum CodingKeys: String, CodingKey { case content; case reasoningContent = "reasoning_content" }
        }
    }
}

// Split the original bytes ourselves. Text-line adapters may omit the empty
// lines that separate events, joining several JSON chunks into one payload.
// Decode UTF-8 only after a whole line arrives, so split Chinese scalars are safe.
struct SSEByteDecoder {
    private var decoder = SSEDecoder()
    private var lineBytes: [UInt8] = []
    private var skipNextLF = false
    private var firstLine = true

    mutating func consume(byte: UInt8) throws -> StreamEvent? {
        if skipNextLF {
            skipNextLF = false
            if byte == 0x0A { return nil }
        }
        if byte == 0x0D {
            skipNextLF = true
            return try consumeLine()
        }
        if byte == 0x0A { return try consumeLine() }
        lineBytes.append(byte)
        return nil
    }

    mutating func finish() throws -> StreamEvent? {
        if !lineBytes.isEmpty, let event = try consumeLine() { return event }
        return try decoder.flush()
    }

    private mutating func consumeLine() throws -> StreamEvent? {
        guard var line = String(bytes: lineBytes, encoding: .utf8) else {
            throw ChatError.malformedStream
        }
        lineBytes.removeAll(keepingCapacity: true)
        if firstLine {
            firstLine = false
            if line.hasPrefix("\u{FEFF}") { line.removeFirst() }
        }
        return try decoder.consume(line: line)
    }
}
