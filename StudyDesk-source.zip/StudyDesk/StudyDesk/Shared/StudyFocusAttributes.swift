import Foundation
#if canImport(ActivityKit)
import ActivityKit

/// 灵动岛 / 锁屏计时的数据。App 和小组件扩展都会编译这个文件。
struct StudyFocusAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        /// 正在计时时：计时数字从这个时间点开始往上走（已扣除暂停的时间）
        var countingFrom: Date?
        /// 暂停时显示的固定秒数
        var pausedSeconds: Double
        var isPaused: Bool
        /// 番茄倒计时的目标秒数，自由计时为 nil
        var targetSeconds: Double?
        var todaySeconds: Double
    }
    var subject: String
    var label: String
    var isRest: Bool
}
#endif
