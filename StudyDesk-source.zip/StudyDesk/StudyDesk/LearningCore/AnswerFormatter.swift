import Foundation

/// 把 AI 回答里的 Markdown 拆成排版块：小标题、圆点列表、编号列表、分隔线、段落。
/// 同一段里的单个换行会连起来（很多模型习惯一句一行），空行才分段。
enum AnswerFormatter {
    enum Block: Equatable, Sendable {
        case heading(String)
        case bullet(String)
        case numbered(String, String)
        case rule
        case paragraph(String)
    }

    /// 回答格式要求：每次请求附在系统提示词后面
    static let styleInstruction = """
    回答格式：用自然段落写，段落之间空一行；同一段里的句子连着写，不要一句一行。需要分点时用简短的列表，每点一两句。小标题最多用一两个，不用表格，不用分隔线。重点词可以加粗，不要整段加粗。
    """

    static func blocks(_ text: String) -> [Block] {
        var out: [Block] = [], para: [String] = []
        func flush() {
            guard !para.isEmpty else { return }
            out.append(.paragraph(join(para))); para = []
        }
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty { flush(); continue }
            if let m = line.range(of: #"^#{1,6}\s+"#, options: .regularExpression) {
                flush(); out.append(.heading(clean(String(line[m.upperBound...])))); continue
            }
            if line.range(of: #"^(-{3,}|\*{3,}|_{3,})$"#, options: .regularExpression) != nil { flush(); out.append(.rule); continue }
            if let m = line.range(of: #"^[-*•·]\s+"#, options: .regularExpression) {
                flush(); out.append(.bullet(String(line[m.upperBound...]))); continue
            }
            if let m = line.range(of: #"^(\d{1,2})[.、)）]\s*"#, options: .regularExpression) {
                let number = line[m].filter(\.isNumber)
                flush(); out.append(.numbered(String(number), String(line[m.upperBound...]))); continue
            }
            para.append(line)
        }
        flush()
        return out
    }

    /// 同段多行连成一行：中文直接相连，英文之间补一个空格
    static func join(_ lines: [String]) -> String {
        lines.dropFirst().reduce(lines.first ?? "") { acc, next in
            guard let last = acc.last, let first = next.first else { return acc + next }
            return acc + (last.isASCII && last.isLetter && first.isASCII && first.isLetter ? " " : "") + next
        }
    }

    /// 标题里不需要加粗符号
    static func clean(_ s: String) -> String {
        s.replacingOccurrences(of: "**", with: "").replacingOccurrences(of: "__", with: "").trimmingCharacters(in: .whitespaces)
    }
}
