import Foundation

/// 内置史事词典的一条：名词、事件、人物、制度等。内容随 App 打包，只读。
struct HistoryEntry: Codable, Identifiable, Hashable, Sendable {
    struct Link: Codable, Hashable, Sendable { var text: String; var id: String }
    var id: String
    var title: String
    var aliases: [String]
    var kind: String
    var nodeID: String
    var year: Int?
    var endYear: Int?
    var text: String
    var links: [Link]

    var isChina: Bool { nodeID.hasPrefix("h-cn") }

    /// 「前221年」「1840—1842年」，没有年份返回 nil
    var yearText: String? {
        guard let year else { return nil }
        func one(_ y: Int) -> String { y < 0 ? "前\(-y)" : "\(y)" }
        guard let endYear, endYear != year else { return one(year) + "年" }
        return one(year) + "—" + one(endYear) + "年"
    }
}

struct HistoryDictionary: Sendable {
    let entries: [HistoryEntry]
    private let byID: [String: HistoryEntry]

    init(entries: [HistoryEntry]) {
        self.entries = entries
        byID = Dictionary(entries.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
    }

    init(data: Data) throws {
        struct File: Decodable { var entries: [HistoryEntry] }
        self.init(entries: try JSONDecoder().decode(File.self, from: data).entries)
    }

    static let empty = HistoryDictionary(entries: [])

    func entry(_ id: String) -> HistoryEntry? { byID[id] }

    func entries(inNode nodeID: String) -> [HistoryEntry] { entries.filter { $0.nodeID == nodeID } }

    /// 搜索：名称完全相同 > 名称开头 > 名称或别名包含 > 正文包含。去掉空格和书名号再比较。
    func search(_ query: String, limit: Int = 60) -> [HistoryEntry] {
        let q = Self.normalize(query)
        guard !q.isEmpty else { return [] }
        var scored: [(Int, Int, HistoryEntry)] = []
        for (order, e) in entries.enumerated() {
            let title = Self.normalize(e.title)
            let aliases = e.aliases.map(Self.normalize)
            let score: Int
            if title == q || aliases.contains(q) { score = 0 }
            else if title.hasPrefix(q) || aliases.contains(where: { $0.hasPrefix(q) }) { score = 1 }
            else if title.contains(q) || aliases.contains(where: { $0.contains(q) }) { score = 2 }
            else if Self.normalize(e.text).contains(q) { score = 3 }
            else { continue }
            scored.append((score, order, e))
        }
        return scored.sorted { ($0.0, $0.1) < ($1.0, $1.1) }.prefix(limit).map(\.2)
    }

    /// 年表：有年份的条目按开始年份排，同年保持原顺序
    func timeline(china: Bool?) -> [HistoryEntry] {
        entries.enumerated()
            .filter { $0.element.year != nil && (china == nil || $0.element.isChina == china) }
            .sorted { ($0.element.year!, $0.offset) < ($1.element.year!, $1.offset) }
            .map(\.element)
    }

    /// 正文里提到这一条的其他条目（反向链接）
    func mentions(of id: String) -> [HistoryEntry] {
        entries.filter { $0.id != id && $0.links.contains { $0.id == id } }
    }

    static func normalize(_ s: String) -> String {
        s.lowercased().filter { !" 　《》“”\"·・".contains($0) }
    }
}
