import Foundation
import SwiftCSV

struct ImportedCard: Codable {
    var front: String
    var back: String
    var subject: StudySubject?
    var deck: String?
    var source: String?
    var phonetic: String?
    func card(subject fallback: StudySubject, deck fallbackDeck: String) -> StudyCard {
        StudyCard(front: front.trimmingCharacters(in: .whitespacesAndNewlines), back: back,
                  subject: subject ?? fallback, deck: deck ?? fallbackDeck,
                  source: source ?? "个人导入", phonetic: phonetic ?? "")
    }
}
struct ImportedEssay: Codable {
    var id: String
    var kind: EssayKind
    var title: String
    var prompt: String
    var source: String?
    var year: Int?
    var score: Int?
    var note: String?
    var nodeID: String?
    var task: EssayTask {
        EssayTask(id: id, kind: kind, nodeID: nodeID, scope: source ?? "真题", title: String(title.prefix(30)), prompt: prompt,
                  real: true, year: year, score: score, note: note)
    }
}
struct ImportedStudyPack: Codable {
    var cards: [ImportedCard]?
    var questions: [StudyQuestion]?
    var readings: [ReadingPassage]?
    var essays: [ImportedEssay]?
}
enum StudyImport {
    static func parseCards(_ text: String, subject: StudySubject, deck: String) throws -> [StudyCard] {
        let delimiter: Character = text.contains("\t") ? "\t" : ","
        let rows = try delimitedRows(text, separator: delimiter)
        var cards: [StudyCard] = []
        for (index, row) in rows.enumerated() {
            if row.allSatisfy({ $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) { continue }
            if index == 0 && ["word", "front", "单词", "正面"].contains(row[0].lowercased()) { continue }
            guard row.count >= 2, !row[0].trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  !row[1].trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                throw StudyFailure.message("第 \(index + 1) 行缺少正面或释义。请使用两列：单词或问题、释义或答案。")
            }
            cards.append(StudyCard(front: row[0].trimmingCharacters(in: .whitespacesAndNewlines), back: row[1],
                                   subject: subject, deck: row.count > 2 && !row[2].isEmpty ? row[2] : deck,
                                   source: "个人词表导入"))
        }
        guard !cards.isEmpty, cards.count <= 10000 else { throw StudyFailure.message("请导入 1—10000 张卡片。") }
        return cards
    }
    static func delimitedRows(_ text: String, separator: Character) throws -> [[String]] {
        let csv = try CSV<Enumerated>(string: text, delimiter: .character(separator), loadColumns: false)
        return [csv.header] + csv.rows
    }
}
