import Foundation

/// 313 统考论述题常见的贯通性专题。每个专题串起几个考纲章节，用关键词从史事词典里挑相关条目。
struct HistoryTopic: Identifiable, Hashable, Sendable {
    var id: String
    var title: String
    var block: String            // 中国史 / 世界史 / 中外贯通
    var focus: String            // 答这类题要抓的主线
    var nodeIDs: [String]
    var keywords: [String]

    func entries(in dict: HistoryDictionary) -> [HistoryEntry] {
        let nodes = Set(nodeIDs)
        return dict.entries.filter { e in
            nodes.contains(e.nodeID) && keywords.contains { k in e.title.contains(k) || e.aliases.contains { $0.contains(k) } || e.text.contains(k) }
        }
    }
}

enum HistoryTopics {
    static let all: [HistoryTopic] = [
        // 中国古代
        .init(id: "t-centralization", title: "古代中央集权与君主专制的演变", block: "中国史",
              focus: "两条线：中央与地方（分封→郡县→行省），君权与相权（三公→三省→废丞相→军机处）；每一步的原因和影响。",
              nodeIDs: ["h-cn-ancient-01", "h-cn-ancient-02", "h-cn-ancient-04", "h-cn-ancient-05", "h-cn-ancient-06"],
              keywords: ["分封", "郡县", "三公", "推恩", "刺史", "三省", "藩镇", "中央集权", "行省", "丞相", "内阁", "军机处"]),
        .init(id: "t-official-selection", title: "古代选官制度的演变", block: "中国史",
              focus: "世袭→察举→九品中正→科举；选官标准从血缘、门第到才学的变化，和统治基础的扩大。",
              nodeIDs: ["h-cn-ancient-01", "h-cn-ancient-02", "h-cn-ancient-03", "h-cn-ancient-04", "h-cn-ancient-06", "h-cn-modern-04"],
              keywords: ["宗法", "察举", "九品中正", "门阀", "科举", "八股"]),
        .init(id: "t-land-tax", title: "古代土地与赋役制度的演变", block: "中国史",
              focus: "土地：井田→私有→均田→不抑兼并；赋役：租庸调→两税法→一条鞭法→摊丁入亩，趋势是按人丁到按资产、实物到货币。",
              nodeIDs: ["h-cn-ancient-01", "h-cn-ancient-03", "h-cn-ancient-04", "h-cn-ancient-05", "h-cn-ancient-06"],
              keywords: ["井田", "初税亩", "均田", "租庸调", "两税", "一条鞭", "青苗", "募役"]),
        .init(id: "t-economic-south", title: "经济重心南移与商品经济", block: "中国史",
              focus: "南移的三个阶段（东晋南朝、安史之乱后、南宋完成）和原因；宋代商业的突破、明清资本主义萌芽为何发展缓慢。",
              nodeIDs: ["h-cn-ancient-03", "h-cn-ancient-04", "h-cn-ancient-05", "h-cn-ancient-06"],
              keywords: ["江南", "南移", "大运河", "交子", "坊市", "草市", "资本主义萌芽"]),
        .init(id: "t-ethnic-unity", title: "统一多民族国家的发展与边疆治理", block: "中国史",
              focus: "各朝的民族政策和边疆机构（西域都护府、宣政院、驻藏大臣、伊犁将军），民族交融的过程。",
              nodeIDs: ["h-cn-ancient-02", "h-cn-ancient-03", "h-cn-ancient-04", "h-cn-ancient-05", "h-cn-ancient-06"],
              keywords: ["西域", "匈奴", "孝文帝", "吐蕃", "文成公主", "宣政院", "行省", "驻藏", "伊犁", "台湾", "雅克萨"]),
        .init(id: "t-thought", title: "儒学的演变与思想文化", block: "中国史",
              focus: "百家争鸣→独尊儒术→宋明理学→明清之际的批判思想；儒学怎样适应不同时代的统治需要。",
              nodeIDs: ["h-cn-ancient-01", "h-cn-ancient-02", "h-cn-ancient-05", "h-cn-ancient-06"],
              keywords: ["孔子", "百家", "儒", "董仲舒", "理学", "心学", "李贽", "黄宗羲", "顾炎武"]),
        .init(id: "t-foreign-exchange", title: "古代中外交流与对外政策", block: "中国史",
              focus: "从丝绸之路、唐代开放到郑和下西洋、明清海禁闭关；开放与封闭背后的原因。",
              nodeIDs: ["h-cn-ancient-02", "h-cn-ancient-04", "h-cn-ancient-05", "h-cn-ancient-06"],
              keywords: ["丝绸之路", "张骞", "玄奘", "鉴真", "马可", "郑和", "海禁", "闭关", "一口通商"]),
        // 中国近现代
        .init(id: "t-modernization-cn", title: "近代中国的近代化探索", block: "中国史",
              focus: "器物（洋务）→制度（维新、辛亥）→思想（新文化）的递进；各自的阶级基础、成就和局限。",
              nodeIDs: ["h-cn-modern-01", "h-cn-modern-02", "h-cn-modern-03", "h-cn-modern-04", "h-cn-modern-05"],
              keywords: ["魏源", "资政新篇", "洋务", "中体西用", "戊戌", "维新", "新政", "立宪", "同盟会", "辛亥", "临时约法", "新文化"]),
        .init(id: "t-semicolonial", title: "列强侵华与半殖民地半封建社会的形成", block: "中国史",
              focus: "从《南京条约》到《辛丑条约》，条约内容的变化（商品输出→资本输出）和中国社会性质一步步加深。",
              nodeIDs: ["h-cn-modern-01", "h-cn-modern-02", "h-cn-modern-03"],
              keywords: ["鸦片战争", "南京条约", "北京条约", "中法", "甲午", "马关", "瓜分", "八国联军", "辛丑"]),
        .init(id: "t-new-democratic", title: "新民主主义革命的道路", block: "中国史",
              focus: "五四到 1949：国共两次合作、农村包围城市道路的形成、抗战中的统一战线、解放战争胜利的原因。",
              nodeIDs: ["h-cn-modern-05", "h-cn-modern-06", "h-cn-modern-07", "h-cn-modern-08", "h-cn-modern-09"],
              keywords: ["五四", "中国共产党", "国共合作", "北伐", "南昌", "井冈山", "遵义", "西安事变", "统一战线", "论持久战", "七届二中全会"]),
        .init(id: "t-socialist-path", title: "新中国社会主义道路的探索", block: "中国史",
              focus: "过渡时期总路线、三大改造、八大的正确探索与随后的曲折、十一届三中全会后的改革开放；正反两方面经验。",
              nodeIDs: ["h-cn-contemporary-01", "h-cn-contemporary-02", "h-cn-contemporary-03", "h-cn-contemporary-04"],
              keywords: ["过渡时期", "三大改造", "一五", "八大", "大跃进", "八字方针", "十一届三中全会", "联产承包", "特区", "市场经济"]),
        .init(id: "t-prc-diplomacy", title: "新中国外交的发展", block: "中国史",
              focus: "建国初的方针、和平共处五项原则、70 年代外交突破（恢复联合国席位、中美中日关系）、改革开放后的全方位外交。",
              nodeIDs: ["h-cn-contemporary-01", "h-cn-contemporary-03", "h-cn-contemporary-04"],
              keywords: ["和平共处", "日内瓦", "万隆", "联合国", "尼克松", "中日", "世界贸易组织"]),
        // 世界史
        .init(id: "t-ancient-democracy", title: "古代希腊罗马的政治文明", block: "世界史",
              focus: "雅典民主的形成（梭伦→克利斯提尼→伯里克利）及其局限；罗马从共和到帝国，罗马法的发展。",
              nodeIDs: ["h-w-ancient-04", "h-w-ancient-05"],
              keywords: ["城邦", "梭伦", "克利斯提尼", "伯里克利", "共和", "十二铜表法", "元首", "罗马法"]),
        .init(id: "t-feudal-europe", title: "西欧封建社会的形成与瓦解", block: "世界史",
              focus: "采邑改革、封君封臣、庄园制如何形成封建制度；城市兴起、黑死病、王权加强如何瓦解它。",
              nodeIDs: ["h-w-medieval-01", "h-w-medieval-05"],
              keywords: ["采邑", "封君", "庄园", "农奴", "城市", "大宪章", "议会", "三级会议", "黑死病"]),
        .init(id: "t-transition", title: "从中世纪到近代：思想解放与世界连成整体", block: "世界史",
              focus: "文艺复兴、宗教改革、启蒙运动三次思想解放的递进；新航路开辟、价格革命对资本主义兴起的作用。",
              nodeIDs: ["h-w-medieval-05", "h-w-modern-01"],
              keywords: ["文艺复兴", "人文主义", "宗教改革", "路德", "加尔文", "新航路", "价格革命", "启蒙"]),
        .init(id: "t-bourgeois-revolutions", title: "资产阶级革命与代议制的确立", block: "世界史",
              focus: "英国、美国、法国、德国确立代议制的不同道路（君主立宪、总统共和、反复斗争、二元君主制）及原因比较。",
              nodeIDs: ["h-w-modern-01", "h-w-modern-02", "h-w-modern-04"],
              keywords: ["英国资产阶级革命", "光荣革命", "权利法案", "责任内阁", "独立宣言", "1787", "法国大革命", "人权宣言", "拿破仑", "德意志帝国宪法"]),
        .init(id: "t-industrialization", title: "工业革命与世界格局", block: "世界史",
              focus: "两次工业革命的标志和影响（生产方式、阶级关系、世界市场、殖民扩张），垄断资本主义的出现。",
              nodeIDs: ["h-w-modern-03", "h-w-modern-05", "h-w-modern-06"],
              keywords: ["工业革命", "珍妮机", "蒸汽机", "电力", "垄断", "宪章", "瓜分非洲", "殖民"]),
        .init(id: "t-modernization-paths", title: "19 世纪各国的改革与现代化道路", block: "中外贯通",
              focus: "俄国农奴制改革、日本明治维新、中国洋务与维新、美国内战的比较：为什么有的成功、有的失败。",
              nodeIDs: ["h-w-modern-04", "h-cn-modern-02", "h-cn-modern-03"],
              keywords: ["农奴制改革", "明治维新", "南北战争", "洋务", "戊戌", "德意志统一", "意大利统一"]),
        .init(id: "t-socialism-practice", title: "社会主义从理论到实践", block: "中外贯通",
              focus: "《共产党宣言》、巴黎公社、十月革命、苏联模式的形成与改革、苏联解体；对比中国道路的探索。",
              nodeIDs: ["h-w-modern-03", "h-w-contemporary-02", "h-w-contemporary-05", "h-cn-contemporary-04"],
              keywords: ["共产党宣言", "巴黎公社", "十月革命", "新经济政策", "斯大林", "赫鲁晓夫", "戈尔巴乔夫", "苏联解体", "南方谈话"]),
        .init(id: "t-capitalism-adjust", title: "资本主义的危机与调整", block: "世界史",
              focus: "1929 年危机的原因、罗斯福新政的国家干预、凯恩斯主义，与法西斯道路的对比；战后福利国家。",
              nodeIDs: ["h-w-contemporary-03", "h-w-contemporary-06"],
              keywords: ["经济危机", "罗斯福", "凯恩斯", "法西斯", "希特勒", "布雷顿森林"]),
        .init(id: "t-international-order", title: "20 世纪国际格局的演变", block: "世界史",
              focus: "凡尔赛—华盛顿体系→雅尔塔体系与两极格局→多极化；每个体系形成的背景和内在矛盾。",
              nodeIDs: ["h-w-contemporary-01", "h-w-contemporary-03", "h-w-contemporary-04", "h-w-contemporary-05", "h-w-contemporary-06"],
              keywords: ["凡尔赛", "华盛顿会议", "国际联盟", "绥靖", "慕尼黑", "雅尔塔", "联合国", "杜鲁门", "马歇尔", "北约", "苏联解体", "欧盟", "不结盟"]),
        .init(id: "t-national-liberation", title: "殖民扩张与民族解放运动", block: "中外贯通",
              focus: "从新航路后的殖民到 20 世纪亚非拉独立：拉美独立、印度、埃及、非洲独立年，殖民体系瓦解的过程。",
              nodeIDs: ["h-w-modern-05", "h-w-contemporary-06"],
              keywords: ["拉丁美洲", "门罗", "印度", "瓜分非洲", "阿杜瓦", "苏伊士", "非洲独立", "种族隔离"]),
    ]

    static func topic(_ id: String) -> HistoryTopic? { all.first { $0.id == id } }
    static func topics(touching nodeID: String) -> [HistoryTopic] { all.filter { $0.nodeIDs.contains(nodeID) } }
}
