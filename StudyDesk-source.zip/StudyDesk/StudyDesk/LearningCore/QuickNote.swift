import Foundation

/// 一句话记录：保存时不调用 AI，只按关键词猜一个科目，用户可以手动改。
enum QuickNote {
    private static let politics = ["政治", "马原", "马克思", "毛中特", "毛概", "史纲", "近现代史纲要", "思修", "法基", "思想道德", "时政", "肖秀荣", "徐涛", "腿姐", "1000题", "1000 题"]
    private static let english = ["英语", "单词", "背词", "阅读", "完形", "新题型", "翻译", "作文", "长难句", "真题阅读"]

    /// 猜不出来时返回 nil（界面上显示「自动」，保存时归到 313）。
    static func guessSubject(_ text: String) -> StudySubject? {
        let t = text.lowercased()
        if politics.contains(where: { t.contains($0.lowercased()) }) { return .politics }
        if english.contains(where: { t.contains($0.lowercased()) }) || t.range(of: "[a-z]{4,}", options: .regularExpression) != nil { return .english }
        let history = ["313", "历史", "古代史", "近代史", "现代史", "世界史", "中古", "大纲解析", "长孙博", "名词解释", "论述"]
        if history.contains(where: { t.contains($0) }) { return .history }
        return nil
    }

    /// 时间轴上显示的标题：去掉首尾空白，过长截断（原文完整保存在 detail）。
    static func title(for text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        let firstLine = (trimmed.components(separatedBy: .newlines).first ?? trimmed).trimmingCharacters(in: .whitespaces)
        return firstLine.count > 38 ? String(firstLine.prefix(38)) + "…" : firstLine
    }
}
