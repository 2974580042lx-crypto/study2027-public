import Foundation

/// 错题按间隔重做：只根据已有作答记录推算，不新增存储字段。
///
/// 规则：答错后进入错题本；之后在「答错 1 天后」答对一次、再在「上次答对 3 天后」答对一次，
/// 才算真正掌握、移出错题本。任何一次再答错都从头开始。
/// 同一天里连着答对多次只算一次，避免刚错完立刻刷对就「假掌握」。
struct WrongQuestionState: Equatable, Sendable {
    enum Stage: Equatable, Sendable {
        /// 已经到了该重做的时间
        case due
        /// 还在等间隔，`next` 之后才需要再做
        case waiting(next: Date)
        /// 已掌握，不再出现在错题本
        case mastered
    }
    var questionID: String
    var stage: Stage
    /// 本轮已过关的次数（0、1；2 即掌握）
    var passes: Int
    var lastWrong: Date
}

enum WrongQuestionSchedule {
    /// 第 1 次、第 2 次重做各自需要等待的天数
    static let gaps: [Int] = [1, 3]

    static func states(attempts: [QuestionAttempt], now: Date = Date(), calendar: Calendar = .current) -> [String: WrongQuestionState] {
        var byQuestion: [String: [QuestionAttempt]] = [:]
        for attempt in attempts { byQuestion[attempt.questionID, default: []].append(attempt) }
        var result: [String: WrongQuestionState] = [:]
        for (id, list) in byQuestion {
            if let state = state(for: id, attempts: list, now: now, calendar: calendar) { result[id] = state }
        }
        return result
    }

    /// 从来没答错过的题返回 nil。
    static func state(for questionID: String, attempts: [QuestionAttempt], now: Date = Date(), calendar: Calendar = .current) -> WrongQuestionState? {
        let sorted = attempts.sorted { $0.date < $1.date }
        guard let lastWrongIndex = sorted.lastIndex(where: { !$0.correct }) else { return nil }
        let lastWrong = sorted[lastWrongIndex].date
        var passes = 0
        var anchor = lastWrong
        for attempt in sorted[(lastWrongIndex + 1)...] where attempt.correct && passes < gaps.count {
            // 必须在「锚点所在日 + 间隔天数」当天或之后答对才算一次过关
            if attempt.date >= dueDate(after: anchor, days: gaps[passes], calendar: calendar) {
                passes += 1
                anchor = attempt.date
            }
        }
        if passes >= gaps.count {
            return WrongQuestionState(questionID: questionID, stage: .mastered, passes: passes, lastWrong: lastWrong)
        }
        let next = dueDate(after: anchor, days: gaps[passes], calendar: calendar)
        let stage: WrongQuestionState.Stage = now >= next ? .due : .waiting(next: next)
        return WrongQuestionState(questionID: questionID, stage: stage, passes: passes, lastWrong: lastWrong)
    }

    /// 按自然日计算：某天答错，隔 1 天指第二天 0 点起就可以重做。
    static func dueDate(after date: Date, days: Int, calendar: Calendar) -> Date {
        let start = calendar.startOfDay(for: date)
        return calendar.date(byAdding: .day, value: days, to: start) ?? date.addingTimeInterval(Double(days) * 86_400)
    }
}
