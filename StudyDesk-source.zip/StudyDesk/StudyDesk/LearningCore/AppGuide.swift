import Foundation

/// 内置使用说明。用户问到 App 本身时才把全文交给 AI，平时不额外占用上下文。
enum AppGuide {
    // 只放明显指向 App 的词；「哪里」「记忆」这类学习提问里也常见的词不放，免得每次都附带全文
    private static let triggers = [
        "怎么用", "如何使用", "怎么操作", "使用说明", "教程", "研习", "app", "软件", "入口", "功能",
        "灵动岛", "考纲", "史事", "词典", "年表", "大题", "批改", "专题", "周报", "今日计划",
        "错题本", "错题重做", "备份", "能做什么", "怎么开始",
    ]

    /// 这句话是不是在问 App 怎么用
    static func isAboutApp(_ text: String) -> Bool {
        let t = text.lowercased().filter { !$0.isWhitespace }
        return triggers.contains { t.contains($0) }
    }

    /// 需要时返回附加给 AI 的说明，否则返回 nil
    static func context(for question: String, guide: String) -> String? {
        guard !guide.isEmpty, isAboutApp(question) else { return nil }
        return """
        以下是「研习」App 的官方使用说明。用户问到 App 的功能、入口或用法时，按说明回答，说清楚在哪里点；说明里没有的功能就直说没有，不要编造。回答时不必复述整份说明，挑相关的部分讲。
        <app_guide>
        \(guide)
        </app_guide>
        """
    }

    /// 把说明拆成「标题 / 段落 / 列表项」，供界面排版
    enum Block: Equatable, Sendable { case title(String), heading(String), bullet(String, Int), numbered(String, String), paragraph(String) }

    static func blocks(_ markdown: String) -> [Block] {
        markdown.components(separatedBy: .newlines).compactMap { raw in
            let indent = raw.prefix { $0 == " " }.count / 2
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty { return nil }
            if line.hasPrefix("## ") { return .heading(String(line.dropFirst(3))) }
            if line.hasPrefix("# ") { return .title(String(line.dropFirst(2))) }
            if line.hasPrefix("- ") { return .bullet(String(line.dropFirst(2)), indent) }
            if let dot = line.firstIndex(of: "."), line[..<dot].allSatisfy(\.isNumber), !line[..<dot].isEmpty {
                return .numbered(String(line[..<dot]), line[line.index(after: dot)...].trimmingCharacters(in: .whitespaces))
            }
            return .paragraph(line)
        }
    }
}
