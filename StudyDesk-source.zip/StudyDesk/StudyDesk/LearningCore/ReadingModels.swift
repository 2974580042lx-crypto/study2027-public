import Foundation

enum ReadingVerification: String, Codable, Sendable {
    case verified, pending, conflict, example
    var title: String {
        switch self { case .verified: return "已核对"; case .pending: return "待核对"; case .conflict: return "答案有差异"; case .example: return "原创示例" }
    }
    var permitsGrading: Bool { self == .verified || self == .example }
}

struct ReadingQuestion: Identifiable, Codable, Equatable, Sendable {
    var id: String
    var number: Int
    var stem: String
    var options: [String]
    var answer: Int?
    var explanation: String?
    var verification: ReadingVerification
    var source: String
    var sourceURL: String?
    var canGrade: Bool { verification.permitsGrading && answer != nil }
    func validate() throws {
        guard !id.isEmpty, id.count <= 200, (1...100).contains(number), !stem.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              stem.count <= 10000, options.count == 4, options.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.count <= 5000 }),
              answer == nil || options.indices.contains(answer!), !source.isEmpty,
              !verification.permitsGrading || answer != nil else { throw StudyFailure.message("阅读题的题号、四个选项、答案或核验状态不完整。") }
    }
}

struct ReadingPassage: Identifiable, Codable, Equatable, Sendable {
    var id: String
    var title: String
    var year: Int?
    var textNumber: Int?
    var paragraphs: [String]
    var questions: [ReadingQuestion]
    var source: String
    var sourceURL: String?
    var isExample: Bool
    var fullText: String { paragraphs.joined(separator: "\n\n") }
    var label: String { isExample ? "功能示例 · 非真题" : [year.map { "\($0) 年" }, textNumber.map { "Text \($0)" }].compactMap { $0 }.joined(separator: " · ") }
    func validate() throws {
        guard !id.isEmpty, id.count <= 200, !title.isEmpty, !source.isEmpty, (1...100).contains(paragraphs.count),
              paragraphs.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && $0.count <= 30000 }),
              fullText.utf8.count <= 200000, questions.count <= 20,
              Set(questions.map(\.id)).count == questions.count,
              Set(questions.map(\.number)).count == questions.count,
              year == nil || (1980...2100).contains(year!), textNumber == nil || (1...10).contains(textNumber!) else { throw StudyFailure.message("阅读文章格式不正确、题号重复或内容过长。") }
        for question in questions { try question.validate() }
        if !isExample && questions.contains(where: { $0.verification == .example }) { throw StudyFailure.message("示例答案不能作为真题答案导入。") }
    }
}

struct ReadingAttempt: Identifiable, Codable, Equatable, Sendable {
    var id = UUID()
    var passageID: String
    var selected: [String: Int] = [:]
    var paragraph = 0
    var startedAt = Date()
    var submittedAt: Date?
    var correct: Int?
    var graded: Int?
}

struct ReadingWordExample: Codable, Equatable, Sendable {
    var passageID: String
    var passageTitle: String
    var quote: String
    var resourceID: String?
    var page: Int?
}
struct ReadingWord: Identifiable, Codable, Equatable, Sendable {
    var id: String { cardID }
    var cardID: String
    var normalizedTerm: String
    var examples: [ReadingWordExample]
    var addedAt = Date()
}

enum ReadingWords {
    static func context(_ text: String, selection: NSRange) -> String {
        let ns = text as NSString
        guard selection.location >= 0, selection.length > 0, NSMaxRange(selection) <= ns.length else { return "" }
        let start = max(0, selection.location - 220), end = min(ns.length, NSMaxRange(selection) + 220)
        if let range = Range(NSRange(location: start, length: end - start), in: text) { return String(text[range]) }
        return ns.substring(with: selection)
    }
    static func normalized(_ term: String) -> String {
        term.precomposedStringWithCanonicalMapping
            .trimmingCharacters(in: .whitespacesAndNewlines.union(.punctuationCharacters))
            .split(whereSeparator: \.isWhitespace).joined(separator: " ").lowercased()
    }
}

extension StudySnapshot {
    func readingAttempt(for passageID: String) -> ReadingAttempt? { readingAttempts?.last(where: { $0.passageID == passageID }) }
    @discardableResult mutating func beginReading(_ passageID: String, restart: Bool = false, now: Date = Date()) throws -> UUID {
        guard (readingPassages ?? []).contains(where: { $0.id == passageID }) else { throw StudyFailure.message("找不到这篇阅读。") }
        if let existing = readingAttempt(for: passageID), !restart || existing.submittedAt == nil { return existing.id }
        let attempt = ReadingAttempt(passageID: passageID, startedAt: now)
        readingAttempts = (readingAttempts ?? []) + [attempt]
        return attempt.id
    }
    mutating func chooseReadingOption(attemptID: UUID, questionID: String, option: Int) throws {
        guard let index = readingAttempts?.firstIndex(where: { $0.id == attemptID }), let attempt = readingAttempts?[index], attempt.submittedAt == nil,
              let passage = readingPassages?.first(where: { $0.id == attempt.passageID }),
              let question = passage.questions.first(where: { $0.id == questionID }), question.options.indices.contains(option) else { throw StudyFailure.message("这次作答已经提交，或选项不属于当前阅读。") }
        readingAttempts?[index].selected[questionID] = option
    }
    @discardableResult mutating func submitReading(_ attemptID: UUID, now: Date = Date()) throws -> Bool {
        guard let index = readingAttempts?.firstIndex(where: { $0.id == attemptID }), var attempt = readingAttempts?[index],
              let passage = readingPassages?.first(where: { $0.id == attempt.passageID }) else { throw StudyFailure.message("找不到这次阅读记录。") }
        guard attempt.submittedAt == nil else { return false }
        guard !passage.questions.isEmpty, passage.questions.allSatisfy({ q in attempt.selected[q.id].map { q.options.indices.contains($0) } == true }) else { throw StudyFailure.message("请先完成本篇的全部题目。") }
        let gradable = passage.questions.filter(\.canGrade)
        let correct = gradable.filter { attempt.selected[$0.id] == $0.answer }.count
        attempt.submittedAt = now; attempt.correct = correct; attempt.graded = gradable.count
        readingAttempts?[index] = attempt
        for question in passage.questions {
            let correct: Bool? = question.canGrade ? attempt.selected[question.id] == question.answer : nil
            var answerEvent = LearningEvent(subject: .english, kind: .question, title: "\(passage.title) · 第 \(question.number) 题",
                detail: correct.map { $0 ? "答对" : "答错" } ?? "已作答，答案待核验", start: now, end: now,
                referenceID: "reading-question:" + passage.id + ":" + question.id, correct: correct)
            answerEvent.readingPassageID = passage.id; answerEvent.readingQuestionID = question.id
            answerEvent.readingAttemptID = attemptID
            events.append(answerEvent)
        }
        var event = LearningEvent(subject: .english, kind: .material, title: passage.title,
            detail: "完成阅读 · 已核验 \(gradable.count) 题，答对 \(correct) 题" + (gradable.count < passage.questions.count ? "；其余答案待核验" : ""),
            start: now, end: now, referenceID: "reading:" + passage.id)
        event.readingPassageID = passage.id
        event.readingAttemptID = attemptID
        events.append(event)
        return true
    }
    @discardableResult mutating func collectReadingWord(term: String, definition: String, example: ReadingWordExample, now: Date = Date()) throws -> String {
        let normalized = ReadingWords.normalized(term)
        guard !normalized.isEmpty, normalized.count <= 80, normalized.split(separator: " ").count <= 6,
              (readingPassages ?? []).contains(where: { $0.id == example.passageID }) || resources.contains(where: { $0.id == example.resourceID && $0.subject == .english }) else { throw StudyFailure.message("请选择一个单词或简短词组。") }
        let existingCollection = readingWords?.first(where: { $0.normalizedTerm == normalized })
        let existingCard = existingCollection.flatMap { collection in cards.first(where: { $0.id == collection.cardID }) }
            ?? cards.first(where: { $0.subject == .english && ReadingWords.normalized($0.front) == normalized })
        let cardID: String
        if let existingCard { cardID = existingCard.id }
        else {
            guard !definition.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, definition.count <= 10000 else { throw StudyFailure.message("这个词暂没有本地释义，请补充释义后保存。") }
            let card = StudyCard(front: normalized, back: definition, subject: .english, deck: "阅读生词", source: example.passageTitle, note: String(example.quote.prefix(800)))
            cards.append(card); cardID = card.id
        }
        var words = readingWords ?? []
        let limited = ReadingWordExample(passageID: example.passageID, passageTitle: String(example.passageTitle.prefix(200)), quote: String(example.quote.prefix(800)), resourceID: example.resourceID, page: example.page)
        if let index = words.firstIndex(where: { $0.cardID == cardID || $0.normalizedTerm == normalized }) {
            if !words[index].examples.contains(limited), words[index].examples.count < 50 { words[index].examples.append(limited) }
        } else {
            words.insert(ReadingWord(cardID: cardID, normalizedTerm: normalized, examples: [limited], addedAt: now), at: 0)
            var event = LearningEvent(subject: .english, kind: .note, title: normalized, detail: "加入阅读生词本 · \(example.passageTitle)", start: now, end: now, referenceID: cardID)
            event.collectedCardID = cardID; events.append(event)
        }
        readingWords = words
        return cardID
    }
    func validateReadings() throws {
        let passages = readingPassages ?? [], attempts = readingAttempts ?? [], words = readingWords ?? []
        guard passages.count <= 3000, attempts.count <= 300000, words.count <= 30000,
              Set(passages.map(\.id)).count == passages.count, Set(attempts.map(\.id)).count == attempts.count,
              Set(words.map(\.cardID)).count == words.count, Set(words.map(\.normalizedTerm)).count == words.count else { throw StudyFailure.message("阅读记录重复或数量过大。") }
        let byID = Dictionary(uniqueKeysWithValues: passages.map { ($0.id, $0) })
        for passage in passages { try passage.validate() }
        for attempt in attempts {
            guard let passage = byID[attempt.passageID], passage.paragraphs.indices.contains(attempt.paragraph),
                  attempt.startedAt.timeIntervalSince1970.isFinite, attempt.selected.count <= passage.questions.count else { throw StudyFailure.message("阅读进度不属于有效文章。") }
            for (id, selected) in attempt.selected {
                guard let q = passage.questions.first(where: { $0.id == id }), q.options.indices.contains(selected) else { throw StudyFailure.message("阅读选项记录不正确。") }
            }
            if let date = attempt.submittedAt {
                guard date >= attempt.startedAt, date.timeIntervalSince1970.isFinite,
                      attempt.selected.count == passage.questions.count,
                      let correct = attempt.correct, let graded = attempt.graded,
                      (0...passage.questions.count).contains(graded), (0...graded).contains(correct) else { throw StudyFailure.message("阅读成绩记录不正确。") }
            }
        }
        let englishIDs = Set(cards.filter { $0.subject == .english }.map(\.id))
        for word in words {
            guard englishIDs.contains(word.cardID), !word.normalizedTerm.isEmpty, (1...50).contains(word.examples.count),
                  word.examples.allSatisfy({ (byID[$0.passageID] != nil || $0.resourceID?.isEmpty == false) && $0.quote.count <= 800 && ($0.page == nil || $0.page! >= 0) }) else { throw StudyFailure.message("生词本的词卡或原句来源丢失。") }
        }
    }
}

extension StudyAskContext {
    static func reading(_ passage: ReadingPassage, quote: String, question: ReadingQuestion? = nil, attempt: ReadingAttempt?) -> Self {
        var background = passage.fullText
        if let question {
            background += "\n\n第 \(question.number) 题：\(question.stem)\n"
            background += question.options.enumerated().map { "\(String(UnicodeScalar(65 + $0.offset)!)). \($0.element)" }.joined(separator: "\n")
            if let selected = attempt?.selected[question.id] { background += "\n用户选择：" + String(UnicodeScalar(65 + selected)!) }
            if attempt?.submittedAt != nil && question.canGrade, let answer = question.answer {
                background += "\n资料参考答案：" + String(UnicodeScalar(65 + answer)!) + "\n核验状态：" + question.verification.title + "\n" + (question.explanation ?? "")
            } else if !question.canGrade { background += "\n此题参考答案尚未核验，请基于原文解释，不把推测说成已核实答案。" }
        }
        return Self(referenceID: "reading:" + passage.id + (question.map { ":" + $0.id } ?? ""), subject: .english,
            title: passage.title + (question.map { " · 第 \($0.number) 题" } ?? ""), quote: quote, background: background,
            source: passage.source, mode: attempt?.submittedAt == nil ? .hint : .explain)
    }
}
