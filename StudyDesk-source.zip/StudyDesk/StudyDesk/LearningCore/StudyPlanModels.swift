import Foundation

// MARK: - 考纲地图

/// 掌握程度 0…4：没学 / 有点印象 / 还不牢 / 基本掌握 / 熟练
enum Mastery {
    static let titles = ["没学", "有点印象", "还不牢", "基本掌握", "熟练"]
    static func title(_ level: Int) -> String { titles[max(0, min(4, level))] }
    /// 按掌握程度安排下次回顾：印象 2 天、不牢 5 天、基本 12 天、熟练 25 天。
    static func reviewGap(_ level: Int) -> Int? {
        switch level { case 1: return 2; case 2: return 5; case 3: return 12; case 4: return 25; default: return nil }
    }
}

struct SyllabusNode: Codable, Identifiable, Equatable, Sendable {
    var id: String
    var subject: StudySubject
    var block: String
    var title: String
    var order: Int
    var mastery: Int = 0
    var lastStudied: Date?
    var nextReview: Date?

    mutating func setMastery(_ level: Int, at now: Date = Date(), calendar: Calendar = .current) {
        mastery = max(0, min(4, level))
        lastStudied = now
        nextReview = Mastery.reviewGap(mastery).flatMap { calendar.date(byAdding: .day, value: $0, to: calendar.startOfDay(for: now)) }
    }
}

/// 预置章节：按教材常用的时期 / 章划分，只到「节」这一层，具体页码对照自己的书。
/// 用户可以在考纲页里改名、增删。
enum SyllabusSeed {
    static let version = "2026-10 · 按时期与教材章划分，可对照长孙博《大纲解析》目录调整"

    static func nodes() -> [SyllabusNode] {
        var result: [SyllabusNode] = []
        func add(_ subject: StudySubject, _ prefix: String, _ block: String, _ titles: [String]) {
            for (i, title) in titles.enumerated() {
                result.append(SyllabusNode(id: "\(prefix)-\(String(format: "%02d", i + 1))", subject: subject, block: block, title: title, order: result.count))
            }
        }
        add(.history, "h-cn-ancient", "中国古代史", ["先秦", "秦汉", "三国两晋南北朝", "隋唐五代", "宋辽夏金元", "明清（鸦片战争前）"])
        add(.history, "h-cn-modern", "中国近代史", ["鸦片战争与太平天国", "洋务运动与边疆危机", "甲午战争与维新变法", "清末新政与辛亥革命", "北洋政府与新文化运动", "国民革命", "南京国民政府十年", "抗日战争", "解放战争"])
        add(.history, "h-cn-contemporary", "中国现代史", ["新中国成立与过渡时期", "全面建设社会主义（1956—1966）", "“文化大革命”", "改革开放与现代化建设"])
        add(.history, "h-w-ancient", "世界古代史", ["史前与文明起源", "两河流域与古埃及", "古代印度与波斯", "古代希腊", "古代罗马"])
        add(.history, "h-w-medieval", "世界中古史", ["西欧封建社会", "拜占庭与东欧", "阿拉伯与伊斯兰世界", "中古亚洲与非洲", "中古晚期的西欧（文艺复兴、宗教改革、新航路）"])
        add(.history, "h-w-modern", "世界近代史", ["英国革命与启蒙运动", "美国独立与法国大革命", "工业革命与工人运动", "1848 年革命与民族统一", "亚非拉的殖民与反抗", "帝国主义与第一次世界大战前"])
        add(.history, "h-w-contemporary", "世界现代史", ["第一次世界大战与凡尔赛—华盛顿体系", "俄国革命与苏联建设", "1929 年危机与法西斯兴起", "第二次世界大战", "冷战与两极格局", "第三世界与全球化"])
        add(.politics, "p-mayuan", "马原", ["导论", "世界的物质性及发展规律", "实践与认识及其发展规律", "人类社会及其发展规律", "资本主义的本质及规律", "资本主义的发展及其趋势", "社会主义的发展及其规律", "共产主义崇高理想及其最终实现"])
        add(.politics, "p-mao", "毛中特", ["毛泽东思想", "邓小平理论、“三个代表”、科学发展观", "习近平新时代中国特色社会主义思想"])
        add(.politics, "p-shigang", "史纲", ["旧民主主义革命时期（1840—1919）", "新民主主义革命时期（1919—1949）", "社会主义革命和建设时期", "改革开放和社会主义现代化建设新时期", "中国特色社会主义新时代"])
        add(.politics, "p-sixiu", "思修法基", ["绪论", "人生观", "理想信念", "中国精神", "社会主义核心价值观", "道德", "法治"])
        add(.politics, "p-news", "时政", ["当年时政"])
        add(.english, "e-skill", "题型", ["单词", "阅读", "新题型", "翻译", "完形", "小作文", "大作文"])
        return result
    }
}

// MARK: - 每日汇总

struct DailyDigest: Codable, Identifiable, Equatable, Sendable {
    var id: String               // yyyy-MM-dd
    var day: Date
    var summary: String
    var tomorrow: [String]
    var weakPoints: [String]
    var changes: [String: Int]   // nodeID → 汇总后的掌握程度
    var createdAt: Date
    var eventCount: Int
    var seen = false
    var automatic = true
}

// MARK: - 记忆

enum MemoryCategory: String, Codable, CaseIterable, Sendable {
    case goals, weakPoints, habits, other
    var title: String {
        switch self { case .goals: return "目标与安排"; case .weakPoints: return "还不牢的地方"; case .habits: return "学习习惯"; case .other: return "其他" }
    }
}

struct MemoryItem: Codable, Identifiable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var text: String
    var category: MemoryCategory
    var source: String           // 「你写的」「10 月 4 日的汇总」
    var pinned = false
    var createdAt = Date()
    var updatedAt = Date()
}

enum StudyMemory {
    static let maxItems = 200
    /// 旧版「学习档案」一段文字 → 若干条记忆（原文仍保留在 personalMemory）。
    static func migrate(profile: String?) -> [MemoryItem] {
        let defaultText = "目标：考研复习。可在学习设置中编辑个人学习档案。"
        guard let profile, profile != defaultText else { return [] }
        return profile.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
            .prefix(50)
            .map { MemoryItem(text: String($0.prefix(200)), category: .other, source: "你写的") }
    }

    /// 发给 AI 的记忆上下文：置顶 → 还不牢 → 其余，总长度控制在 limit 字以内。
    static func context(items: [MemoryItem], limit: Int = 1200) -> String {
        let ordered = items.filter(\.pinned) + items.filter { !$0.pinned && $0.category == .weakPoints }.sorted { $0.updatedAt > $1.updatedAt }
            + items.filter { !$0.pinned && $0.category != .weakPoints }.sorted { $0.updatedAt > $1.updatedAt }
        var lines: [String] = [], used = 0
        for item in ordered {
            let line = "- [\(item.category.title)] \(item.text)"
            if used + line.count > limit { break }
            lines.append(line); used += line.count
        }
        return lines.joined(separator: "\n")
    }
}
