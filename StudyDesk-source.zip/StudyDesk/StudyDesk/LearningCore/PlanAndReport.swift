import Foundation

// MARK: - 今日计划

struct PlanItem: Codable, Identifiable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var text: String
    var done = false
    var origin: Origin = .mine
    enum Origin: String, Codable, Sendable { case mine, digest, carried }
}

struct DailyPlan: Codable, Identifiable, Equatable, Sendable {
    var id: String               // yyyy-MM-dd
    var items: [PlanItem]
}

enum DailyPlanner {
    static let keepDays = 21

    /// 今天的计划：已有就原样返回；没有就用昨天汇总的「明天做什么」，再接上最近一天没做完的事。
    static func plan(for day: Date, plans: [DailyPlan], digests: [DailyDigest], calendar: Calendar = .current) -> DailyPlan {
        let id = StudyDigest.id(for: day, calendar: calendar)
        if let existing = plans.first(where: { $0.id == id }) { return existing }
        var items: [PlanItem] = []
        if let yesterday = calendar.date(byAdding: .day, value: -1, to: day),
           let digest = digests.first(where: { $0.id == StudyDigest.id(for: yesterday, calendar: calendar) }) {
            items += digest.tomorrow.map { PlanItem(text: $0, origin: .digest) }
        }
        if let last = plans.filter({ $0.id < id }).max(by: { $0.id < $1.id }) {
            let seen = Set(items.map { HistoryDictionary.normalize($0.text) })
            items += last.items.filter { !$0.done && !seen.contains(HistoryDictionary.normalize($0.text)) }
                .prefix(3).map { PlanItem(text: $0.text, origin: .carried) }
        }
        return DailyPlan(id: id, items: items)
    }

    /// 写回计划列表，只保留最近几周
    static func store(_ plan: DailyPlan, in plans: inout [DailyPlan]) {
        if let i = plans.firstIndex(where: { $0.id == plan.id }) { plans[i] = plan } else { plans.append(plan) }
        plans.sort { $0.id < $1.id }
        if plans.count > keepDays { plans.removeFirst(plans.count - keepDays) }
    }
}

// MARK: - 周报

struct WeeklyReport: Equatable, Sendable {
    struct GroupStat: Equatable, Sendable { var group: String; var subject: StudySubject; var answered: Int; var wrong: Int
        var accuracy: Double { answered == 0 ? 0 : Double(answered - wrong) / Double(answered) } }
    struct WrongSample: Equatable, Sendable { var stem: String; var picked: String; var answer: String; var group: String }

    var weekStart: Date
    var weekEnd: Date
    var studyDays: Int
    var seconds: TimeInterval
    var subjectSeconds: [StudySubject: TimeInterval]
    var previousSeconds: TimeInterval
    var answered: Int
    var correct: Int
    var previousAnswered: Int
    var previousCorrect: Int
    var weakGroups: [GroupStat]
    var wrongSamples: [WrongSample]
    var essayCount: Int
    var essayRatio: Double?          // 平均得分率
    var essayWeakPoints: [String]
    var masteryChanges: Int
    var wordsReviewed: Int

    var accuracy: Double? { answered == 0 ? nil : Double(correct) / Double(answered) }
    var previousAccuracy: Double? { previousAnswered == 0 ? nil : Double(previousCorrect) / Double(previousAnswered) }

    /// 本周一 00:00 开始的那一周
    static func weekStart(for date: Date, calendar: Calendar = .current) -> Date {
        var cal = calendar; cal.firstWeekday = 2
        return cal.dateInterval(of: .weekOfYear, for: date)?.start ?? cal.startOfDay(for: date)
    }
    static func id(for weekStart: Date, calendar: Calendar = .current) -> String { "W" + StudyDigest.id(for: weekStart, calendar: calendar) }

    static func compute(weekStart: Date, events: [LearningEvent], attempts: [QuestionAttempt], questions: [StudyQuestion],
                        essays: [EssayTask], digests: [DailyDigest], calendar: Calendar = .current) -> WeeklyReport {
        let end = calendar.date(byAdding: .day, value: 7, to: weekStart)!
        let prevStart = calendar.date(byAdding: .day, value: -7, to: weekStart)!
        let days = (0..<7).compactMap { calendar.date(byAdding: .day, value: $0, to: weekStart) }

        var seconds: TimeInterval = 0, bySubject: [StudySubject: TimeInterval] = [:], studyDays = 0, words = 0
        for day in days {
            let summary = DailyStudySummary(events: events, day: day, calendar: calendar)
            seconds += summary.seconds
            for (s, t) in summary.subjects { bySubject[s, default: 0] += t }
            words += summary.reviewedWords + summary.newWords
            if summary.seconds > 0 || summary.answers > 0 || summary.reviewedWords + summary.newWords > 0 { studyDays += 1 }
        }
        let prevSeconds = (0..<7).compactMap { calendar.date(byAdding: .day, value: $0, to: prevStart) }
            .reduce(0) { $0 + DailyStudySummary(events: events, day: $1, calendar: calendar).seconds }

        let byID = Dictionary(questions.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })
        let week = attempts.filter { $0.date >= weekStart && $0.date < end }
        let prev = attempts.filter { $0.date >= prevStart && $0.date < weekStart }
        var groups: [String: GroupStat] = [:]
        for a in week {
            guard let q = byID[a.questionID] else { continue }
            var stat = groups[q.group] ?? GroupStat(group: q.group, subject: q.subject, answered: 0, wrong: 0)
            stat.answered += 1; if !a.correct { stat.wrong += 1 }
            groups[q.group] = stat
        }
        let weak = groups.values.filter { $0.wrong > 0 }
            .sorted { ($0.wrong, -$0.accuracy) > ($1.wrong, -$1.accuracy) }.prefix(5).map { $0 }
        func letters(_ list: [Int]) -> String { list.map { String(UnicodeScalar(65 + $0)!) }.joined(separator: "、") }
        var seenWrong = Set<String>()
        let samples = week.reversed().compactMap { a -> WrongSample? in
            guard !a.correct, let q = byID[a.questionID], seenWrong.insert(q.id).inserted else { return nil }
            return WrongSample(stem: String(q.stem.prefix(80)), picked: letters(a.selected), answer: letters(q.answers), group: q.group)
        }.prefix(15).map { $0 }

        let essayAttempts = essays.flatMap { task in task.attempts.filter { $0.date >= weekStart && $0.date < end }.map { (task.fullScore, $0) } }
        let ratio: Double? = essayAttempts.isEmpty ? nil : essayAttempts.map { $0.1.score / Double($0.0) }.reduce(0, +) / Double(essayAttempts.count)
        let changes = digests.filter { $0.day >= weekStart && $0.day < end }.reduce(0) { $0 + $1.changes.count }

        return WeeklyReport(weekStart: weekStart, weekEnd: end, studyDays: studyDays, seconds: seconds, subjectSeconds: bySubject,
                            previousSeconds: prevSeconds, answered: week.count, correct: week.filter(\.correct).count,
                            previousAnswered: prev.count, previousCorrect: prev.filter(\.correct).count,
                            weakGroups: weak, wrongSamples: samples, essayCount: essayAttempts.count, essayRatio: ratio,
                            essayWeakPoints: Array(essayAttempts.flatMap { $0.1.weakPoints }.prefix(8)),
                            masteryChanges: changes, wordsReviewed: words)
    }
}

/// AI 对一周的诊断，按周保存
struct WeeklyDiagnosis: Codable, Identifiable, Equatable, Sendable {
    struct ErrorType: Codable, Equatable, Sendable { var type: String; var detail: String }
    var id: String               // W2026-10-05
    var diagnosis: String
    var errorTypes: [ErrorType]
    var focus: [String]
    var createdAt = Date()
}

enum WeeklyReview {
    static let systemPrompt = """
    你是考研备考教练，学生考 313 历史学基础、英语一和政治，离初试大约还有几周到两个月。根据一周的学习数据做诊断，要具体、能落地，不要空泛鼓励，也不要制造焦虑。
    errorTypes：从错题和大题批改看，主要错在哪几类（如「史实记不牢」「概念混淆」「审题偏」「答题不成体系」「语法基础」），每类用一句话举本周的具体例子，最多 3 类；数据太少就少写。
    focus：下周最该做的 3 件事，每件写清楚做什么、做到什么程度。
    只输出 JSON，不要其他文字：
    {"diagnosis":"三四句总体判断","errorTypes":[{"type":"","detail":""}],"focus":["","",""]}
    """

    static func userMessage(_ r: WeeklyReport, examDays: Int?, calendar: Calendar = .current) -> String {
        func pct(_ v: Double?) -> String { v.map { "\(Int(($0 * 100).rounded()))%" } ?? "无" }
        func hours(_ s: TimeInterval) -> String { String(format: "%.1f 小时", s / 3600) }
        var lines = ["本周（\(StudyDigest.id(for: r.weekStart, calendar: calendar)) 起）："]
        if let examDays { lines.append("距初试 \(examDays) 天") }
        lines.append("学习 \(r.studyDays) 天，计时 \(hours(r.seconds))（上周 \(hours(r.previousSeconds))）")
        lines.append("各科：" + StudySubject.allCases.map { "\($0.title) \(hours(r.subjectSeconds[$0] ?? 0))" }.joined(separator: "，"))
        lines.append("选择题 \(r.answered) 道，正确率 \(pct(r.accuracy))（上周 \(pct(r.previousAccuracy))）；单词复习 \(r.wordsReviewed) 次；考纲掌握度变动 \(r.masteryChanges) 处")
        if !r.weakGroups.isEmpty {
            lines.append("错得最多的题组：")
            lines += r.weakGroups.map { "- \($0.group)：做 \($0.answered) 错 \($0.wrong)" }
        }
        if !r.wrongSamples.isEmpty {
            lines.append("本周错题（题干｜选了｜答案）：")
            lines += r.wrongSamples.map { "- \($0.stem)｜\($0.picked)｜\($0.answer)" }
        }
        lines.append("大题批改 \(r.essayCount) 次，平均得分率 \(pct(r.essayRatio))")
        if !r.essayWeakPoints.isEmpty { lines.append("批改指出的薄弱点：" + r.essayWeakPoints.joined(separator: "；")) }
        return lines.joined(separator: "\n")
    }

    static func parse(_ text: String, id: String, now: Date = Date()) throws -> WeeklyDiagnosis {
        struct Raw: Decodable { var diagnosis: String?; var errorTypes: [WeeklyDiagnosis.ErrorType]?; var focus: [String]? }
        guard let raw: Raw = EssayPractice.decodeJSON(text),
              let diagnosis = raw.diagnosis?.trimmingCharacters(in: .whitespacesAndNewlines), !diagnosis.isEmpty else {
            throw StudyFailure.message("AI 没有按格式返回诊断，再试一次。")
        }
        return WeeklyDiagnosis(id: id, diagnosis: diagnosis,
                               errorTypes: Array((raw.errorTypes ?? []).filter { !$0.type.isEmpty }.prefix(3)),
                               focus: Array((raw.focus ?? []).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.prefix(3)),
                               createdAt: now)
    }
}
