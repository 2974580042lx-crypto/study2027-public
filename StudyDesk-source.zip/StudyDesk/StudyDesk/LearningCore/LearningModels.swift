import Foundation
import FSRS

enum StudySubject: String, Codable, CaseIterable, Identifiable, Sendable {
    case english, politics, history
    var id: String { rawValue }
    var title: String { switch self { case .english: return "英语一"; case .politics: return "政治"; case .history: return "313 历史学" } }
    var symbol: String { switch self { case .english: return "a.book.closed"; case .politics: return "text.book.closed"; case .history: return "books.vertical" } }
}

struct StudyCard: Identifiable, Codable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var front: String
    var back: String
    var subject: StudySubject
    var deck: String
    var source: String
    var phonetic: String = ""
    var note: String = ""
    var due: Date = .distantPast
    var reviewedAt: Date?
    var intervalDays: Double = 0
    var reviews: Int = 0
    var lapses: Int = 0
    var memory: Card?
    var reviewLogs: [ReviewLog]?
    mutating func review(_ grade: RecallGrade, at now: Date) throws {
        // Keep the upstream FSRS memory state and logs intact in backups.
        let scheduler = FSRS(parameters: FSRSParameters(w: FSRSDefaults.defaultWv6, enableFuzz: false))
        let rating: Rating = grade == .again ? .again : grade == .hard ? .hard : grade == .easy ? .easy : .good
        let result = try scheduler.next(card: memory ?? Card(due: now), now: now, grade: rating)
        memory = result.card
        reviewLogs = (reviewLogs ?? []) + [result.log]
        due = result.card.due; reviewedAt = result.card.lastReview
        intervalDays = result.card.scheduledDays; reviews = result.card.reps; lapses = result.card.lapses
    }
}
enum RecallGrade: String, CaseIterable, Sendable { case again, hard, good, easy
    var title: String { switch self { case .again: return "忘了"; case .hard: return "费力"; case .good: return "记得"; case .easy: return "轻松" } }
}

struct StudyQuestion: Identifiable, Codable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var subject: StudySubject
    var group: String
    var stem: String
    var options: [String]
    var answers: [Int]
    var explanation: String
    var source: String
    var year: Int?
    var number: Int?
    var sourceURL: String?
    var answerVerification: String?
    var multiple: Bool { answers.count > 1 }
    func isCorrect(_ selected: Set<Int>) -> Bool { !selected.isEmpty && selected == Set(answers) }
    func validate() throws {
        guard !stem.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              (2...10).contains(options.count), !answers.isEmpty,
              Set(answers).count == answers.count, answers.allSatisfy({ options.indices.contains($0) }),
              !source.isEmpty else { throw StudyFailure.message("题目内容、答案序号或来源不完整。答案序号从 0 开始。") }
    }
}
struct QuestionAttempt: Identifiable, Codable, Sendable {
    var id = UUID()
    var questionID: String
    var selected: [Int]
    var correct: Bool
    var date = Date()
}
struct StudyResource: Identifiable, Codable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var title: String
    var subject: StudySubject
    var fileName: String?
    var text: String = ""
    var source: String = "个人导入"
    var url: String?
    var page: Int = 0
    var note: String = ""
    var createdAt = Date()
}
enum LearningEventKind: String, Codable, Sendable { case focus, newWord, reviewWord, newCard, reviewCard, question, note, material, assistant }
struct LearningEvent: Identifiable, Codable, Sendable {
    var id = UUID()
    var subject: StudySubject
    var kind: LearningEventKind
    var title: String
    var detail: String
    var start: Date
    var end: Date
    var referenceID: String?
    var correct: Bool?
    var manual = false
    var readingPassageID: String?
    var readingQuestionID: String?
    var readingAttemptID: UUID?
    var collectedCardID: String?
    func seconds(on day: Date, calendar: Calendar = .current) -> TimeInterval {
        guard kind == .focus, let interval = calendar.dateInterval(of: .day, for: day) else { return 0 }
        return max(0, min(end, interval.end).timeIntervalSince(max(start, interval.start)))
    }
    func isOn(_ day: Date, calendar: Calendar = .current) -> Bool {
        if kind == .focus { return seconds(on: day, calendar: calendar) > 0 }
        return calendar.isDate(start, inSameDayAs: day)
    }
}
struct FocusRun: Codable, Equatable, Sendable {
    var id = UUID()
    var subject: StudySubject
    var label: String
    var targetSeconds: TimeInterval?
    var elapsed: TimeInterval = 0
    var segmentStart: Date?
    var isRest: Bool = false
    func total(at now: Date) -> TimeInterval {
        let total = elapsed + (segmentStart.map { max(0, now.timeIntervalSince($0)) } ?? 0)
        return min(targetSeconds ?? .greatestFiniteMagnitude, total)
    }
    func effectiveEnd(at now: Date) -> Date? {
        guard let start = segmentStart else { return nil }
        return min(now, targetSeconds.map { start.addingTimeInterval(max(0, $0 - elapsed)) } ?? now)
    }
    var isPaused: Bool { segmentStart == nil }
}
struct StudyPreferences: Codable, Sendable {
    var examDate: Date = Calendar(identifier: .gregorian).date(from: DateComponents(year: 2026, month: 12, day: 19))!
    var dailyMinutes = 120
    var dailyWords = 20
    var focusMinutes = 25
    var restMinutes = 5
    var preferredSubject: StudySubject = .english
    var useSerif = true
    static func daysUntil(_ target: Date, from now: Date, calendar: Calendar = .current) -> Int {
        max(0, calendar.dateComponents([.day], from: calendar.startOfDay(for: now), to: calendar.startOfDay(for: target)).day ?? 0)
    }
}
struct StudySnapshot: Codable, Sendable {
    var version = 1
    var preferences = StudyPreferences()
    var cards: [StudyCard] = []
    var questions: [StudyQuestion] = []
    var attempts: [QuestionAttempt] = []
    var resources: [StudyResource] = []
    var events: [LearningEvent] = []
    var focus: FocusRun?
    var memoryEnabled: Bool? = true
    var personalMemory: String? = "目标：考研复习。可在学习设置中编辑个人学习档案。"
    var bundledContentRevision: Int?
    var readingPassages: [ReadingPassage]?
    var readingAttempts: [ReadingAttempt]?
    var readingWords: [ReadingWord]?
    func validate() throws {
        guard version == 1, cards.count <= 30000, questions.count <= 30000, resources.count <= 1000,
              events.count <= 300000, attempts.count <= 300000,
              Set(cards.map(\.id)).count == cards.count,
              Set(questions.map(\.id)).count == questions.count,
              Set(resources.map(\.id)).count == resources.count,
              Set(events.map(\.id)).count == events.count else { throw StudyFailure.message("学习数据格式不正确或数量过大。") }
        guard (1...1440).contains(preferences.dailyMinutes), (1...500).contains(preferences.dailyWords),
              (1...180).contains(preferences.focusMinutes), (1...60).contains(preferences.restMinutes) else {
            throw StudyFailure.message("学习目标或计时设置超出范围。")
        }
        for card in cards {
            guard !card.front.isEmpty, !card.back.isEmpty, card.reviews >= 0,
                  card.intervalDays.isFinite, card.intervalDays >= 0 else { throw StudyFailure.message("卡片格式不正确。") }
        }
        for q in questions { try q.validate() }
        for r in resources {
            if let file = r.fileName {
                guard file == URL(fileURLWithPath: file).lastPathComponent,
                      !file.contains(".."), !file.contains("\\"), !file.contains("/"), !file.isEmpty else {
                    throw StudyFailure.message("附件名称不合法。")
                }
            }
        }
        for e in events {
            guard e.end >= e.start, e.start.timeIntervalSince1970.isFinite, e.end.timeIntervalSince1970.isFinite else { throw StudyFailure.message("学习时间记录无效。") }
        }
        try validateReadings()
    }
    func encoded() throws -> Data {
        try validate(); let e = JSONEncoder(); e.dateEncodingStrategy = .iso8601
        return try e.encode(self)
    }
    static func decode(_ data: Data) throws -> Self {
        guard data.count <= 100 * 1024 * 1024 else { throw StudyFailure.message("记录文件过大。") }
        let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601
        let state = try d.decode(Self.self, from: data); try state.validate(); return state
    }
}
struct StudyBackup: Codable {
    var format = "study2027-backup"
    var version = 1
    var state: StudySnapshot
    var attachments: [String: Data]
}
struct DailyStudySummary {
    var seconds: TimeInterval = 0
    var newWords = 0
    var reviewedWords = 0
    var cardReviews = 0
    var answers = 0
    var correct = 0
    var readingsCompleted = 0
    var wordsCollected = 0
    var subjects: [StudySubject: TimeInterval] = [:]
    init(events: [LearningEvent], day: Date, calendar: Calendar = .current) {
        var readingIDs = Set<String>(), collectedIDs = Set<String>()
        for event in events where event.isOn(day, calendar: calendar) {
            if let id = event.readingPassageID, readingIDs.insert(id).inserted { readingsCompleted += 1 }
            if let id = event.collectedCardID, collectedIDs.insert(id).inserted { wordsCollected += 1 }
            let time = event.seconds(on: day, calendar: calendar)
            seconds += time; subjects[event.subject, default: 0] += time
            switch event.kind {
            case .newWord: newWords += 1
            case .reviewWord: reviewedWords += 1
            case .newCard, .reviewCard: cardReviews += 1
            case .question: answers += 1; if event.correct == true { correct += 1 }
            default: break
            }
        }
    }
}
enum StudyFailure: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}
