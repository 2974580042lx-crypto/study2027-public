import Foundation

/// 一组练习的做题进度：每题只看最近一次作答。全部由答题记录算出，不另存。
struct PracticeProgress: Equatable, Sendable {
    enum Mark: Equatable, Sendable { case unanswered, correct, wrong }
    var marks: [Mark]

    init(questionIDs: [String], attempts: [QuestionAttempt]) {
        let last = PracticeProgress.lastAttempts(attempts)
        marks = questionIDs.map { id in last[id].map { $0.correct ? .correct : .wrong } ?? .unanswered }
    }

    static func lastAttempts(_ attempts: [QuestionAttempt]) -> [String: QuestionAttempt] {
        var result: [String: QuestionAttempt] = [:]
        for a in attempts where result[a.questionID].map({ $0.date <= a.date }) ?? true { result[a.questionID] = a }
        return result
    }

    var answered: Int { marks.filter { $0 != .unanswered }.count }
    var correct: Int { marks.filter { $0 == .correct }.count }
    var wrongIndices: [Int] { marks.indices.filter { marks[$0] == .wrong } }
    /// 接着做：第一道没做过的题；全做过返回 nil
    var resumeIndex: Int? { marks.firstIndex(of: .unanswered) }
    /// 列表上的一句话，例如「已做 12 / 30 · 对 9」
    var summary: String {
        answered == 0 ? "\(marks.count) 题" : "已做 \(answered) / \(marks.count) · 对 \(correct)"
    }
}
