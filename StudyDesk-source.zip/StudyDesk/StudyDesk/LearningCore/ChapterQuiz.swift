import Foundation

/// 按考纲章节让 AI 出单选题。题目存进题库，做题记录、错题本和间隔重做与其他题完全一样。
enum ChapterQuiz {
    static let count = 5
    static let source = "AI 按考纲出题 · 答案和解析以教材为准"

    static func systemPrompt(_ subject: StudySubject) -> String {
        let role = subject == .politics
            ? "你是考研政治（思想政治理论，全国统考）的出题老师。根据给定章节出单项选择题，考查基本原理、基本观点和重要论断，难度接近考研政治单选题。"
            : "你是历史学考研（313 历史学基础，全国统考）的出题老师。根据给定章节出单项选择题，考查基础史实和理解，难度接近统考选择题。"
        return role + "\n" + rules
    }

    private static let rules = """
    要求：
    1. 每题 4 个选项，只有一个正确答案；干扰项要似是而非，但必须确定是错的。
    2. 只出内容清楚、没有争议的题；拿不准的知识点不要出。
    3. 题干可以用简短材料或情境，不要照抄参考材料的句子。
    4. 解析说明正确项为什么对、主要干扰项错在哪里，80 字以内。
    5. 不要和「已经出过的题」重复。
    只输出 JSON，不要其他文字：
    {"questions":[{"stem":"题干","options":["选项","选项","选项","选项"],"answer":"A","explanation":"解析"}]}
    """

    struct Input: Sendable {
        var block: String
        var title: String
        var reference: [String]
        var previousStems: [String]
        var weakPoints: [String]
    }

    static func group(block: String, title: String) -> String { "AI 出题 · \(block) · \(title)" }

    static func userMessage(_ input: Input) -> String {
        var lines = ["章节：\(input.block) · \(input.title)", "请出 \(count) 道单项选择题。"]
        if !input.reference.isEmpty {
            lines.append("\n参考材料（本节常见知识点，供你把握范围，可以超出但不要和它矛盾）：")
            lines += input.reference.prefix(30).map { "- " + $0 }
        }
        if !input.weakPoints.isEmpty {
            lines.append("\n这个学生最近的薄弱点（相关的可以多出一题）：")
            lines += input.weakPoints.prefix(5).map { "- " + $0 }
        }
        if !input.previousStems.isEmpty {
            lines.append("\n已经出过的题（不要重复）：")
            lines += input.previousStems.suffix(25).map { "- " + String($0.prefix(60)) }
        }
        return lines.joined(separator: "\n")
    }

    static func parse(_ text: String, subject: StudySubject = .history, group: String, idPrefix: String) throws -> [StudyQuestion] {
        struct Raw: Decodable { var stem: String?; var options: [String]?; var answer: String?; var explanation: String? }
        struct File: Decodable { var questions: [Raw] }
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}"), start < end,
              let file = try? JSONDecoder().decode(File.self, from: Data(text[start...end].utf8)) else {
            throw StudyFailure.message("AI 没有按格式返回题目，再试一次。")
        }
        var result: [StudyQuestion] = []
        for raw in file.questions {
            let stem = raw.stem?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let options = (raw.options ?? []).map { stripLetter($0) }.filter { !$0.isEmpty }
            let letter = raw.answer?.trimmingCharacters(in: .whitespacesAndNewlines).uppercased().first
            guard !stem.isEmpty, options.count == 4, Set(options).count == 4,
                  let letter, let scalar = letter.unicodeScalars.first,
                  (65...68).contains(scalar.value) else { continue }
            let q = StudyQuestion(id: "\(idPrefix)-\(UUID().uuidString.prefix(8))", subject: subject, group: group,
                                  stem: stem, options: options, answers: [Int(scalar.value) - 65],
                                  explanation: raw.explanation?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "",
                                  source: source)
            guard (try? q.validate()) != nil else { continue }
            result.append(q)
        }
        guard !result.isEmpty else { throw StudyFailure.message("这次的题格式不对，没有可用的题，再试一次。") }
        return Array(result.prefix(count))
    }

    /// 去掉 AI 自带的「A. 」「B、」前缀，界面会自己加字母
    static func stripLetter(_ option: String) -> String {
        var s = option.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.count > 2, let first = s.first, "ABCDabcd".contains(first) {
            let second = s[s.index(after: s.startIndex)]
            if ".．、:：)） ".contains(second) { s = String(s.dropFirst(2)).trimmingCharacters(in: .whitespaces) }
        }
        return s
    }
}
