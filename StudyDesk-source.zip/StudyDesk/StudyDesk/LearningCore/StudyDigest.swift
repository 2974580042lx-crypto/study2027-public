import Foundation

/// AI 汇总某一天：组装请求、解析返回、把结果写回学习记录。不依赖界面，便于测试。
enum StudyDigest {
    static let systemPrompt = """
    你是考研学习记录的整理助手。用户在备考：313 历史学基础、思想政治理论、英语一。
    你会收到某一天的学习记录、考纲章节列表（含当前掌握程度 0–4）和已有的长期记忆。
    请只输出一个 JSON 对象，不要输出任何其他文字，格式：
    {"summary":"两三句话的总结，语气平和",
     "progress":[{"nodeID":"章节ID","mastery":2}],
     "weakPoints":["记录里明确提到的卡住、写不出、做错的地方，一条一句话"],
     "tomorrow":["明天可以先做的事，最多 3 条，每条一句话"],
     "memories":{"add":[{"text":"值得长期记住的一句话","category":"weakPoints"}],"remove":["已有记忆ID"]}}
    规则：
    - 只根据给出的记录判断，不猜测没有记录的学习。
    - nodeID 只能从给出的章节列表里选；对不上章节的内容不要放进 progress。
    - 掌握程度保守估计：0 没学、1 有点印象、2 还不牢、3 基本掌握、4 熟练。只说「看完了」最多给 2；写明默写顺利或选择题全对才给 3；不要因为一天的记录给 4。没有新信息的章节不要列出。
    - category 只能是 goals、weakPoints、habits、other。只记长期有用的事，一天最多新增 3 条；某个还不牢的地方已经掌握时，在 remove 里删掉对应记忆。
    - 不使用「落后」「必须」「来不及」这类词，不制造焦虑。
    """

    struct Input: Sendable {
        var day: Date
        var events: [LearningEvent]
        var nodes: [SyllabusNode]
        var memories: [MemoryItem]
        var examDate: Date?
    }

    static func id(for day: Date, calendar: Calendar = .current) -> String {
        let c = calendar.dateComponents([.year, .month, .day], from: day)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    /// 这一天值得汇总的记录（AI 讲解只算一条标题，不带内容）。
    static func relevantEvents(_ events: [LearningEvent], day: Date, calendar: Calendar = .current) -> [LearningEvent] {
        events.filter { $0.isOn(day, calendar: calendar) }.sorted { $0.start < $1.start }
    }

    static func userMessage(_ input: Input, calendar: Calendar = .current) -> String {
        let time = DateFormatter(); time.calendar = calendar; time.timeZone = calendar.timeZone; time.dateFormat = "HH:mm"
        var lines: [String] = []
        lines.append("日期：\(id(for: input.day, calendar: calendar))")
        if let exam = input.examDate {
            let days = calendar.dateComponents([.day], from: calendar.startOfDay(for: input.day), to: calendar.startOfDay(for: exam)).day ?? 0
            lines.append("距初试：\(max(0, days)) 天")
        }
        lines.append("\n【学习记录】")
        let events = relevantEvents(input.events, day: input.day, calendar: calendar)
        // 背词、做题这类单条很多，按科目和类型合并成一行，避免请求过长
        var counted: [String: (count: Int, correct: Int)] = [:]
        for e in events {
            switch e.kind {
            case .newWord, .reviewWord, .newCard, .reviewCard, .question:
                let key = "\(e.subject.title)·\(kindTitle(e.kind))"
                var v = counted[key] ?? (0, 0); v.count += 1; if e.correct == true { v.correct += 1 }; counted[key] = v
            default:
                let minutes = Int(e.end.timeIntervalSince(e.start) / 60)
                let length = minutes > 0 ? "，\(minutes) 分钟" : ""
                let text = e.kind == .note || e.manual ? e.detail : e.title
                lines.append("\(time.string(from: e.start)) \(e.subject.title)·\(kindTitle(e.kind))\(length)：\(String(text.prefix(200)))")
            }
        }
        for (key, v) in counted.sorted(by: { $0.key < $1.key }) {
            lines.append(key.hasSuffix("做题") ? "\(key)：\(v.count) 道，答对 \(v.correct) 道" : "\(key)：\(v.count) 个")
        }
        if events.isEmpty { lines.append("（无）") }
        lines.append("\n【考纲章节】ID｜科目｜板块｜章节｜当前掌握")
        for n in input.nodes.sorted(by: { $0.order < $1.order }) {
            lines.append("\(n.id)｜\(n.subject.title)｜\(n.block)｜\(n.title)｜\(n.mastery)")
        }
        if !input.memories.isEmpty {
            lines.append("\n【已有记忆】ID｜分类｜内容")
            for m in input.memories.prefix(60) { lines.append("\(m.id)｜\(m.category.rawValue)｜\(m.text)") }
        }
        return lines.joined(separator: "\n")
    }

    private static func kindTitle(_ kind: LearningEventKind) -> String {
        switch kind {
        case .focus: return "学习"; case .note: return "笔记"; case .newWord: return "新词"; case .reviewWord: return "复习单词"
        case .newCard: return "新卡片"; case .reviewCard: return "复习卡片"; case .question: return "做题"; case .material: return "资料"
        case .assistant: return "问 AI"; case .essay: return "大题"
        }
    }

    // MARK: 解析

    struct Result: Equatable, Sendable {
        struct Progress: Equatable, Sendable { var nodeID: String; var mastery: Int }
        struct NewMemory: Equatable, Sendable { var text: String; var category: MemoryCategory }
        var summary: String
        var progress: [Progress]
        var weakPoints: [String]
        var tomorrow: [String]
        var addMemories: [NewMemory]
        var removeMemories: [String]
    }

    private struct Raw: Decodable {
        struct P: Decodable { var nodeID: String?; var mastery: Int? }
        struct M: Decodable { var text: String?; var category: String? }
        struct Ms: Decodable { var add: [M]?; var remove: [String]? }
        var summary: String?; var progress: [P]?; var weakPoints: [String]?; var tomorrow: [String]?; var memories: Ms?
    }

    enum ParseError: LocalizedError, Equatable {
        case noJSON, empty
        var errorDescription: String? { self == .noJSON ? "AI 没有按格式返回汇总。" : "AI 返回的汇总是空的。" }
    }

    /// 容忍 ```json 包裹和前后多余文字。
    static func parse(_ text: String) throws -> Result {
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}"), start < end,
              let data = String(text[start...end]).data(using: .utf8),
              let raw = try? JSONDecoder().decode(Raw.self, from: data) else { throw ParseError.noJSON }
        let summary = (raw.summary ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard !summary.isEmpty else { throw ParseError.empty }
        func clean(_ list: [String]?, max: Int) -> [String] {
            (list ?? []).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.prefix(max).map { String($0.prefix(200)) }
        }
        return Result(
            summary: String(summary.prefix(600)),
            progress: (raw.progress ?? []).compactMap { p in
                guard let id = p.nodeID, let m = p.mastery else { return nil }
                return Result.Progress(nodeID: id, mastery: max(0, min(4, m)))
            },
            weakPoints: clean(raw.weakPoints, max: 8),
            tomorrow: clean(raw.tomorrow, max: 3),
            addMemories: (raw.memories?.add ?? []).prefix(3).compactMap { m in
                guard let text = m.text?.trimmingCharacters(in: .whitespacesAndNewlines), !text.isEmpty else { return nil }
                return Result.NewMemory(text: String(text.prefix(200)), category: MemoryCategory(rawValue: m.category ?? "") ?? .other)
            },
            removeMemories: raw.memories?.remove ?? [])
    }

    // MARK: 写回

    /// 把汇总结果写进快照：更新章节掌握度、增删记忆、保存当天的日报。返回实际改动的章节数。
    @discardableResult
    static func apply(_ result: Result, to state: inout StudySnapshot, day: Date, eventCount: Int, automatic: Bool,
                      now: Date = Date(), calendar: Calendar = .current) -> Int {
        var nodes = state.syllabus ?? SyllabusSeed.nodes()
        var changes: [String: Int] = [:]
        for p in result.progress {
            guard let i = nodes.firstIndex(where: { $0.id == p.nodeID }) else { continue }
            nodes[i].setMastery(p.mastery, at: day, calendar: calendar)
            changes[p.nodeID] = nodes[i].mastery
        }
        state.syllabus = nodes

        var memories = state.memories ?? []
        let removable = Set(result.removeMemories)
        memories.removeAll { removable.contains($0.id) && !$0.pinned }
        let label = "\(calendar.component(.month, from: day)) 月 \(calendar.component(.day, from: day)) 日的汇总"
        for m in result.addMemories where !memories.contains(where: { $0.text == m.text }) {
            memories.append(MemoryItem(text: m.text, category: m.category, source: label, createdAt: now, updatedAt: now))
        }
        if memories.count > StudyMemory.maxItems { memories = Array(memories.suffix(StudyMemory.maxItems)) }
        state.memories = memories

        var digests = state.digests ?? []
        let key = id(for: day, calendar: calendar)
        digests.removeAll { $0.id == key }
        digests.append(DailyDigest(id: key, day: calendar.startOfDay(for: day), summary: result.summary, tomorrow: result.tomorrow,
                                   weakPoints: result.weakPoints, changes: changes, createdAt: now, eventCount: eventCount,
                                   seen: !automatic, automatic: automatic))
        state.digests = Array(digests.sorted { $0.day < $1.day }.suffix(120))
        return changes.count
    }

    /// 需要自动补汇总的日子：最近 7 天（不含今天）里有记录、还没汇总过的，从早到晚。
    static func pendingDays(events: [LearningEvent], digests: [DailyDigest], now: Date = Date(), calendar: Calendar = .current) -> [Date] {
        let today = calendar.startOfDay(for: now)
        let done = Set(digests.map(\.id))
        return (1...7).reversed().compactMap { offset -> Date? in
            guard let day = calendar.date(byAdding: .day, value: -offset, to: today) else { return nil }
            guard !done.contains(id(for: day, calendar: calendar)) else { return nil }
            return events.contains { $0.isOn(day, calendar: calendar) && $0.kind != .assistant } ? day : nil
        }
    }
}
