import Foundation

// MARK: - 主观题（313 论述 / 材料、政治分析题、英语作文）

enum EssayKind: String, Codable, CaseIterable, Sendable {
    case historyEssay, historyMaterial, politicsAnalysis, englishLarge, englishSmall

    var subject: StudySubject {
        switch self {
        case .historyEssay, .historyMaterial: .history
        case .politicsAnalysis: .politics
        case .englishLarge, .englishSmall: .english
        }
    }
    var title: String {
        switch self {
        case .historyEssay: "论述题"
        case .historyMaterial: "材料分析题"
        case .politicsAnalysis: "政治分析题"
        case .englishLarge: "英语大作文"
        case .englishSmall: "英语小作文"
        }
    }
    var fullScore: Int {
        switch self {
        case .historyEssay: 40
        case .historyMaterial: 30
        case .politicsAnalysis: 10
        case .englishLarge: 20
        case .englishSmall: 10
        }
    }
    var isEnglish: Bool { subject == .english }
    static func kinds(for subject: StudySubject) -> [EssayKind] { allCases.filter { $0.subject == subject } }
}

struct EssayPoint: Codable, Equatable, Sendable {
    enum Hit: String, Codable, Sendable { case full, partial, miss }
    var point: String
    var hit: Hit
    var comment: String
}

struct EssayCorrection: Codable, Equatable, Sendable {
    var original: String
    var better: String
    var reason: String
}

struct EssayAttempt: Codable, Identifiable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var text: String
    var date = Date()
    var score: Double
    var points: [EssayPoint]
    var summary: String
    var improvements: [String]
    var corrections: [EssayCorrection]
    var weakPoints: [String]
}

struct EssayTask: Codable, Identifiable, Equatable, Sendable {
    var id: String = UUID().uuidString
    var kind: EssayKind
    var nodeID: String?
    var topicID: String?
    var scope: String            // 「中国古代史 · 秦汉」或专题名
    var title: String
    var prompt: String           // 题目，材料题包含材料
    var createdAt = Date()
    var attempts: [EssayAttempt] = []
    var draft: String?
    /// 题包导入的历年真题
    var real: Bool?
    var year: Int?
    /// 这道题自己的满分（早年 313 简答题每题 30 分）；没有就按题型
    var score: Int?
    /// 例如「材料原文缺，只有题意」
    var note: String?

    var fullScore: Int { score ?? kind.fullScore }
    var isReal: Bool { real == true }

    var best: EssayAttempt? { attempts.max { $0.score < $1.score } }
    var latest: EssayAttempt? { attempts.last }
}

enum EssayPractice {
    static let source = "AI 出题与批改 · 得分点和分数仅供参考"

    // MARK: 出题

    static func generateSystemPrompt(_ kind: EssayKind) -> String {
        let task: String
        switch kind {
        case .historyEssay:
            task = "出一道 313 历史学基础（全国统考）风格的论述题，满分 30 分。题目要有分析空间，可以贯通几个时期或比较中外，不要只考单个史实的复述。"
        case .historyMaterial:
            task = "出一道 313 历史学基础（全国统考）风格的材料分析题，满分 20 分。先给一段 150—300 字的材料（可以是对史料的忠实转述或概括，不要伪造原文出处），再提 2—3 个设问，标出每问分值。"
        case .politicsAnalysis:
            task = "出一道考研政治（全国统考）风格的分析题，满分 10 分。先给简短材料，再提 1—2 个设问，考查原理运用或理论观点。"
        case .englishLarge:
            task = "出一道考研英语一大作文题（图画或图表作文，用文字描述图画或数据），满分 20 分，要求 160—200 词。"
        case .englishSmall:
            task = "出一道考研英语一小作文题（书信、通知、倡议等应用文），满分 10 分，约 100 词。"
        }
        return """
        你是考研阅卷经验丰富的老师。\(task)
        内容必须准确、没有争议，不要编造不存在的史料出处或数据来源。
        如果给了「真题样例」，命题范围、设问方式和难度都要照着样例来；313 题目不超出全国硕士研究生招生考试历史学基础考试大纲的范围。
        只输出 JSON，不要其他文字：
        {"title":"十字以内的短标题","prompt":"完整题目（材料题含材料和设问）"}
        """
    }

    static func generateUserMessage(kind: EssayKind, scope: String, reference: [String], weakPoints: [String], previousTitles: [String],
                                    examples: [EssayTask] = []) -> String {
        var lines = ["题型：\(kind.title)", "范围：\(scope)"]
        if !examples.isEmpty {
            lines.append("\n真题样例（照着它们的范围、设问方式和难度出一道新题，不要和样例重复）：")
            lines += examples.map { "- \($0.year.map { "\($0) 年：" } ?? "")\(String($0.prompt.prefix(240)).replacingOccurrences(of: "\n", with: " "))" }
        }
        if !reference.isEmpty {
            lines.append("\n范围内的知识点（把握方向用，可以超出）：")
            lines += reference.prefix(30).map { "- " + $0 }
        }
        if !weakPoints.isEmpty {
            lines.append("\n这个学生的薄弱点（合适的话往这里出）：")
            lines += weakPoints.prefix(5).map { "- " + $0 }
        }
        if !previousTitles.isEmpty {
            lines.append("\n出过的题（不要重复）：")
            lines += previousTitles.suffix(15).map { "- " + $0 }
        }
        return lines.joined(separator: "\n")
    }

    static func parseTask(_ text: String, kind: EssayKind, scope: String, nodeID: String?, topicID: String?) throws -> EssayTask {
        struct Raw: Decodable { var title: String?; var prompt: String? }
        guard let raw: Raw = decodeJSON(text),
              let prompt = raw.prompt?.trimmingCharacters(in: .whitespacesAndNewlines), prompt.count >= 8 else {
            throw StudyFailure.message("AI 没有按格式出题，再试一次。")
        }
        let title = raw.title?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return EssayTask(kind: kind, nodeID: nodeID, topicID: topicID, scope: scope,
                         title: String((title.isEmpty ? String(prompt.prefix(16)) : title).prefix(30)), prompt: prompt)
    }

    // MARK: 批改

    static func gradeSystemPrompt(_ kind: EssayKind, fullScore: Int? = nil) -> String {
        let full = fullScore ?? kind.fullScore
        let standard: String
        if kind.isEnglish {
            standard = """
            按考研英语一作文评分标准评分（满分 \(full)）：先判断档次，再在档内给分。得分点按「任务完成、内容要点、结构连贯、语言准确与多样」逐项列出。
            corrections 挑 3—6 处最值得改的句子（语法错误、中式表达、可以升级的表达），original 必须是原文里的原句或片段。
            """
        } else {
            standard = """
            按考研阅卷方式评分（满分 \(full)）：先列出这道题的参考得分点（一般 4—8 个，每个写清楚要答出什么、大致分值），再逐个判断学生答案踩中（full）、部分踩中（partial）还是没答（miss），按点给分；再看论证逻辑、史实准确、结构层次，适当增减。
            史实错误要在对应得分点的 comment 里指出。不要因为字数多就给高分。corrections 留空数组。
            """
        }
        return """
        你是严格但讲道理的考研阅卷老师。\(standard)
        summary：两三句总评，先说最主要的问题。improvements：最多 4 条具体改进建议，说怎么改而不是空话。
        weakPoints：从这次作答里看出的知识或能力薄弱点，最多 3 条，每条 20 字以内，写成以后能复习的样子（如「明朝内阁与宰相的区别说不清」）。
        只输出 JSON，不要其他文字：
        {"score":0,"points":[{"point":"得分点（分值）","hit":"full","comment":"简评"}],"summary":"","improvements":[""],"corrections":[{"original":"","better":"","reason":""}],"weakPoints":[""]}
        """
    }

    static func gradeUserMessage(task: EssayTask, answer: String, previous: EssayAttempt?) -> String {
        var lines = ["题型：\(task.kind.title)（满分 \(task.fullScore)）", "题目：", task.prompt, "", "学生答案：", answer]
        if let previous {
            lines += ["", "这是重写。上次得分 \(formatScore(previous.score))，上次的主要问题：\(previous.summary)", "请评价这次有没有改进。"]
        }
        return lines.joined(separator: "\n")
    }

    static func parseGrade(_ text: String, kind: EssayKind, fullScore: Int? = nil, answer: String, now: Date = Date()) throws -> EssayAttempt {
        struct RawPoint: Decodable { var point: String?; var hit: String?; var comment: String? }
        struct RawFix: Decodable { var original: String?; var better: String?; var reason: String? }
        struct Raw: Decodable {
            var score: Double?; var points: [RawPoint]?; var summary: String?
            var improvements: [String]?; var corrections: [RawFix]?; var weakPoints: [String]?
        }
        guard let raw: Raw = decodeJSON(text), let score = raw.score, score.isFinite else {
            throw StudyFailure.message("AI 没有按格式批改，再试一次。")
        }
        func clean(_ list: [String]?, _ limit: Int) -> [String] {
            (list ?? []).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.prefix(limit).map { $0 }
        }
        let points = (raw.points ?? []).compactMap { p -> EssayPoint? in
            guard let point = p.point?.trimmingCharacters(in: .whitespacesAndNewlines), !point.isEmpty else { return nil }
            return EssayPoint(point: point, hit: EssayPoint.Hit(rawValue: p.hit ?? "") ?? .miss, comment: p.comment ?? "")
        }
        let corrections = (raw.corrections ?? []).compactMap { c -> EssayCorrection? in
            guard let o = c.original?.trimmingCharacters(in: .whitespacesAndNewlines), let b = c.better?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !o.isEmpty, !b.isEmpty, o != b else { return nil }
            return EssayCorrection(original: o, better: b, reason: c.reason ?? "")
        }
        let rounded = (min(max(score, 0), Double(fullScore ?? kind.fullScore)) * 2).rounded() / 2
        return EssayAttempt(text: answer, date: now, score: rounded, points: points,
                            summary: raw.summary?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "",
                            improvements: clean(raw.improvements, 4), corrections: kind.isEnglish ? Array(corrections.prefix(6)) : [],
                            weakPoints: clean(raw.weakPoints, 3).map { String($0.prefix(40)) })
    }

    /// 批改出的薄弱点并入长期记忆；已有相同内容的不重复加
    static func mergeWeakPoints(_ points: [String], into memories: inout [MemoryItem], scope: String, now: Date = Date()) -> Int {
        var added = 0
        for p in points {
            let key = HistoryDictionary.normalize(p)
            guard !key.isEmpty, !memories.contains(where: { HistoryDictionary.normalize($0.text) == key }) else { continue }
            memories.append(MemoryItem(text: p, category: .weakPoints, source: "大题批改 · \(scope)", createdAt: now, updatedAt: now))
            added += 1
        }
        return added
    }

    /// 给出题挑真题样例：同题型，按和范围、词条的重合程度排序，最多 3 道
    static func pickExamples(from tasks: [EssayTask], kind: EssayKind, scope: String, terms: [String], limit: Int = 3) -> [EssayTask] {
        let pool = tasks.filter { $0.isReal && $0.kind == kind && $0.note == nil }
        let keys = Array(Set(terms.filter { $0.count >= 2 } + scopeKeys(scope)))
        let ranked = pool.map { t in (t, keys.filter { t.prompt.contains($0) }.count) }
            .sorted { $0.1 != $1.1 ? $0.1 > $1.1 : ($0.0.year ?? 0) > ($1.0.year ?? 0) }
        return Array(ranked.prefix(limit).map { $0.0 })
    }
    private static func scopeKeys(_ scope: String) -> [String] {
        scope.components(separatedBy: CharacterSet(charactersIn: " ·、，（）()—")).filter { $0.count >= 2 && $0.count <= 8 }
    }

    static func formatScore(_ score: Double) -> String {
        score == score.rounded() ? String(Int(score)) : String(format: "%.1f", score)
    }

    static func decodeJSON<T: Decodable>(_ text: String) -> T? {
        guard let start = text.firstIndex(of: "{"), let end = text.lastIndex(of: "}"), start < end else { return nil }
        return try? JSONDecoder().decode(T.self, from: Data(text[start...end].utf8))
    }
}
