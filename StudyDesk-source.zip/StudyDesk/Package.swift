// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "DeepSeekCore",
    platforms: [.macOS(.v13)],
    products: [.library(name: "DeepSeekCore", targets: ["DeepSeekCore"])],
    dependencies: [
        .package(url: "https://github.com/open-spaced-repetition/swift-fsrs.git", revision: "4fbaf20184d62f82a9f44f343337c61a2c5483e9"),
        .package(url: "https://github.com/swiftcsv/SwiftCSV.git", revision: "324d583f2e6eb587c62bcd8574693d5c4f9b6eff"),
        .package(url: "https://github.com/vapor/jwt-kit.git", revision: "13e7513b3ba0afa13967daf77af2fb4ad087306c")
    ],
    targets: [
        .target(name: "DeepSeekCore", dependencies: [.product(name: "FSRS", package: "swift-fsrs"), .product(name: "SwiftCSV", package: "swiftcsv"), .product(name: "JWTKit", package: "jwt-kit")], path: "StudyDesk",
                exclude: ["AppStore.swift", "StudyDeskApp.swift", "Info.plist", "Views", "LearningUI", "Assets.xcassets", "Resources", "Services/AppPersistence.swift", "Services/KeychainStore.swift", "Services/SubscriptionStore.swift"],
                sources: ["Core", "LearningCore", "Services/DeepSeekClient.swift", "Services/SubscriptionHTTP.swift", "Services/SubscriptionLoopback.swift"]),
        .testTarget(name: "DeepSeekCoreTests", dependencies: ["DeepSeekCore"], path: "Tests")
    ]
)
