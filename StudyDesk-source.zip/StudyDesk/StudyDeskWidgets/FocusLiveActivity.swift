import ActivityKit
import SwiftUI
import WidgetKit

/// 灵动岛与锁屏上的学习计时。数字由系统自己走，不需要 App 每秒更新。
struct FocusLiveActivity: Widget {
    private static let seal = Color(red: 0.722, green: 0.227, blue: 0.149)   // 朱红 #B83A26

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: StudyFocusAttributes.self) { context in
            LockScreenFocusView(context: context)
                .activityBackgroundTint(nil)
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 6) {
                        sealMark(size: 22)
                        Text(context.attributes.subject).font(.system(size: 14, design: .serif))
                    }.padding(.leading, 4)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text(context.state.isPaused ? "已暂停" : (context.attributes.isRest ? "休息中" : "学习中"))
                        .font(.system(size: 13, design: .serif)).foregroundStyle(.secondary).padding(.trailing, 4)
                }
                DynamicIslandExpandedRegion(.bottom) {
                    VStack(spacing: 6) {
                        clock(context.state, size: 40)
                        Text(context.attributes.label).font(.system(size: 15, design: .serif)).lineLimit(1).foregroundStyle(.secondary)
                    }.padding(.bottom, 4)
                }
            } compactLeading: {
                sealMark(size: 18)
            } compactTrailing: {
                clock(context.state, size: 14).frame(maxWidth: 58)
            } minimal: {
                sealMark(size: 16)
            }
            .keylineTint(Self.seal)
        }
    }

    private func sealMark(size: CGFloat) -> some View {
        Text("研").font(.system(size: size * 0.6, weight: .semibold, design: .serif)).foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(Self.seal, in: RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
    }

    private func clock(_ state: StudyFocusAttributes.ContentState, size: CGFloat) -> some View {
        FocusClock(state: state, size: size)
    }
}

private struct LockScreenFocusView: View {
    let context: ActivityViewContext<StudyFocusAttributes>
    private static let seal = Color(red: 0.722, green: 0.227, blue: 0.149)
    var body: some View {
        HStack(alignment: .center, spacing: 14) {
            Text("研").font(.system(size: 18, weight: .semibold, design: .serif)).foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Self.seal, in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text("\(context.attributes.subject) · \(context.state.isPaused ? "已暂停" : (context.attributes.isRest ? "休息中" : "学习中"))")
                    .font(.system(size: 13, design: .serif)).foregroundStyle(.secondary)
                Text(context.attributes.label).font(.system(size: 16, design: .serif)).lineLimit(1)
                Text("今天累计 " + Duration.seconds(context.state.todaySeconds).formatted(.time(pattern: .hourMinute)) + (context.state.targetSeconds == nil ? " · 暂停不计入" : ""))
                    .font(.system(size: 11, design: .serif)).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            FocusClock(state: context.state, size: 30)
        }
        .padding(16)
    }
}

/// 计时数字：计时中由系统自动走；暂停时显示固定时间。
private struct FocusClock: View {
    let state: StudyFocusAttributes.ContentState
    let size: CGFloat
    var body: some View {
        if !state.isPaused, let from = state.countingFrom {
            if let target = state.targetSeconds {
                let end = from.addingTimeInterval(target)
                Text(timerInterval: min(Date(), end)...end, countsDown: true)
                    .font(.system(size: size, weight: .medium)).monospacedDigit().multilineTextAlignment(.center)
            } else {
                Text(from, style: .timer)
                    .font(.system(size: size, weight: .medium)).monospacedDigit().multilineTextAlignment(.center)
            }
        } else {
            Text(Duration.seconds(state.pausedSeconds).formatted(.time(pattern: state.pausedSeconds >= 3600 ? .hourMinuteSecond : .minuteSecond)))
                .font(.system(size: size, weight: .medium)).monospacedDigit().foregroundStyle(.secondary)
        }
    }
}
