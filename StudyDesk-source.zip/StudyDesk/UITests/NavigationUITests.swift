import XCTest
final class NavigationUITests: XCTestCase {
    @MainActor func testReadingSubmitAndResume() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-english"], in: app); app.buttons["subject-english"].tap()
        app.buttons["english-reading-library"].tap(); app.buttons["reading-reading-feature-example"].tap()
        XCTAssertTrue(app.textViews["reading-paragraph-0"].waitForExistence(timeout: 5))
        capture("10-english-reading")
        app.buttons["reading-jump-questions"].tap()
        for (number, choice) in [(21,0),(22,1),(23,2),(24,3),(25,0)] {
            let option = app.buttons["reading-option-\(number)-\(choice)"]
            reveal(option, in: app); option.tap()
        }
        app.buttons["reading-submit"].tap()
        XCTAssertTrue(app.staticTexts["reading-score"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["reading-score"].label.contains("5/5"))
        capture("11-reading-score")
        app.navigationBars.buttons["英语阅读"].tap()
        app.buttons["reading-reading-feature-example"].tap(); app.buttons["reading-jump-questions"].tap()
        XCTAssertTrue(app.staticTexts["reading-score"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["reading-submit"].exists)
    }
    @MainActor func testReadingSelectionAndWordCollection() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-english"], in: app); app.buttons["subject-english"].tap()
        app.buttons["english-reading-library"].tap(); app.buttons["reading-reading-feature-example"].tap()
        let text = app.textViews["reading-paragraph-0"]
        XCTAssertTrue(text.waitForExistence(timeout: 5))
        text.coordinate(withNormalizedOffset: CGVector(dx: 0.24, dy: 0.15)).press(forDuration: 1.2)
        let collect = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "加入生词本")).firstMatch
        XCTAssertTrue(collect.waitForExistence(timeout: 5))
        capture("12-reading-selection")
        app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "问 AI")).firstMatch.tap()
        XCTAssertTrue(app.staticTexts["study-selected-quote"].waitForExistence(timeout: 5)); app.buttons["完成"].tap()
        app.buttons["阅读操作"].tap(); app.buttons["收录生词"].tap()
        app.textFields["reading-word-term"].tap(); app.textFields["reading-word-term"].typeText("record")
        app.buttons["reading-word-save"].tap()
        app.buttons["阅读操作"].tap(); app.buttons["打开生词本"].tap()
        XCTAssertTrue(app.buttons["reading-collected-record"].waitForExistence(timeout: 5))
        capture("13-reading-vocabulary")
    }
    @MainActor func testSubscriptionSettingsKeepLoginSeparateFromPaidAPI() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        app.buttons["打开侧栏"].tap()
        app.buttons["学习设置"].tap()
        app.buttons["AI 连接、系统提示词与聊天设置"].tap()
        let picker = app.buttons["ai-provider-picker"]
        XCTAssertTrue(picker.waitForExistence(timeout: 5)); picker.tap()
        app.buttons["ChatGPT 订阅"].tap()
        XCTAssertTrue(app.buttons["subscription-sign-in"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.secureTextFields["粘贴 DeepSeek API Key"].exists)
        XCTAssertFalse(app.buttons["subscription-test"].exists)
        capture("08-subscription-settings")
        app.buttons["保存"].tap()
        app.buttons["完成"].tap()
        XCTAssertTrue(app.staticTexts["exam-countdown"].waitForExistence(timeout: 5))
    }
    @MainActor func testSystemAuthenticationReturnsThroughDeviceLoopback() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview", "--subscription-loopback-smoke"]; app.launch()
        addUIInterruptionMonitor(withDescription: "System authentication consent") { alert in
            for title in ["继续", "Continue"] { if alert.buttons[title].exists { alert.buttons[title].tap(); return true } }
            return false
        }
        app.buttons["loopback-start"].tap()
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        for title in ["继续", "Continue"] {
            if springboard.buttons[title].waitForExistence(timeout: 2) { springboard.buttons[title].tap(); break }
        }
        if !app.staticTexts["loopback-success"].exists { app.tap() }
        XCTAssertTrue(app.staticTexts["loopback-success"].waitForExistence(timeout: 20))
        // The callback assertion above is the verification. Capturing the screen while
        // the system authentication window is being dismissed is nondeterministic on CI.
    }
    @MainActor func testStudyHomeAndVocabularyReview() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        XCTAssertTrue(app.staticTexts["exam-countdown"].waitForExistence(timeout: 15))
        capture("01-phone-home")
        reveal(app.buttons["subject-english"], in: app); app.buttons["subject-english"].tap()
        app.buttons.containing(.staticText, identifier: "考研基础词库").firstMatch.tap()
        app.buttons["start-word-review"].tap()
        XCTAssertTrue(app.staticTexts["review-front"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.textViews["review-answer"].exists)
        app.buttons["reveal-card"].tap()
        XCTAssertTrue(app.textViews["review-answer"].waitForExistence(timeout: 5))
        capture("02-word-reveal")
        app.buttons["grade-good"].tap()
        XCTAssertTrue(app.staticTexts["2 / 20"].waitForExistence(timeout: 5))
    }
    @MainActor func testTimerPauseAndFinish() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        app.buttons["开始学习计时"].tap(); app.buttons["focus-start"].tap()
        XCTAssertTrue(app.staticTexts["focus-clock"].waitForExistence(timeout: 5))
        app.buttons["暂停"].tap(); XCTAssertTrue(app.buttons["继续"].exists)
        capture("03-focus-paused")
        app.buttons["结束并保存"].tap()
        XCTAssertTrue(app.staticTexts["exam-countdown"].waitForExistence(timeout: 5))
    }
    @MainActor func testQuestionHidesAnswerUntilSubmission() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-politics"], in: app); app.buttons["subject-politics"].tap()
        app.buttons.containing(.staticText, identifier: "马克思主义基本原理").firstMatch.tap()
        XCTAssertFalse(app.otherElements["question-result"].exists)
        reveal(app.buttons["option-0"], in: app); app.buttons["option-0"].tap()
        reveal(app.buttons["submit-question"], in: app); app.buttons["submit-question"].tap()
        XCTAssertTrue(app.staticTexts["答对了"].waitForExistence(timeout: 5))
        capture("04-question-feedback")
    }
    @MainActor func testSelectTextAndAskWithoutLeavingQuestion() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-politics"], in: app); app.buttons["subject-politics"].tap()
        app.buttons.containing(.staticText, identifier: "马克思主义基本原理").firstMatch.tap()
        let stem = app.textViews["selectable-question-stem"]
        XCTAssertTrue(stem.waitForExistence(timeout: 5))
        stem.coordinate(withNormalizedOffset: CGVector(dx: 0.35, dy: 0.15)).press(forDuration: 1.2)
        let ask = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "问 AI")).firstMatch
        XCTAssertTrue(ask.waitForExistence(timeout: 5))
        capture("05-selection-menu")
        ask.tap()
        XCTAssertTrue(app.staticTexts["study-selected-quote"].waitForExistence(timeout: 5))
        capture("06-inline-ai")
        let input = app.descendants(matching: .any).matching(identifier: "study-question-input").firstMatch
        input.tap(); input.typeText("请帮我理解")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        capture("07-inline-ai-keyboard")
        app.buttons["完成"].tap()
        XCTAssertTrue(app.textViews["selectable-question-stem"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["question-result"].exists)
    }
    @MainActor private func reveal(_ element: XCUIElement, in app: XCUIApplication) {
        for _ in 0..<4 { if element.isHittable { return }; app.swipeUp() }
    }
    @MainActor private func capture(_ name: String) {
        let a = XCTAttachment(screenshot: XCUIScreen.main.screenshot()); a.name = name; a.lifetime = .keepAlways; add(a)
    }
}
