import XCTest
final class NavigationUITests: XCTestCase {
    @MainActor func testReadingSubmitAndResume() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-english"], in: app); app.buttons["subject-english"].tap()
        app.buttons["english-reading-library"].tap(); app.buttons["reading-reading-feature-example"].tap()
        XCTAssertTrue(app.textViews["reading-paragraph-0"].waitForExistence(timeout: 5))
        capture("10-english-reading")
        app.buttons["reading-jump-questions"].tap()
        for (number, choice) in [(21,0),(22,1),(23,2),(24,3),(25,0)] {
            let option = app.buttons["reading-option-\(number)-\(choice)"]
            reveal(option, in: app); option.tap()
        }
        app.buttons["reading-submit"].tap()
        XCTAssertTrue(app.staticTexts["reading-score"].waitForExistence(timeout: 15))
        XCTAssertTrue(app.staticTexts["reading-score"].label.contains("5/5"))
        capture("11-reading-score")
        app.navigationBars.buttons["英语阅读"].tap()
        app.buttons["reading-reading-feature-example"].tap(); app.buttons["reading-jump-questions"].tap()
        XCTAssertTrue(app.staticTexts["reading-score"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["reading-submit"].exists)
    }
    @MainActor func testReadingSelectionAndWordCollection() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-english"], in: app); app.buttons["subject-english"].tap()
        app.buttons["english-reading-library"].tap(); app.buttons["reading-reading-feature-example"].tap()
        let text = app.textViews["reading-paragraph-0"]
        XCTAssertTrue(text.waitForExistence(timeout: 5))
        text.coordinate(withNormalizedOffset: CGVector(dx: 0.24, dy: 0.15)).press(forDuration: 1.2)
        let collect = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "加入生词本")).firstMatch
        XCTAssertTrue(collect.waitForExistence(timeout: 5))
        capture("12-reading-selection")
        app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "问 AI")).firstMatch.tap()
        XCTAssertTrue(app.staticTexts["study-selected-quote"].waitForExistence(timeout: 5)); app.buttons["完成"].tap()
        app.buttons["阅读操作"].tap(); app.buttons["收录生词"].tap()
        app.textFields["reading-word-term"].tap(); app.textFields["reading-word-term"].typeText("record")
        app.buttons["reading-word-save"].tap()
        app.buttons["阅读操作"].tap(); app.buttons["打开生词本"].tap()
        XCTAssertTrue(app.buttons["reading-collected-record"].waitForExistence(timeout: 5))
        capture("13-reading-vocabulary")
    }
    @MainActor func testSubscriptionSettingsKeepLoginSeparateFromPaidAPI() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        app.buttons["打开侧栏"].tap()
        app.buttons["学习设置"].tap()
        let aiSettings = app.buttons["AI 连接、系统提示词与聊天设置"]
        reveal(aiSettings, in: app); aiSettings.tap()
        let picker = app.buttons["ai-provider-picker"]
        XCTAssertTrue(picker.waitForExistence(timeout: 5)); picker.tap()
        app.buttons["ChatGPT 订阅"].tap()
        XCTAssertTrue(app.buttons["subscription-sign-in"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.secureTextFields["粘贴 DeepSeek API Key"].exists)
        XCTAssertFalse(app.buttons["subscription-test"].exists)
        capture("08-subscription-settings")
        app.buttons["保存"].tap()
        app.buttons["完成"].tap()
        XCTAssertTrue(app.staticTexts["exam-countdown"].waitForExistence(timeout: 5))
    }
    @MainActor func testSystemAuthenticationReturnsThroughDeviceLoopback() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview", "--subscription-loopback-smoke"]; app.launch()
        addUIInterruptionMonitor(withDescription: "System authentication consent") { alert in
            for title in ["继续", "Continue"] { if alert.buttons[title].exists { alert.buttons[title].tap(); return true } }
            return false
        }
        app.buttons["loopback-start"].tap()
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        for title in ["继续", "Continue"] {
            if springboard.buttons[title].waitForExistence(timeout: 2) { springboard.buttons[title].tap(); break }
        }
        if !app.staticTexts["loopback-success"].exists { app.tap() }
        XCTAssertTrue(app.staticTexts["loopback-success"].waitForExistence(timeout: 20))
        // The callback assertion above is the verification. Capturing the screen while
        // the system authentication window is being dismissed is nondeterministic on CI.
    }
    @MainActor func testStudyHomeAndVocabularyReview() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        XCTAssertTrue(app.staticTexts["exam-countdown"].waitForExistence(timeout: 15))
        capture("01-phone-home")
        reveal(app.buttons["subject-english"], in: app); app.buttons["subject-english"].tap()
        // 内置词库默认只查不背：英语页给的是查词入口
        XCTAssertFalse(app.buttons.containing(.staticText, identifier: "考研基础词库").firstMatch.exists)
        let lookup = app.buttons["word-lookup"]
        reveal(lookup, in: app); lookup.tap()
        let field = app.searchFields.firstMatch
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("state")
        XCTAssertTrue(app.buttons["word-result"].firstMatch.waitForExistence(timeout: 5))
        capture("02-word-lookup")
    }
    @MainActor func testTimerPauseAndFinish() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        app.buttons["开始学习计时"].tap(); app.buttons["focus-start"].tap()
        XCTAssertTrue(app.staticTexts["focus-clock"].waitForExistence(timeout: 5))
        app.buttons["暂停"].tap(); XCTAssertTrue(app.buttons["继续"].exists)
        capture("03-focus-paused")
        app.buttons["结束并保存"].tap()
        let field = app.textFields["quick-note-field"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("马原第一章")
        capture("03b-focus-note")
        app.buttons["quick-note-save"].tap()
        XCTAssertTrue(app.staticTexts["exam-countdown"].waitForExistence(timeout: 5))
    }
    @MainActor func testSyllabusAndMemoryPages() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        app.buttons["打开侧栏"].tap()
        app.buttons["考纲"].tap()
        let node = app.buttons["syllabus-node-h-cn-ancient-02"]
        XCTAssertTrue(node.waitForExistence(timeout: 5))
        capture("16-syllabus-map")
        node.tap()
        XCTAssertTrue(app.buttons["mastery-3"].waitForExistence(timeout: 5)); app.buttons["mastery-3"].tap()
        app.buttons["完成"].tap()
        XCTAssertTrue(node.waitForExistence(timeout: 5))
        app.buttons["打开侧栏"].tap()
        app.buttons["记忆"].tap()
        XCTAssertTrue(app.buttons["memory-add"].waitForExistence(timeout: 5))
        capture("17-memory")
    }
    @MainActor func testEssayGradingAndWeeklyReport() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview", "--ui-preview"]; app.launch()
        app.buttons["打开侧栏"].tap()
        app.buttons["大题"].tap()
        let new = app.buttons["essay-new-historyEssay"]
        XCTAssertTrue(new.waitForExistence(timeout: 5))
        capture("21-essay-hub")
        new.tap()
        let editor = app.textViews["essay-answer"]
        XCTAssertTrue(editor.waitForExistence(timeout: 10))
        reveal(editor, in: app); editor.tap()
        editor.typeText("秦朝确立皇帝制度、三公九卿制和郡县制。汉代推恩令、刺史制度。唐代三省六部分割相权。明朝废丞相，清朝设军机处。")
        app.buttons["收起"].tap()
        let submit = app.buttons["essay-submit"]
        reveal(submit, in: app); submit.tap()
        XCTAssertTrue(app.descendants(matching: .any)["essay-score"].waitForExistence(timeout: 10))
        capture("22-essay-result")

        let app2 = XCUIApplication(); app2.terminate(); app2.launchArguments = ["--study-preview"]; app2.launch()
        let plan = app2.buttons["plan-add"]
        reveal(plan, in: app2)
        XCTAssertTrue(plan.exists)
        let weekly = app2.buttons["weekly-report-link"]
        reveal(weekly, in: app2); weekly.tap()
        XCTAssertTrue(app2.staticTexts["weekly-hours"].waitForExistence(timeout: 5))
        capture("23-weekly-report")
    }
    @MainActor func testHistoryDictionarySearchAndChapterQuiz() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        app.buttons["打开侧栏"].tap()
        app.buttons["史事"].tap()
        XCTAssertTrue(app.buttons["中国史年表"].waitForExistence(timeout: 5))
        capture("18-history-timeline")
        let field = app.searchFields.firstMatch
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.tap(); field.typeText("百日维新")
        let hit = app.buttons.containing(.staticText, identifier: "戊戌变法").firstMatch
        XCTAssertTrue(hit.waitForExistence(timeout: 5))
        hit.tap()
        XCTAssertTrue(app.staticTexts["history-entry-title"].waitForExistence(timeout: 5))
        capture("19-history-entry")

        let app2 = XCUIApplication(); app2.terminate(); app2.launchArguments = ["--study-preview", "--ui-preview"]; app2.launch()
        app2.buttons["打开侧栏"].tap()
        app2.buttons["考纲"].tap()
        let node = app2.buttons["syllabus-node-h-cn-ancient-02"]
        XCTAssertTrue(node.waitForExistence(timeout: 5)); node.tap()
        let generate = app2.buttons["node-generate-quiz"]
        XCTAssertTrue(generate.waitForExistence(timeout: 5))
        reveal(generate, in: app2); generate.tap()
        XCTAssertTrue(app2.buttons["option-0"].waitForExistence(timeout: 10))
        capture("20-chapter-quiz")
    }
    @MainActor func testQuickNoteFromHome() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["quick-note-button"], in: app); app.buttons["quick-note-button"].tap()
        let field = app.textFields["quick-note-field"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        field.typeText("长孙博秦汉一章看完")
        capture("14-quick-note")
        app.buttons["quick-note-save"].tap()
        reveal(app.staticTexts["长孙博秦汉一章看完"], in: app)
        XCTAssertTrue(app.staticTexts["长孙博秦汉一章看完"].waitForExistence(timeout: 5))
    }
    @MainActor func testQuestionHidesAnswerUntilSubmission() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-politics"], in: app); app.buttons["subject-politics"].tap()
        app.buttons.containing(.staticText, identifier: "C-Eval 基础练习 · 马原").firstMatch.tap()
        XCTAssertFalse(app.otherElements["question-result"].exists)
        reveal(app.buttons["option-0"], in: app); app.buttons["option-0"].tap()
        reveal(app.buttons["submit-question"], in: app); app.buttons["submit-question"].tap()
        XCTAssertTrue(app.otherElements["question-result"].waitForExistence(timeout: 5))
        capture("04-question-feedback")
    }
    @MainActor func testPracticeResumesWhereLeftOff() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-politics"], in: app); app.buttons["subject-politics"].tap()
        app.buttons.containing(.staticText, identifier: "C-Eval 基础练习 · 马原").firstMatch.tap()
        reveal(app.buttons["option-0"], in: app); app.buttons["option-0"].tap()
        reveal(app.buttons["submit-question"], in: app); app.buttons["submit-question"].tap()
        XCTAssertTrue(app.otherElements["question-result"].waitForExistence(timeout: 5))
        app.navigationBars.buttons.element(boundBy: 0).tap()
        // 进度写在按钮里，系统可能把它并进按钮标签；题组题数会变，只看「已做 1 /」
        func label(_ text: String) -> XCUIElement { app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS %@", text)).firstMatch }
        XCTAssertTrue(label("已做 1 /").waitForExistence(timeout: 5))
        app.buttons.containing(.staticText, identifier: "C-Eval 基础练习 · 马原").firstMatch.tap()
        XCTAssertTrue(app.staticTexts["practice-resumed"].waitForExistence(timeout: 5))
        XCTAssertTrue(label("2 / ").exists)
        app.buttons["question-map-button"].tap()
        XCTAssertTrue(app.buttons["question-map-0"].waitForExistence(timeout: 5))
        capture("15-question-map")
    }
    @MainActor func testSelectTextAndAskWithoutLeavingQuestion() throws {
        let app = XCUIApplication(); app.launchArguments = ["--study-preview"]; app.launch()
        reveal(app.buttons["subject-politics"], in: app); app.buttons["subject-politics"].tap()
        app.buttons.containing(.staticText, identifier: "C-Eval 基础练习 · 马原").firstMatch.tap()
        let stem = app.textViews["selectable-question-stem"]
        XCTAssertTrue(stem.waitForExistence(timeout: 5))
        stem.coordinate(withNormalizedOffset: CGVector(dx: 0.35, dy: 0.15)).press(forDuration: 1.2)
        let ask = app.descendants(matching: .any).matching(NSPredicate(format: "label == %@", "问 AI")).firstMatch
        XCTAssertTrue(ask.waitForExistence(timeout: 5))
        capture("05-selection-menu")
        ask.tap()
        XCTAssertTrue(app.staticTexts["study-selected-quote"].waitForExistence(timeout: 5))
        capture("06-inline-ai")
        let input = app.descendants(matching: .any).matching(identifier: "study-question-input").firstMatch
        input.tap(); input.typeText("请帮我理解")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        capture("07-inline-ai-keyboard")
        app.buttons["完成"].tap()
        XCTAssertTrue(app.textViews["selectable-question-stem"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.otherElements["question-result"].exists)
    }
    @MainActor private func reveal(_ element: XCUIElement, in app: XCUIApplication) {
        // 要能点到，而且不能压在底部的输入栏下面
        for _ in 0..<6 {
            if element.exists, element.isHittable, element.frame.maxY < app.frame.height * 0.72 { return }
            app.swipeUp()
        }
    }
    @MainActor private func capture(_ name: String) {
        let a = XCTAttachment(screenshot: XCUIScreen.main.screenshot()); a.name = name; a.lifetime = .keepAlways; add(a)
    }
}
