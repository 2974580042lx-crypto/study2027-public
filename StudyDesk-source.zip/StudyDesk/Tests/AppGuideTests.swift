import XCTest
@testable import DeepSeekCore

final class AppGuideTests: XCTestCase {
    private var guideText: String {
        let url = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
            .appendingPathComponent("StudyDesk/Resources/app-guide.md")
        return (try? String(contentsOf: url, encoding: .utf8)) ?? ""
    }

    func testOnlyAppQuestionsGetTheGuide() {
        XCTAssertNotNil(AppGuide.context(for: "史事词典怎么用？", guide: "说明"))
        XCTAssertNotNil(AppGuide.context(for: "这个 App 能做什么", guide: "说明"))
        XCTAssertNil(AppGuide.context(for: "这道题错在哪里", guide: "说明"))
        XCTAssertNil(AppGuide.context(for: "郡国并行的原因是什么", guide: "说明"))
        XCTAssertNil(AppGuide.context(for: "怎么用？", guide: ""), "没有说明时不附带")
    }

    func testBlocksParseHeadingsListsAndNumbers() {
        let blocks = AppGuide.blocks("# 标题\n\n## 小节\n- 一条\n  - 子条\n1. 第一步\n普通段落\n1840 年鸦片战争")
        XCTAssertEqual(blocks, [.title("标题"), .heading("小节"), .bullet("一条", 0), .bullet("子条", 1),
                                .numbered("1", "第一步"), .paragraph("普通段落"), .paragraph("1840 年鸦片战争")])
    }

    /// 说明里提到的页面要真的存在；改了功能记得同步改说明
    func testGuideCoversMainPages() {
        let text = guideText
        XCTAssertFalse(text.isEmpty)
        for page in ["今天", "复习", "考纲", "大题", "史事", "资料", "记忆", "本周报告", "今日计划", "错题重做", "自动备份"] {
            XCTAssertTrue(text.contains(page), "使用说明缺少：\(page)")
        }
        XCTAssertLessThan(text.count, 6000, "说明会整段交给 AI，别写太长")
    }
}
