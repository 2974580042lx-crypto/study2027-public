import XCTest
@testable import DeepSeekCore

final class ReadingTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_790_920_000)
    private func passage(verification: ReadingVerification = .verified) -> ReadingPassage {
        ReadingPassage(id: "p", title: "Test reading", year: 2025, textNumber: 1, paragraphs: ["A reader makes a record.", "The second paragraph."],
            questions: [ReadingQuestion(id: "q21", number: 21, stem: "Which answer?", options: ["A text", "B text", "C text", "D text"], answer: 2, explanation: "hidden-answer-sentinel", verification: verification, source: "Test source")], source: "Test source", isExample: false)
    }
    private func state(verification: ReadingVerification = .verified) -> StudySnapshot {
        var s = StudySnapshot(); s.readingPassages = [passage(verification: verification)]; return s
    }
    func testOldLearningBackupLoadsWithNoReadingFields() throws {
        var old = StudySnapshot(); old.cards = [StudyCard(id: "kept", front: "record", back: "记录", subject: .english, deck: "book", source: "source", reviews: 4)]
        let decoded = try StudySnapshot.decode(old.encoded())
        XCTAssertNil(decoded.readingPassages); XCTAssertNil(decoded.readingAttempts); XCTAssertNil(decoded.readingWords)
        XCTAssertEqual(decoded.cards.first?.reviews, 4)
    }
    func testRejectsInvalidOptionsAndUnverifiedMissingAnswer() throws {
        var p = passage(); p.questions[0].options = ["A", "B"]
        XCTAssertThrowsError(try p.validate())
        p = passage(); p.questions[0].answer = 7; XCTAssertThrowsError(try p.validate())
        p = passage(); p.questions[0].answer = nil; XCTAssertThrowsError(try p.validate())
        p.questions[0].verification = .pending; XCTAssertNoThrow(try p.validate())
    }
    func testSelectionAndPositionSurviveBackupRoundTrip() throws {
        var s = state(); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        s.readingAttempts?[0].paragraph = 1
        var loaded = try StudySnapshot.decode(s.encoded())
        XCTAssertEqual(try loaded.beginReading("p"), id)
        XCTAssertEqual(loaded.readingAttempt(for: "p")?.paragraph, 1)
        XCTAssertEqual(loaded.readingAttempt(for: "p")?.selected["q21"], 2)
    }
    func testSubmitIsIdempotentAndSelectionsLockAfterSubmission() throws {
        var s = state(); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        XCTAssertTrue(try s.submitReading(id, now: now.addingTimeInterval(20)))
        XCTAssertFalse(try s.submitReading(id, now: now.addingTimeInterval(30)))
        XCTAssertEqual(s.events.count, 2); XCTAssertEqual(s.readingAttempt(for: "p")?.correct, 1)
        XCTAssertThrowsError(try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 1))
    }
    func testIncompleteAndForeignOptionsDoNotCreateLearningEvents() throws {
        var s = state(); let id = try s.beginReading("p", now: now)
        XCTAssertThrowsError(try s.submitReading(id, now: now))
        XCTAssertThrowsError(try s.chooseReadingOption(attemptID: id, questionID: "foreign", option: 0))
        XCTAssertThrowsError(try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 7))
        XCTAssertTrue(s.events.isEmpty)
    }
    func testConflictingAnswerRecordsAttemptWithoutMarkingWrong() throws {
        var s = state(verification: .conflict); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 0)
        try s.submitReading(id, now: now.addingTimeInterval(20))
        XCTAssertEqual(s.readingAttempt(for: "p")?.graded, 0)
        XCTAssertNil(s.events.first(where: { $0.kind == .question })?.correct)
        XCTAssertTrue(s.events.first?.detail.contains("待核验") == true)
    }
    func testRetryKeepsHistoryAndDailyPassageCountIsUnique() throws {
        var s = state(); let first = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: first, questionID: "q21", option: 0); try s.submitReading(first, now: now.addingTimeInterval(5))
        let second = try s.beginReading("p", restart: true, now: now.addingTimeInterval(10))
        XCTAssertNotEqual(first, second); XCTAssertTrue(s.readingAttempt(for: "p")!.selected.isEmpty)
        try s.chooseReadingOption(attemptID: second, questionID: "q21", option: 2); try s.submitReading(second, now: now.addingTimeInterval(20))
        let summary = DailyStudySummary(events: s.events, day: now)
        XCTAssertEqual(summary.answers, 2); XCTAssertEqual(summary.correct, 1); XCTAssertEqual(summary.readingsCompleted, 1)
        XCTAssertEqual(s.readingAttempts?.first?.correct, 0)
        XCTAssertEqual(s.events.first?.readingAttemptID, first)
        XCTAssertEqual(s.events.last?.readingAttemptID, second)
    }
    func testReadingHintIncludesArticleButNotAnswerOrExplanation() throws {
        let p = passage(), context = StudyAskContext.reading(p, quote: "reader", question: p.questions[0], attempt: nil)
        XCTAssertTrue(context.background.contains(p.paragraphs[1]))
        XCTAssertFalse(context.background.contains("hidden-answer-sentinel")); XCTAssertFalse(context.background.contains("资料参考答案"))
        var attempt = ReadingAttempt(passageID: p.id); attempt.submittedAt = now
        let explained = StudyAskContext.reading(p, quote: "reader", question: p.questions[0], attempt: attempt)
        XCTAssertTrue(explained.background.contains("hidden-answer-sentinel"))
        XCTAssertNotEqual(context.id, explained.id)
    }
    func testConflictingKeyIsNeverInjectedAsVerifiedAnswer() throws {
        let p = passage(verification: .conflict); var attempt = ReadingAttempt(passageID: p.id); attempt.submittedAt = now
        let context = StudyAskContext.reading(p, quote: "reader", question: p.questions[0], attempt: attempt)
        XCTAssertFalse(context.background.contains("资料参考答案")); XCTAssertFalse(context.background.contains("hidden-answer-sentinel"))
    }
    func testCollectReusesCardWithoutResettingFSRSProgressAndDeduplicates() throws {
        var s = state(); let due = now.addingTimeInterval(86400)
        s.cards = [StudyCard(id: "kept", front: "Record", back: "记录", subject: .english, deck: "book", source: "ECDICT", due: due, reviews: 7)]
        let example = ReadingWordExample(passageID: "p", passageTitle: "Test reading", quote: "A record.")
        let first = try s.collectReadingWord(term: " Record, ", definition: "new meaning", example: example, now: now)
        let second = try s.collectReadingWord(term: "record", definition: "", example: example, now: now)
        XCTAssertEqual(first, second); XCTAssertEqual(s.cards.count, 1); XCTAssertEqual(s.cards[0].reviews, 7)
        XCTAssertEqual(s.cards[0].back, "记录"); XCTAssertEqual(s.cards[0].due, due)
        XCTAssertEqual(s.readingWords?.count, 1); XCTAssertEqual(s.readingWords?.first?.examples.count, 1)
        let summary = DailyStudySummary(events: s.events, day: now)
        XCTAssertEqual(summary.wordsCollected, 1); XCTAssertEqual(summary.newWords, 0)
    }
    func testNewTermRequiresDefinitionAndBacksUpWithItsSource() throws {
        var s = state(); let example = ReadingWordExample(passageID: "p", passageTitle: "Reading", quote: "A library.")
        XCTAssertThrowsError(try s.collectReadingWord(term: "library", definition: "", example: example)); XCTAssertTrue(s.cards.isEmpty)
        let id = try s.collectReadingWord(term: "library", definition: "图书馆", example: example)
        let loaded = try StudySnapshot.decode(s.encoded())
        XCTAssertEqual(loaded.readingWords?.first?.cardID, id); XCTAssertEqual(loaded.cards.first?.back, "图书馆")
    }
    func testPDFWordSourcePageSurvivesRemovalOfOriginalResource() throws {
        var s = state(); s.resources = [StudyResource(id: "pdf", title: "我的原卷", subject: .english)]
        let example = ReadingWordExample(passageID: "", passageTitle: "我的原卷", quote: "record", resourceID: "pdf", page: 8)
        _ = try s.collectReadingWord(term: "record", definition: "记录", example: example)
        s.resources = []; XCTAssertNoThrow(try s.validate())
        XCTAssertEqual(s.readingWords?.first?.examples.first?.page, 8)
    }
    func testSelectionContextUsesTheActualOccurrence() {
        let text = "record first. " + String(repeating: "padding ", count: 80) + "record second occurrence."
        let range = (text as NSString).range(of: "record", options: .backwards)
        let context = ReadingWords.context(text, selection: range)
        XCTAssertTrue(context.contains("second occurrence")); XCTAssertFalse(context.contains("first."))
    }
    func testInvalidProgressAndOrphanWordAreRejected() throws {
        var s = state(); _ = try s.beginReading("p", now: now); s.readingAttempts?[0].paragraph = 9
        XCTAssertThrowsError(try s.validate())
        s = state(); s.readingWords = [ReadingWord(cardID: "missing", normalizedTerm: "word", examples: [ReadingWordExample(passageID: "p", passageTitle: "title", quote: "word")])]
        XCTAssertThrowsError(try s.validate())
    }

    private func canonical<T: Encodable>(_ value: T) throws -> Data {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        return try encoder.encode(value)
    }
    @discardableResult private func applyReadings(_ incoming: [ReadingPassage], into state: inout StudySnapshot) throws -> ReadingImportResult {
        let result = try state.mergingReadings(incoming)
        state = result.snapshot
        return result
    }
    private func submittedState(verification: ReadingVerification = .verified, answer: Int? = 2, selected: Int = 2) throws -> StudySnapshot {
        var s = state(verification: verification); s.readingPassages?[0].questions[0].answer = answer
        let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: selected)
        s.readingAttempts?[0].paragraph = 1
        try s.submitReading(id, now: now.addingTimeInterval(10))
        return s
    }
    private func assertPreserved(_ old: ReadingAttempt, _ new: ReadingAttempt, file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(new.id, old.id, file: file, line: line)
        XCTAssertEqual(new.passageID, old.passageID, file: file, line: line)
        XCTAssertEqual(new.selected, old.selected, file: file, line: line)
        XCTAssertEqual(new.paragraph, old.paragraph, file: file, line: line)
        XCTAssertEqual(new.startedAt, old.startedAt, file: file, line: line)
        XCTAssertEqual(new.submittedAt, old.submittedAt, file: file, line: line)
    }
    private func assertImportRejected(_ incoming: [ReadingPassage], state: StudySnapshot, file: StaticString = #filePath, line: UInt = #line) throws {
        var candidate = state; let before = try canonical(candidate)
        XCTAssertThrowsError(try applyReadings(incoming, into: &candidate), file: file, line: line)
        XCTAssertEqual(try canonical(candidate), before, file: file, line: line)
    }
    private func additionalQuestion() -> ReadingQuestion {
        var question = passage().questions[0]; question.id = "q22"; question.number = 22
        question.stem = "Another synthetic question?"; question.answer = 0
        return question
    }

    func testPendingUpdatePreservesEveryAttemptFieldAndAllEvents() throws {
        var s = try submittedState(verification: .pending, answer: nil)
        let retry = try s.beginReading("p", restart: true, now: now.addingTimeInterval(20))
        try s.chooseReadingOption(attemptID: retry, questionID: "q21", option: 0)
        try s.submitReading(retry, now: now.addingTimeInterval(30))
        let unfinished = try s.beginReading("p", restart: true, now: now.addingTimeInterval(40))
        try s.chooseReadingOption(attemptID: unfinished, questionID: "q21", option: 1)
        let old = try XCTUnwrap(s.readingAttempts), events = try canonical(s.events)
        let before = try canonical(s)
        var updated = passage()
        updated.title = "Updated synthetic reading"; updated.year = 2026; updated.textNumber = 2
        updated.paragraphs = ["An updated opening.", "An updated second paragraph.", "An appended paragraph."]
        updated.source = "Updated synthetic source"; updated.sourceURL = "https://example.invalid/reading"
        updated.questions[0].stem = "Updated synthetic stem?"; updated.questions[0].number = 23
        updated.questions[0].options = ["New A", "New B", "New C", "New D"]
        updated.questions[0].explanation = "Updated explanation"
        updated.questions[0].source = "Updated answer source"; updated.questions[0].sourceURL = "https://example.invalid/answer"
        let result = try s.mergingReadings([updated])
        XCTAssertEqual(try canonical(s), before)
        XCTAssertEqual(result.added, 0); XCTAssertEqual(result.updated, 1); XCTAssertEqual(result.unchanged, 0)
        XCTAssertEqual(result.snapshot.readingPassages, [updated])
        let history = try XCTUnwrap(result.snapshot.readingAttempts)
        XCTAssertEqual(history.count, old.count)
        for (before, after) in zip(old, history) { assertPreserved(before, after) }
        XCTAssertEqual(history[0].correct, 1); XCTAssertEqual(history[0].graded, 1)
        XCTAssertEqual(history[1].correct, 0); XCTAssertEqual(history[1].graded, 1)
        XCTAssertNil(history[2].correct); XCTAssertNil(history[2].graded)
        XCTAssertEqual(try canonical(result.snapshot.events), events)
        XCTAssertNoThrow(try result.snapshot.validate())
    }

    func testConflictAndVerifiedUpdatesRecomputeOnlyDerivedScores() throws {
        var s = try submittedState(); let original = try XCTUnwrap(s.readingAttempts?.first)
        let events = try canonical(s.events)
        let changes: [(ReadingVerification, Int?, Int, Int)] = [(.conflict, 1, 0, 0), (.verified, 0, 0, 1), (.verified, 2, 1, 1), (.pending, nil, 0, 0)]
        for (verification, answer, correct, graded) in changes {
            var updated = passage(verification: verification); updated.questions[0].answer = answer
            _ = try applyReadings([updated], into: &s)
            let attempt = try XCTUnwrap(s.readingAttempts?.first)
            assertPreserved(original, attempt)
            XCTAssertEqual(attempt.correct, correct); XCTAssertEqual(attempt.graded, graded)
            XCTAssertEqual(try canonical(s.events), events)
        }
    }

    func testRepeatedPackIsIdempotentIncludingBackupBytes() throws {
        var s = try submittedState(verification: .pending, answer: nil)
        var updated = passage(); updated.title = "Synthetic revision"
        var added = passage(); added.id = "new"
        let first = try applyReadings([updated, added], into: &s)
        XCTAssertEqual(first.added, 1); XCTAssertEqual(first.updated, 1); XCTAssertEqual(first.unchanged, 0)
        let before = try canonical(s)
        let repeated = try applyReadings([updated, added], into: &s)
        XCTAssertEqual(repeated.added, 0); XCTAssertEqual(repeated.updated, 0); XCTAssertEqual(repeated.unchanged, 2)
        XCTAssertEqual(try canonical(s), before)
    }

    func testMixedPackCountsAndPassageOrder() throws {
        var s = state(); var retained = passage(); retained.id = "retained"
        s.readingPassages?.append(retained)
        var updated = passage(); updated.title = "New title"
        var added = passage(); added.id = "new"
        let result = try applyReadings([retained, added, updated], into: &s)
        XCTAssertEqual(result.added, 1); XCTAssertEqual(result.updated, 1); XCTAssertEqual(result.unchanged, 1)
        XCTAssertEqual(s.readingPassages?.map(\.id), ["p", "retained", "new"])
        XCTAssertEqual(s.readingPassages, [updated, retained, added])
        XCTAssertNil(s.readingAttempts); XCTAssertTrue(s.events.isEmpty)
    }

    func testAddingNewPassageLeavesUnrelatedHistoryUntouched() throws {
        let s = try submittedState(); var added = passage(); added.id = "new"
        let result = try s.mergingReadings([added])
        XCTAssertEqual(result.added, 1); XCTAssertEqual(result.updated, 0); XCTAssertEqual(result.unchanged, 0)
        XCTAssertEqual(result.snapshot.readingPassages, [passage(), added])
        XCTAssertEqual(result.snapshot.readingAttempts, s.readingAttempts)
        XCTAssertEqual(try canonical(result.snapshot.events), try canonical(s.events))
    }

    func testAppendingQuestionsKeepsEarlierSubmissionValidAndDoesNotGradeUnansweredQuestions() throws {
        var s = try submittedState(); let original = try XCTUnwrap(s.readingAttempts?.first)
        let events = try canonical(s.events)
        var updated = passage(); updated.questions.append(additionalQuestion())
        _ = try applyReadings([updated], into: &s)
        let attempt = try XCTUnwrap(s.readingAttempts?.first); assertPreserved(original, attempt)
        XCTAssertEqual(attempt.correct, 1); XCTAssertEqual(attempt.graded, 1)
        XCTAssertNil(attempt.selected["q22"])
        XCTAssertEqual(try canonical(s.events), events)
        let loaded = try StudySnapshot.decode(s.encoded())
        XCTAssertEqual(loaded.readingAttempts, s.readingAttempts)
        let retry = try s.beginReading("p", restart: true, now: now.addingTimeInterval(20))
        try s.chooseReadingOption(attemptID: retry, questionID: "q21", option: 2)
        XCTAssertThrowsError(try s.submitReading(retry, now: now.addingTimeInterval(30)))
        try s.chooseReadingOption(attemptID: retry, questionID: "q22", option: 0)
        try s.submitReading(retry, now: now.addingTimeInterval(30))
        XCTAssertEqual(s.readingAttempts?.last?.graded, 2)
    }

    func testUnsubmittedUpdateRetainsSelectionsAndPositionWithoutScores() throws {
        var s = state(verification: .pending); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        s.readingAttempts?[0].paragraph = 1
        let before = try XCTUnwrap(s.readingAttempts?.first)
        var updated = passage(); updated.questions.append(additionalQuestion())
        let result = try s.mergingReadings([updated])
        XCTAssertEqual(result.snapshot.readingAttempts?.first, before)
        XCTAssertNil(result.snapshot.readingAttempts?.first?.correct)
        XCTAssertNil(result.snapshot.readingAttempts?.first?.graded)
        XCTAssertTrue(result.snapshot.events.isEmpty)
    }

    func testMixedVerificationGradesOnlyHistoricalSelections() throws {
        var s = state(); var second = additionalQuestion(); second.verification = .conflict
        s.readingPassages?[0].questions.append(second)
        let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        try s.chooseReadingOption(attemptID: id, questionID: "q22", option: 0)
        try s.submitReading(id, now: now.addingTimeInterval(10))
        let original = try XCTUnwrap(s.readingAttempts?.first), events = try canonical(s.events)
        var updated = try XCTUnwrap(s.readingPassages?.first)
        updated.questions[0].verification = .conflict
        updated.questions[1].verification = .verified; updated.questions[1].answer = 1
        var newQuestion = additionalQuestion(); newQuestion.id = "q23"; newQuestion.number = 23
        updated.questions.insert(newQuestion, at: 0)
        let result = try s.mergingReadings([updated])
        let attempt = try XCTUnwrap(result.snapshot.readingAttempts?.first)
        assertPreserved(original, attempt)
        XCTAssertEqual(attempt.correct, 0); XCTAssertEqual(attempt.graded, 1)
        XCTAssertEqual(try canonical(result.snapshot.events), events)
    }

    func testUpdatingPassageLeavesAnotherPassageAndItsAttemptUntouched() throws {
        var s = try submittedState(); var other = passage(); other.id = "other"
        s.readingPassages?.append(other)
        let id = try s.beginReading(other.id, now: now.addingTimeInterval(20))
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 0)
        try s.submitReading(id, now: now.addingTimeInterval(30))
        let original = s.readingAttempt(for: other.id), events = try canonical(s.events)
        var updated = passage(); updated.questions[0].answer = 0
        let result = try s.mergingReadings([updated])
        XCTAssertEqual(result.snapshot.readingPassages?.last, other)
        XCTAssertEqual(result.snapshot.readingAttempt(for: other.id), original)
        XCTAssertEqual(try canonical(result.snapshot.events), events)
    }

    func testDeletingEvenAnUnselectedQuestionRejectsWholePack() throws {
        var s = state(); s.readingPassages?[0].questions.append(additionalQuestion())
        let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        var added = passage(); added.id = "new"
        try assertImportRejected([added, passage()], state: s)
    }

    func testShorteningParagraphsChecksAllHistoryAndRejectsWholePack() throws {
        var s = try submittedState()
        _ = try s.beginReading("p", restart: true, now: now.addingTimeInterval(20))
        XCTAssertEqual(s.readingAttempts?.last?.paragraph, 0)
        var shortened = passage(); shortened.paragraphs.removeLast()
        var added = passage(); added.id = "new"
        try assertImportRejected([added, shortened], state: s)
    }

    func testShorteningUnusedParagraphIsSafeWhenEverySavedPositionRemainsValid() throws {
        var s = state(); _ = try s.beginReading("p", now: now)
        let before = s.readingAttempts
        var shortened = passage(); shortened.paragraphs.removeLast()
        let result = try s.mergingReadings([shortened])
        XCTAssertEqual(result.updated, 1); XCTAssertEqual(result.snapshot.readingAttempts, before)
    }

    func testInvalidIncomingOptionsOrAnswerRejectWholePack() throws {
        let s = try submittedState(); var added = passage(); added.id = "new"
        for count in [3, 5] {
            var invalid = passage(); invalid.questions[0].options = Array(repeating: "Synthetic option", count: count)
            try assertImportRejected([added, invalid], state: s)
        }
        for answer in [-1, 4] {
            var invalid = passage(); invalid.questions[0].answer = answer
            try assertImportRejected([added, invalid], state: s)
        }
    }

    func testDamagedHistoricalOptionIndicesAreRejectedWithoutRepairingHistory() throws {
        for option in [-1, 4] {
            var s = try submittedState(); s.readingAttempts?[0].selected["q21"] = option
            var added = passage(); added.id = "new"
            try assertImportRejected([added, passage()], state: s)
        }
    }

    func testDamagedHistoricalQuestionIDCannotBeConcealedByAddingThatQuestion() throws {
        var s = state(); _ = try s.beginReading("p", now: now)
        s.readingAttempts?[0].selected = ["q22": 0]
        var updated = passage(); updated.questions.append(additionalQuestion())
        try assertImportRejected([updated], state: s)
    }

    func testDamagedExistingOptionCountIsRejectedBeforeReplacement() throws {
        var s = try submittedState(); s.readingPassages?[0].questions[0].options.removeLast()
        try assertImportRejected([passage()], state: s)
    }

    func testExampleIdentityCannotSwitchInEitherDirection() throws {
        var example = passage(verification: .example); example.isExample = true
        try assertImportRejected([example], state: state())
        var s = StudySnapshot(); s.readingPassages = [example]
        try assertImportRejected([passage()], state: s)
        var updated = example; updated.title = "Updated synthetic example"
        XCTAssertEqual(try s.mergingReadings([updated]).updated, 1)
    }

    func testDuplicateIncomingPassageIDsAreRejectedAtomically() throws {
        var updated = passage(); updated.title = "Conflicting duplicate"
        try assertImportRejected([passage(), updated], state: state())
    }

    func testLateInvalidPassageRejectsOtherwiseValidAddAndUpdate() throws {
        var added = passage(); added.id = "new"
        var updated = passage(); updated.title = "Valid synthetic update"
        var invalid = passage(); invalid.id = "invalid"; invalid.paragraphs = []
        try assertImportRejected([added, updated, invalid], state: try submittedState())
    }

    func testOldBackupAcceptsNewReadingWithoutChangingCardsOrAddingHistory() throws {
        var old = StudySnapshot()
        old.cards = [StudyCard(id: "kept", front: "synthetic", back: "test definition", subject: .english, deck: "test", source: "test", reviews: 4)]
        let loaded = try StudySnapshot.decode(old.encoded())
        let result = try loaded.mergingReadings([passage()])
        XCTAssertEqual(result.added, 1); XCTAssertEqual(result.updated, 0); XCTAssertEqual(result.unchanged, 0)
        XCTAssertEqual(try canonical(result.snapshot.cards), try canonical(loaded.cards))
        XCTAssertNil(result.snapshot.readingAttempts); XCTAssertNil(result.snapshot.readingWords)
        XCTAssertEqual(try canonical(result.snapshot.events), try canonical(loaded.events))
        let restored = try StudySnapshot.decode(result.snapshot.encoded())
        XCTAssertEqual(restored.readingPassages, [passage()]); XCTAssertEqual(restored.cards.first?.reviews, 4)
    }

    func testEmptyReadingMergePreservesOldBackupOptionalFields() throws {
        let s = StudySnapshot(), result = try s.mergingReadings([])
        XCTAssertEqual(result.added, 0); XCTAssertEqual(result.updated, 0); XCTAssertEqual(result.unchanged, 0)
        XCTAssertEqual(try canonical(result.snapshot), try canonical(s))
        XCTAssertNil(result.snapshot.readingPassages); XCTAssertNil(result.snapshot.readingAttempts)
    }
}
