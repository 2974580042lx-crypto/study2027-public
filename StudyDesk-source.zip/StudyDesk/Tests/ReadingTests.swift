import XCTest
@testable import DeepSeekCore

final class ReadingTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_790_920_000)
    private func passage(verification: ReadingVerification = .verified) -> ReadingPassage {
        ReadingPassage(id: "p", title: "Test reading", year: 2025, textNumber: 1, paragraphs: ["A reader makes a record.", "The second paragraph."],
            questions: [ReadingQuestion(id: "q21", number: 21, stem: "Which answer?", options: ["A text", "B text", "C text", "D text"], answer: 2, explanation: "hidden-answer-sentinel", verification: verification, source: "Test source")], source: "Test source", isExample: false)
    }
    private func state(verification: ReadingVerification = .verified) -> StudySnapshot {
        var s = StudySnapshot(); s.readingPassages = [passage(verification: verification)]; return s
    }
    func testOldLearningBackupLoadsWithNoReadingFields() throws {
        var old = StudySnapshot(); old.cards = [StudyCard(id: "kept", front: "record", back: "记录", subject: .english, deck: "book", source: "source", reviews: 4)]
        let decoded = try StudySnapshot.decode(old.encoded())
        XCTAssertNil(decoded.readingPassages); XCTAssertNil(decoded.readingAttempts); XCTAssertNil(decoded.readingWords)
        XCTAssertEqual(decoded.cards.first?.reviews, 4)
    }
    func testRejectsInvalidOptionsAndUnverifiedMissingAnswer() throws {
        var p = passage(); p.questions[0].options = ["A", "B"]
        XCTAssertThrowsError(try p.validate())
        p = passage(); p.questions[0].answer = 7; XCTAssertThrowsError(try p.validate())
        p = passage(); p.questions[0].answer = nil; XCTAssertThrowsError(try p.validate())
        p.questions[0].verification = .pending; XCTAssertNoThrow(try p.validate())
    }
    func testSelectionAndPositionSurviveBackupRoundTrip() throws {
        var s = state(); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        s.readingAttempts?[0].paragraph = 1
        var loaded = try StudySnapshot.decode(s.encoded())
        XCTAssertEqual(try loaded.beginReading("p"), id)
        XCTAssertEqual(loaded.readingAttempt(for: "p")?.paragraph, 1)
        XCTAssertEqual(loaded.readingAttempt(for: "p")?.selected["q21"], 2)
    }
    func testSubmitIsIdempotentAndSelectionsLockAfterSubmission() throws {
        var s = state(); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 2)
        XCTAssertTrue(try s.submitReading(id, now: now.addingTimeInterval(20)))
        XCTAssertFalse(try s.submitReading(id, now: now.addingTimeInterval(30)))
        XCTAssertEqual(s.events.count, 2); XCTAssertEqual(s.readingAttempt(for: "p")?.correct, 1)
        XCTAssertThrowsError(try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 1))
    }
    func testIncompleteAndForeignOptionsDoNotCreateLearningEvents() throws {
        var s = state(); let id = try s.beginReading("p", now: now)
        XCTAssertThrowsError(try s.submitReading(id, now: now))
        XCTAssertThrowsError(try s.chooseReadingOption(attemptID: id, questionID: "foreign", option: 0))
        XCTAssertThrowsError(try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 7))
        XCTAssertTrue(s.events.isEmpty)
    }
    func testConflictingAnswerRecordsAttemptWithoutMarkingWrong() throws {
        var s = state(verification: .conflict); let id = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: id, questionID: "q21", option: 0)
        try s.submitReading(id, now: now.addingTimeInterval(20))
        XCTAssertEqual(s.readingAttempt(for: "p")?.graded, 0)
        XCTAssertNil(s.events.first(where: { $0.kind == .question })?.correct)
        XCTAssertTrue(s.events.first?.detail.contains("待核验") == true)
    }
    func testRetryKeepsHistoryAndDailyPassageCountIsUnique() throws {
        var s = state(); let first = try s.beginReading("p", now: now)
        try s.chooseReadingOption(attemptID: first, questionID: "q21", option: 0); try s.submitReading(first, now: now.addingTimeInterval(5))
        let second = try s.beginReading("p", restart: true, now: now.addingTimeInterval(10))
        XCTAssertNotEqual(first, second); XCTAssertTrue(s.readingAttempt(for: "p")!.selected.isEmpty)
        try s.chooseReadingOption(attemptID: second, questionID: "q21", option: 2); try s.submitReading(second, now: now.addingTimeInterval(20))
        let summary = DailyStudySummary(events: s.events, day: now)
        XCTAssertEqual(summary.answers, 2); XCTAssertEqual(summary.correct, 1); XCTAssertEqual(summary.readingsCompleted, 1)
        XCTAssertEqual(s.readingAttempts?.first?.correct, 0)
        XCTAssertEqual(s.events.first?.readingAttemptID, first)
        XCTAssertEqual(s.events.last?.readingAttemptID, second)
    }
    func testReadingHintIncludesArticleButNotAnswerOrExplanation() throws {
        let p = passage(), context = StudyAskContext.reading(p, quote: "reader", question: p.questions[0], attempt: nil)
        XCTAssertTrue(context.background.contains(p.paragraphs[1]))
        XCTAssertFalse(context.background.contains("hidden-answer-sentinel")); XCTAssertFalse(context.background.contains("资料参考答案"))
        var attempt = ReadingAttempt(passageID: p.id); attempt.submittedAt = now
        let explained = StudyAskContext.reading(p, quote: "reader", question: p.questions[0], attempt: attempt)
        XCTAssertTrue(explained.background.contains("hidden-answer-sentinel"))
        XCTAssertNotEqual(context.id, explained.id)
    }
    func testConflictingKeyIsNeverInjectedAsVerifiedAnswer() throws {
        let p = passage(verification: .conflict); var attempt = ReadingAttempt(passageID: p.id); attempt.submittedAt = now
        let context = StudyAskContext.reading(p, quote: "reader", question: p.questions[0], attempt: attempt)
        XCTAssertFalse(context.background.contains("资料参考答案")); XCTAssertFalse(context.background.contains("hidden-answer-sentinel"))
    }
    func testCollectReusesCardWithoutResettingFSRSProgressAndDeduplicates() throws {
        var s = state(); let due = now.addingTimeInterval(86400)
        s.cards = [StudyCard(id: "kept", front: "Record", back: "记录", subject: .english, deck: "book", source: "ECDICT", due: due, reviews: 7)]
        let example = ReadingWordExample(passageID: "p", passageTitle: "Test reading", quote: "A record.")
        let first = try s.collectReadingWord(term: " Record, ", definition: "new meaning", example: example, now: now)
        let second = try s.collectReadingWord(term: "record", definition: "", example: example, now: now)
        XCTAssertEqual(first, second); XCTAssertEqual(s.cards.count, 1); XCTAssertEqual(s.cards[0].reviews, 7)
        XCTAssertEqual(s.cards[0].back, "记录"); XCTAssertEqual(s.cards[0].due, due)
        XCTAssertEqual(s.readingWords?.count, 1); XCTAssertEqual(s.readingWords?.first?.examples.count, 1)
        let summary = DailyStudySummary(events: s.events, day: now)
        XCTAssertEqual(summary.wordsCollected, 1); XCTAssertEqual(summary.newWords, 0)
    }
    func testNewTermRequiresDefinitionAndBacksUpWithItsSource() throws {
        var s = state(); let example = ReadingWordExample(passageID: "p", passageTitle: "Reading", quote: "A library.")
        XCTAssertThrowsError(try s.collectReadingWord(term: "library", definition: "", example: example)); XCTAssertTrue(s.cards.isEmpty)
        let id = try s.collectReadingWord(term: "library", definition: "图书馆", example: example)
        let loaded = try StudySnapshot.decode(s.encoded())
        XCTAssertEqual(loaded.readingWords?.first?.cardID, id); XCTAssertEqual(loaded.cards.first?.back, "图书馆")
    }
    func testPDFWordSourcePageSurvivesRemovalOfOriginalResource() throws {
        var s = state(); s.resources = [StudyResource(id: "pdf", title: "我的原卷", subject: .english)]
        let example = ReadingWordExample(passageID: "", passageTitle: "我的原卷", quote: "record", resourceID: "pdf", page: 8)
        _ = try s.collectReadingWord(term: "record", definition: "记录", example: example)
        s.resources = []; XCTAssertNoThrow(try s.validate())
        XCTAssertEqual(s.readingWords?.first?.examples.first?.page, 8)
    }
    func testSelectionContextUsesTheActualOccurrence() {
        let text = "record first. " + String(repeating: "padding ", count: 80) + "record second occurrence."
        let range = (text as NSString).range(of: "record", options: .backwards)
        let context = ReadingWords.context(text, selection: range)
        XCTAssertTrue(context.contains("second occurrence")); XCTAssertFalse(context.contains("first."))
    }
    func testInvalidProgressAndOrphanWordAreRejected() throws {
        var s = state(); _ = try s.beginReading("p", now: now); s.readingAttempts?[0].paragraph = 9
        XCTAssertThrowsError(try s.validate())
        s = state(); s.readingWords = [ReadingWord(cardID: "missing", normalizedTerm: "word", examples: [ReadingWordExample(passageID: "p", passageTitle: "title", quote: "word")])]
        XCTAssertThrowsError(try s.validate())
    }
}
