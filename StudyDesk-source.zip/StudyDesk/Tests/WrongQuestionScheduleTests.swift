import XCTest
@testable import DeepSeekCore

final class WrongQuestionScheduleTests: XCTestCase {
    private var calendar: Calendar = {
        var c = Calendar(identifier: .gregorian)
        c.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        return c
    }()
    private func day(_ d: Int, _ h: Int = 10) -> Date {
        calendar.date(from: DateComponents(year: 2026, month: 10, day: d, hour: h))!
    }
    private func attempt(_ correct: Bool, _ date: Date) -> QuestionAttempt {
        QuestionAttempt(questionID: "q", selected: [0], correct: correct, date: date)
    }
    private func state(_ attempts: [QuestionAttempt], now: Date) -> WrongQuestionState? {
        WrongQuestionSchedule.state(for: "q", attempts: attempts, now: now, calendar: calendar)
    }

    func testNeverWrongIsNotInBook() {
        XCTAssertNil(state([attempt(true, day(5))], now: day(6)))
    }

    func testWrongWaitsUntilNextDay() {
        let s = state([attempt(false, day(5, 22))], now: day(5, 23))
        XCTAssertEqual(s?.stage, .waiting(next: calendar.startOfDay(for: day(6))))
        XCTAssertEqual(state([attempt(false, day(5, 22))], now: day(6, 0))?.stage, .due)
    }

    func testSameDayCorrectDoesNotCount() {
        let s = state([attempt(false, day(5)), attempt(true, day(5, 11))], now: day(6))
        XCTAssertEqual(s?.passes, 0)
        XCTAssertEqual(s?.stage, .due)
    }

    func testTwoSpacedPassesMaster() {
        let attempts = [attempt(false, day(5)), attempt(true, day(6)), attempt(true, day(9))]
        XCTAssertEqual(state(attempts, now: day(10))?.stage, .mastered)
    }

    func testSecondPassTooEarlyKeepsWaiting() {
        let attempts = [attempt(false, day(5)), attempt(true, day(6)), attempt(true, day(7))]
        let s = state(attempts, now: day(7, 12))
        XCTAssertEqual(s?.passes, 1)
        XCTAssertEqual(s?.stage, .waiting(next: calendar.startOfDay(for: day(9))))
    }

    func testWrongAgainRestarts() {
        let attempts = [attempt(false, day(5)), attempt(true, day(6)), attempt(false, day(9)), attempt(true, day(9, 12))]
        let s = state(attempts, now: day(9, 13))
        XCTAssertEqual(s?.passes, 0)
        XCTAssertEqual(s?.lastWrong, day(9))
    }

    func testOldDataWithSingleLaterCorrectStillNeedsSecondPass() {
        // 旧版规则下答对一次就算过关；新规则要求再隔 3 天答对一次
        let attempts = [attempt(false, day(1)), attempt(true, day(3))]
        XCTAssertEqual(state(attempts, now: day(4))?.stage, .waiting(next: calendar.startOfDay(for: day(6))))
        XCTAssertEqual(state(attempts, now: day(6))?.stage, .due)
    }
}
