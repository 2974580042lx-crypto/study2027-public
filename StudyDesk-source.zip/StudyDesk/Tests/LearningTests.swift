import XCTest
import FSRS
@testable import DeepSeekCore

final class LearningTests: XCTestCase {
    private var calendar: Calendar { var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(secondsFromGMT: 8*3600)!; return c }
    private func date(_ day: Int, _ hour: Int, _ minute: Int) -> Date { calendar.date(from: DateComponents(year: 2026, month: 10, day: day, hour: hour, minute: minute))! }
    func testCountdownUsesCalendarDaysNot24HourRounding() {
        XCTAssertEqual(StudyPreferences.daysUntil(date(3, 0, 0), from: date(2, 23, 59), calendar: calendar), 1)
        XCTAssertEqual(StudyPreferences.daysUntil(date(2, 0, 0), from: date(3, 0, 0), calendar: calendar), 0)
    }
    func testFocusSessionCrossingMidnightSplitsBetweenDays() {
        let e = LearningEvent(subject: .english, kind: .focus, title: "reading", detail: "", start: date(2, 23, 50), end: date(3, 0, 20))
        XCTAssertEqual(e.seconds(on: date(2, 12, 0), calendar: calendar), 600)
        XCTAssertEqual(e.seconds(on: date(3, 12, 0), calendar: calendar), 1200)
    }
    func testPausedTimerDoesNotAccumulateAndCountdownCaps() {
        let paused = FocusRun(subject: .history, label: "reading", targetSeconds: nil, elapsed: 90, segmentStart: nil)
        XCTAssertEqual(paused.total(at: date(3, 0, 0)), 90)
        let run = FocusRun(subject: .english, label: "focus", targetSeconds: 1500, elapsed: 300, segmentStart: date(2, 10, 0))
        XCTAssertEqual(run.total(at: date(2, 11, 0)), 1500)
        XCTAssertEqual(run.effectiveEnd(at: date(2, 11, 0)), date(2, 10, 20))
    }
    func testReviewUsesUpstreamFSRSAndSurvivesBackup() throws {
        let now = date(2, 10, 0)
        var card = StudyCard(front: "study", back: "learn", subject: .english, deck: "test", source: "test")
        try card.review(.good, at: now)
        let expected = try FSRS(parameters: FSRSParameters(w: FSRSDefaults.defaultWv6, enableFuzz: false)).next(card: Card(due: now), now: now, grade: .good)
        XCTAssertEqual(card.memory, expected.card)
        var snapshot = StudySnapshot(); snapshot.cards = [card]
        let decoded = try StudySnapshot.decode(snapshot.encoded())
        XCTAssertEqual(decoded.cards[0].memory, card.memory)
        XCTAssertEqual(decoded.cards[0].reviewLogs, card.reviewLogs)
        XCTAssertEqual(decoded.cards[0].reviews, 1)
    }
    func testNewWordsAndRepeatReviewsAreSeparate() {
        let d = date(2, 10, 0)
        let events = [LearningEvent(subject: .english, kind: .newWord, title: "study", detail: "", start: d, end: d, referenceID: "same"), LearningEvent(subject: .english, kind: .reviewWord, title: "study", detail: "", start: d, end: d, referenceID: "same")]
        let summary = DailyStudySummary(events: events, day: d, calendar: calendar)
        XCTAssertEqual(summary.newWords, 1); XCTAssertEqual(summary.reviewedWords, 1); XCTAssertEqual(summary.seconds, 0)
    }
    func testMultipleChoiceRequiresExactSet() throws {
        let q = StudyQuestion(subject: .politics, group: "test", stem: "test", options: ["a", "b", "c"], answers: [0,2], explanation: "", source: "test")
        try q.validate()
        XCTAssertTrue(q.isCorrect([2,0])); XCTAssertFalse(q.isCorrect([0])); XCTAssertFalse(q.isCorrect([0,1,2]))
    }
    func testCSVHandlesQuotedCommasAndNewlines() throws {
        let rows = try StudyImport.parseCards("word,meaning,deck\r\nexample,\"first,second\nthird\",unit1\r\n", subject: .english, deck: "fallback")
        XCTAssertEqual(rows.count, 1); XCTAssertEqual(rows[0].back, "first,second\nthird"); XCTAssertEqual(rows[0].deck, "unit1")
        let tsv = try StudyImport.parseCards("study\tlearn\nread\treading", subject: .english, deck: "test")
        XCTAssertEqual(tsv.count, 2); XCTAssertEqual(tsv[0].front, "study")
    }
    func testUnsafeAttachmentAndInvalidAnswersRejected() {
        var state = StudySnapshot(); state.resources = [StudyResource(title: "bad", subject: .history, fileName: "../escape.pdf")]
        XCTAssertThrowsError(try state.validate())
        let q = StudyQuestion(subject: .history, group: "test", stem: "test", options: ["a","b"], answers: [9], explanation: "", source: "test")
        XCTAssertThrowsError(try q.validate())
    }
    func testBundledSeedDecodes() throws {
        let root = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
        let data = try Data(contentsOf: root.appendingPathComponent("StudyDesk/Resources/study-seed.json"))
        struct Seed: Decodable { var cards: [StudyCard]; var questions: [StudyQuestion]; var resources: [StudyResource] }
        let seed = try JSONDecoder().decode(Seed.self, from: data)
        var state = StudySnapshot(); state.cards = seed.cards; state.questions = seed.questions; state.resources = seed.resources
        try state.validate(); XCTAssertEqual(state.cards.filter { $0.subject == .english }.count, 4801)
    }
}
