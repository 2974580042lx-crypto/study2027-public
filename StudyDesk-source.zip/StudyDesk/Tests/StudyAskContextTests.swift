import XCTest
@testable import DeepSeekCore

final class StudyAskContextTests: XCTestCase {
    func testUnsubmittedQuestionDoesNotAttachAnswerOrExplanation() {
        let q = StudyQuestion(id: "q1", subject: .politics, group: "2024", stem: "题干", options: ["A项", "B项"], answers: [1], explanation: "EXPLANATION_SENTINEL", source: "原卷")
        let context = StudyAskContext.question(q, quote: "B项", submitted: false, selected: [0])
        XCTAssertEqual(context.mode, .hint)
        XCTAssertFalse(context.instruction.contains("EXPLANATION_SENTINEL"))
        XCTAssertFalse(context.instruction.contains("资料参考答案"))
        XCTAssertTrue(context.instruction.contains("用户当前选择：A"))
        XCTAssertTrue(context.message(for: "为什么？").contains("B项"))
    }
    func testSubmittedQuestionIncludesReferenceAndSeparatesHintHistory() {
        let q = StudyQuestion(id: "q2", subject: .history, group: "练习", stem: "题干", options: ["A项", "B项"], answers: [1], explanation: "解析内容", source: "原卷")
        let hint = StudyAskContext.question(q, quote: "题干", submitted: false, selected: [])
        let answer = StudyAskContext.question(q, quote: "B项", submitted: true, selected: [0])
        XCTAssertNotEqual(hint.id, answer.id)
        XCTAssertTrue(answer.instruction.contains("资料参考答案：B"))
        XCTAssertTrue(answer.instruction.contains("解析内容"))
    }
    func testDifferentSelectionsInSameMaterialReuseConversation() {
        let a = StudyAskContext(referenceID: "paper:2024:text1", subject: .english, title: "原文", quote: "第一句", background: "背景", source: "2024")
        var b = a; b.quote = "第二句"
        XCTAssertEqual(a.id, b.id)
        XCTAssertNotEqual(a.message(for: "翻译"), b.message(for: "翻译"))
    }
    func testOldConversationWithoutContextStillDecodes() throws {
        let data = Data("{\"id\":\"E952A9B0-CC78-435C-BF08-06AD47FE1076\",\"title\":\"原对话\",\"createdAt\":0,\"updatedAt\":0,\"messages\":[]}".utf8)
        let thread = try JSONDecoder().decode(ChatThread.self, from: data)
        XCTAssertNil(thread.studyReferenceID); XCTAssertNil(thread.studyContext)
    }
}
