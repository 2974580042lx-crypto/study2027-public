import XCTest
@testable import DeepSeekCore

final class QuickNoteTests: XCTestCase {
    func testGuessSubject() {
        XCTAssertEqual(QuickNote.guessSubject("马原第一章看完，选择题错了 4 道"), .politics)
        XCTAssertEqual(QuickNote.guessSubject("肖秀荣1000题做了两节"), .politics)
        XCTAssertEqual(QuickNote.guessSubject("背了 50 个单词"), .english)
        XCTAssertEqual(QuickNote.guessSubject("2010 text 2 reading"), .english)
        XCTAssertEqual(QuickNote.guessSubject("长孙博大纲解析秦汉"), .history)
        XCTAssertNil(QuickNote.guessSubject("今天状态一般"))
    }

    func testTitleTrimsAndTruncates() {
        XCTAssertEqual(QuickNote.title(for: "  看完一章 \n第二行  "), "看完一章")
        let long = String(repeating: "史", count: 50)
        XCTAssertEqual(QuickNote.title(for: long), String(repeating: "史", count: 38) + "…")
    }

    func testNoteEventHasNoDuration() {
        let now = Date()
        let note = LearningEvent(subject: .history, kind: .note, title: "看书", detail: "看书", start: now, end: now, manual: true)
        let summary = DailyStudySummary(events: [note], day: now)
        XCTAssertEqual(summary.seconds, 0)
    }
}
