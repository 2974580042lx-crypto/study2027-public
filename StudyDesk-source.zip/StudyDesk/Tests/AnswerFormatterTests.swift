import XCTest
@testable import DeepSeekCore

final class AnswerFormatterTests: XCTestCase {
    func testJoinsSentencePerLineIntoOneParagraph() {
        let text = "郡国并行是汉初的制度。\n它同时用郡县和封国。\n\n第二段从这里开始。"
        XCTAssertEqual(AnswerFormatter.blocks(text), [.paragraph("郡国并行是汉初的制度。它同时用郡县和封国。"), .paragraph("第二段从这里开始。")])
    }

    func testHeadingsListsAndRules() {
        let text = "## **核心结论**\n- 第一点\n* 第二点\n1. 先看时间\n2、再看主体\n---\n正文"
        XCTAssertEqual(AnswerFormatter.blocks(text), [
            .heading("核心结论"), .bullet("第一点"), .bullet("第二点"),
            .numbered("1", "先看时间"), .numbered("2", "再看主体"), .rule, .paragraph("正文"),
        ])
    }

    func testEnglishLinesGetASpace() {
        XCTAssertEqual(AnswerFormatter.join(["The author argues", "that cities grow."]), "The author argues that cities grow.")
        XCTAssertEqual(AnswerFormatter.join(["中文", "接着写"]), "中文接着写")
    }

    func testEachSubjectHasItsOwnPersona() {
        XCTAssertTrue(SubjectPersona.prompt(for: .history).contains("313"))
        XCTAssertTrue(SubjectPersona.prompt(for: .politics).contains("马原"))
        XCTAssertTrue(SubjectPersona.prompt(for: .english).contains("长难句"))
        XCTAssertEqual(Set(StudySubject.allCases.map(SubjectPersona.prompt(for:))).count, StudySubject.allCases.count)
    }

    func testYearAtLineStartIsNotANumberedItem() {
        // 「1840 年」这种不能被当成编号列表
        XCTAssertEqual(AnswerFormatter.blocks("1840 年鸦片战争爆发。"), [.paragraph("1840 年鸦片战争爆发。")])
    }
}
