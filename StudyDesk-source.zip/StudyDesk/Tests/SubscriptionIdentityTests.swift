import XCTest
@testable import DeepSeekCore

// Synthetic public key and token, generated solely for offline verification.
final class SubscriptionIdentityTests: XCTestCase {
    private let keys = Data(#"{"keys":[{"kty":"RSA","n":"trln1uwlwmRYbkr8WQzKRZDb-y6E2Vm8QmlMGrSynBjVgsbx2nwJJ_POhdeOifHG0U0mrMHtDJ64jyWrGKwZKF3AwDF5tpjU_k47k8a02WGDGdEzXQKPmYxoJoq_MyNC9YSRzo6xIvp8PYKSHfG0YH80V_07TkvhU6gVJkIhLadAPdVhC_z6UA9ND205s_R721I9d4uzJ5Ba32RArtBkl_WIzcVW58p1miTyt4TJoAenTuU1z5iirB3Rycix6INrEpncU2X5wAZtJnktJ1_Wgmq85_q4myfxHB0SAZfytiHFkjzIL1tpS6pd8P1CL-UFm3oK-pgb0c2EvzNHaBtOrw","e":"AQAB","kid":"study-synthetic-test","alg":"RS256","use":"sig"}]}"#.utf8)
    private let token = "eyJhbGciOiJSUzI1NiIsImtpZCI6InN0dWR5LXN5bnRoZXRpYy10ZXN0In0.eyJub25jZSI6Im5vbmNlLXRlc3QiLCJlbWFpbCI6InN5bnRoZXRpY0BleGFtcGxlLmludmFsaWQiLCJhenAiOiJvYWlhcHBfdGVzdCIsImlzcyI6Imh0dHBzOi8vYXV0aC5vcGVuYWkuY29tIiwic3ViIjoic3ludGhldGljLXN1YmplY3QiLCJhdWQiOiJvYWlhcHBfdGVzdCIsImlhdCI6MTc5MDk0MjQwMCwiZXhwIjoxNzkwOTQ2MDAwfQ.JDSLHzc4lHGSU5a6hgZ_8CdGdk6tkDybHV4dYMGry2S4hwMG6XZSRMT8oe_Bow47mQGWbs4UgwZZyhMNvzCiZlrZxrIt3opg6uh9Ijb99ntgPjzoJQTtpttGPVwsdFwR4Imvews2tprYiZnnFCpI3JZahR6MP9BZ8Ls2sVoU37S57mVjL4u1E7551JGEb5VgUj20IB2QUHPtCQIHyb7thC6sn-2dZxefybTJwnupce8GgyvFp7ye6djbbTGd00KCMF9bn3On8Ryj7VYcAFl46MlKAy48jnLK9mpJ8j4OVLK1lacusUDKzZajt1CzEfhlXyUekHGdwMg3HQdGaYqtyA"
    private let now = Date(timeIntervalSince1970: 1790942500)
    func testValidRS256Identity() throws {
        let identity = try SubscriptionJWT.verify(token, jwks: keys, clientID: "oaiapp_test", nonce: "nonce-test", now: now)
        XCTAssertEqual(identity.subject, "synthetic-subject")
    }
    func testRejectsWrongNonceAudienceSubjectAndExpiry() throws {
        XCTAssertThrowsError(try SubscriptionJWT.verify(token, jwks: keys, clientID: "oaiapp_test", nonce: "other", now: now))
        XCTAssertThrowsError(try SubscriptionJWT.verify(token, jwks: keys, clientID: "oaiapp_other", nonce: "nonce-test", now: now))
        XCTAssertThrowsError(try SubscriptionJWT.verify(token, jwks: keys, clientID: "oaiapp_test", nonce: nil, expectedSubject: "other-subject", now: now))
        XCTAssertThrowsError(try SubscriptionJWT.verify(token, jwks: keys, clientID: "oaiapp_test", nonce: "nonce-test", now: now.addingTimeInterval(4000)))
    }
    func testRejectsTamperedSignatureAndUnsignedToken() throws {
        var pieces = token.split(separator: ".").map(String.init)
        let first = pieces[2].first == "A" ? "B" : "A"
        pieces[2] = first + pieces[2].dropFirst()
        XCTAssertThrowsError(try SubscriptionJWT.verify(pieces.joined(separator: "."), jwks: keys, clientID: "oaiapp_test", nonce: "nonce-test", now: now))
        pieces[0] = Data(#"{"alg":"none","kid":"study-synthetic-test"}"#.utf8).base64URL
        pieces[2] = ""
        XCTAssertThrowsError(try SubscriptionJWT.verify(pieces.joined(separator: "."), jwks: keys, clientID: "oaiapp_test", nonce: "nonce-test", now: now))
    }
}
