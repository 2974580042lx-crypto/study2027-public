import XCTest
@testable import DeepSeekCore

final class SubscriptionTests: XCTestCase {
    private func tx() -> SubscriptionTransaction {
        SubscriptionTransaction(state: "one-time-state", nonce: "one-time-nonce", verifier: "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk", redirectURI: "http://127.0.0.1:49321/auth/callback")
    }
    func testPKCEAndRegistrationUseActualAppAndStableHost() throws {
        let t = tx()
        XCTAssertEqual(t.challenge, "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM")
        let url = t.authorizationURL(endpoint: URL(string: "https://auth.openai.com/api/accounts/authorize")!, hostID: "urn:uuid:test-host", clientID: nil, idTokenHint: nil)
        let q = URLComponents(url: url, resolvingAgainstBaseURL: false)!.queryItems!
        XCTAssertEqual(q.first(where: { $0.name == "agent_name_hint" })?.value, "研习")
        XCTAssertEqual(q.first(where: { $0.name == "client_id" })?.value, "dynamic_agent_client")
        XCTAssertEqual(q.first(where: { $0.name == "redirect_uri" })?.value, t.redirectURI)
        XCTAssertFalse(url.absoluteString.contains(t.verifier))
    }
    func testCallbackRejectsForeignStateHostPathAndDuplicateFields() throws {
        let t = tx(), valid = t.redirectURI + "?code=synthetic&state=one-time-state&client_id=oaiapp_test"
        XCTAssertEqual(try t.validateCallback(URL(string: valid)!, savedClientID: nil).clientID, "oaiapp_test")
        for bad in [valid.replacingOccurrences(of: "127.0.0.1", with: "localhost"), valid.replacingOccurrences(of: "/auth/callback", with: "/callback"), valid.replacingOccurrences(of: "one-time-state", with: "wrong"), valid + "&state=one-time-state", valid + "&code=other", valid.replacingOccurrences(of: "oaiapp_test", with: "dynamic_agent_client")] {
            XCTAssertThrowsError(try t.validateCallback(URL(string: bad)!, savedClientID: nil))
        }
        XCTAssertThrowsError(try t.validateCallback(URL(string: valid)!, savedClientID: "oaiapp_other"))
    }
    func testReturningCallbackPreservesIssuedClientAndDenialIsNotSuccess() throws {
        let t = tx()
        XCTAssertEqual(try t.validateCallback(URL(string: t.redirectURI + "?code=synthetic&state=one-time-state")!, savedClientID: "oaiapp_saved").clientID, "oaiapp_saved")
        XCTAssertThrowsError(try t.validateCallback(URL(string: t.redirectURI + "?error=access_denied&state=one-time-state")!, savedClientID: "oaiapp_saved"))
    }
    func testResponsesPayloadUsesSubscriptionFieldsAndHidesFailedHistory() throws {
        var settings = AppSettings(); settings.systemPrompt = "学习提示"; settings.provider = .chatGPT
        let request = ChatRequest(settings: settings, messages: [ChatMessage(role: .user, content: "问题"), ChatMessage(role: .assistant, content: "失败的答案", state: .failed), ChatMessage(role: .user, content: "再问")])
        let data = try JSONEncoder().encode(SubscriptionRequest(request: request, model: "gpt-5.6-sol"))
        let root = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        XCTAssertEqual(root["model"] as? String, "gpt-5.6-sol")
        XCTAssertEqual(root["store"] as? Bool, false); XCTAssertEqual(root["stream"] as? Bool, true)
        XCTAssertEqual(root["instructions"] as? String, "学习提示")
        XCTAssertNil(root["max_output_tokens"]); XCTAssertNil(root["max_tokens"]); XCTAssertNil(root["reasoning"])
        let messages = try XCTUnwrap(root["input"] as? [[String: String]])
        XCTAssertEqual(messages.map { $0["content"]! }, ["问题", "再问"])
        XCTAssertFalse(messages.contains { $0["role"] == "system" })
    }
    func testOldSettingsAndMessagesRemainDecodable() throws {
        let old = #"{"model":"deepseek-flash","thinkingEnabled":true,"effort":"high","systemPrompt":"hello","maxOutputTokens":4096,"contextMessageLimit":40}"#
        let decoded = try JSONDecoder().decode(AppSettings.self, from: Data(old.utf8))
        XCTAssertEqual(decoded.selectedProvider, .deepSeek); XCTAssertEqual(decoded.subscriptionModelID, "gpt-5.6-sol")
        XCTAssertEqual(decoded.selectedSubscriptionEffort, .automatic)
    }
    func testCatalogUsesOnlyReturnedVisibleModels() throws {
        let data = Data(#"{"models":[{"slug":"gpt-5.6-sol","display_name":"GPT-5.6 Sol","visibility":"list"},{"slug":"gpt-6.1-sol","display_name":"GPT-6.1 Sol","visibility":"hidden"}]}"#.utf8)
        XCTAssertEqual(try SubscriptionModel.catalog(data).map(\.slug), ["gpt-5.6-sol"])
    }
    func testUTF8CRLFStreamRequiresCompletedAndParsesUsage() throws {
        var parser = ResponsesStreamDecoder(); var text = ""; var finalEvent: StreamEvent?
        let source = "\u{FEFF}: keepalive\r\n\r\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"你好\"}\r\n\r\ndata: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\",\"usage\":{\"input_tokens\":12,\"output_tokens\":3,\"input_tokens_details\":{\"cached_tokens\":2}}}}\r\n\r\n"
        for byte in source.utf8 { if let event = try parser.consume(byte) { text += event.content; finalEvent = event } }
        XCTAssertEqual(text, "你好"); XCTAssertTrue(parser.completed)
        XCTAssertEqual(finalEvent?.usage?.totalTokens, 15); XCTAssertEqual(finalEvent?.usage?.cachedTokens, 2)
    }
    func testDoneAndPartialTextDoNotPretendToBeComplete() throws {
        var parser = ResponsesStreamDecoder()
        let source = "data: {\"type\":\"response.output_text.delta\",\"delta\":\"partial\"}\n\ndata: [DONE]\n\n"
        for byte in source.utf8 { _ = try parser.consume(byte) }
        _ = try parser.finish(); XCTAssertFalse(parser.completed)
    }
    func testLateQuotaFailureIsReportedAfterText() throws {
        var parser = ResponsesStreamDecoder()
        for byte in "data: {\"type\":\"response.output_text.delta\",\"delta\":\"partial\"}\n\n".utf8 { _ = try parser.consume(byte) }
        XCTAssertThrowsError(try "data: {\"type\":\"response.failed\",\"response\":{\"error\":{\"code\":\"subscription_sharing_usage_limit_exceeded\"}}}\n\n".utf8.forEach { _ = try parser.consume($0) }) { error in
            XCTAssertTrue(error.localizedDescription.contains("额度"))
        }
        XCTAssertFalse(parser.completed)
    }
    func testDiscoveryRejectsOffOriginIdentityEndpoints() throws {
        let input = #"{"issuer":"https://auth.openai.com","authorization_endpoint":"https://auth.openai.com/api/accounts/authorize","token_endpoint":"https://evil.invalid/token","jwks_uri":"https://auth.openai.com/keys"}"#
        let config = try JSONDecoder().decode(SubscriptionDiscovery.self, from: Data(input.utf8))
        XCTAssertThrowsError(try config.validated())
    }
    func testTokenEnvelopeRequiresRotationAndExplicitScopes() throws {
        let valid = #"{"access_token":"synthetic-access","refresh_token":"synthetic-refresh","id_token":"synthetic-id","scope":"openid offline_access chatgpt.tokens.use.direct","token_type":"Bearer","expires_in":3600}"#
        XCTAssertTrue(try SubscriptionTokens.decode(Data(valid.utf8)).scopes.contains("chatgpt.tokens.use.direct"))
        let broken = valid.replacingOccurrences(of: "\"refresh_token\":\"synthetic-refresh\",", with: "")
        XCTAssertThrowsError(try SubscriptionTokens.decode(Data(broken.utf8)))
    }
    func testLoopbackRejectsUnrelatedRequestAndDeliversValidCallback() async throws {
        let listener = SubscriptionLoopback(state: "test-loopback-state")
        let url = try await listener.start()
        defer { listener.cancel() }
        XCTAssertEqual(url.host, "127.0.0.1")
        let invalid = URL(string: url.absoluteString + "?code=synthetic&state=wrong")!
        let (_, rejection) = try await URLSession.shared.data(from: invalid)
        XCTAssertEqual((rejection as? HTTPURLResponse)?.statusCode, 400)
        let valid = URL(string: url.absoluteString + "?code=synthetic&state=test-loopback-state&client_id=oaiapp_test")!
        let (_, accepted) = try await URLSession.shared.data(from: valid)
        XCTAssertEqual((accepted as? HTTPURLResponse)?.statusCode, 200)
        let result = try await listener.result(); XCTAssertEqual(result, valid)
    }
}
