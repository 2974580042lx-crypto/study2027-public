import XCTest
@testable import DeepSeekCore

final class HistoryDictionaryTests: XCTestCase {
    private func entry(_ id: String, _ title: String, aliases: [String] = [], node: String = "h-cn-ancient-02",
                       year: Int? = nil, end: Int? = nil, text: String = "", links: [HistoryEntry.Link] = []) -> HistoryEntry {
        HistoryEntry(id: id, title: title, aliases: aliases, kind: "事件", nodeID: node, year: year, endYear: end, text: text, links: links)
    }

    private var sample: HistoryDictionary {
        HistoryDictionary(entries: [
            entry("a", "郡县制", text: "秦朝推行。"),
            entry("b", "郡国并行", aliases: ["郡国制"], year: -202, text: "郡县制和分封制并存。", links: [.init(text: "郡县制", id: "a")]),
            entry("c", "戊戌变法", aliases: ["百日维新"], node: "h-cn-modern-03", year: 1898),
            entry("d", "《共产党宣言》", node: "h-w-modern-03", year: 1848),
            entry("e", "秦统一六国", year: -221, text: "建立郡县。"),
        ])
    }

    func testSearchRanksTitleBeforeBody() {
        XCTAssertEqual(sample.search("郡县制").map(\.id), ["a", "b"])
        XCTAssertEqual(sample.search("郡县").map(\.id), ["a", "b", "e"])
    }

    func testSearchMatchesAliasesAndIgnoresBookMarks() {
        XCTAssertEqual(sample.search("百日维新").first?.id, "c")
        XCTAssertEqual(sample.search("共产党宣言").first?.id, "d")
        XCTAssertEqual(sample.search(" 郡国 制 ").first?.id, "b")
        XCTAssertTrue(sample.search("  ").isEmpty)
    }

    func testTimelineSortsBCFirstAndFiltersRegion() {
        XCTAssertEqual(sample.timeline(china: true).map(\.id), ["e", "b", "c"])
        XCTAssertEqual(sample.timeline(china: false).map(\.id), ["d"])
    }

    func testYearTextAndMentions() {
        XCTAssertEqual(entry("x", "x", year: -221, end: -206).yearText, "前221—前206年")
        XCTAssertEqual(entry("x", "x", year: 1840).yearText, "1840年")
        XCTAssertNil(entry("x", "x").yearText)
        XCTAssertEqual(sample.mentions(of: "a").map(\.id), ["b"])
    }

    /// 打包进 App 的词典能解码，链接都指向存在的条目，章节都在考纲里
    func testBundledDictionaryIsConsistent() throws {
        let url = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
            .appendingPathComponent("StudyDesk/Resources/history-entries.json")
        let dict = try HistoryDictionary(data: Data(contentsOf: url))
        XCTAssertGreaterThan(dict.entries.count, 300)
        let nodes = Set(SyllabusSeed.nodes().map(\.id))
        for e in dict.entries {
            XCTAssertTrue(nodes.contains(e.nodeID), e.title)
            for link in e.links {
                XCTAssertNotNil(dict.entry(link.id), "\(e.title) → \(link.text)")
                XCTAssertTrue(e.text.contains(link.text), "\(e.title) 正文里没有 \(link.text)")
            }
        }
        XCTAssertEqual(dict.search("戊戌变法").first?.title, "戊戌变法")
    }
}
