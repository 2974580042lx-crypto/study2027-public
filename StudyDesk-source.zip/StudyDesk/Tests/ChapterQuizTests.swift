import XCTest
@testable import DeepSeekCore

final class ChapterQuizTests: XCTestCase {
    func testParseKeepsValidQuestionsAndStripsLetters() throws {
        let text = """
        ```json
        {"questions":[
         {"stem":"汉武帝解决王国问题的措施是","options":["A. 推恩令","B. 刺史制度","C. 盐铁官营","D. 郡国并行"],"answer":"a","explanation":"推恩令分割王国。"},
         {"stem":"缺选项","options":["甲","乙"],"answer":"A"},
         {"stem":"答案越界","options":["甲","乙","丙","丁"],"answer":"E"},
         {"stem":"选项重复","options":["甲","甲","丙","丁"],"answer":"B"}
        ]}
        ```
        """
        let qs = try ChapterQuiz.parse(text, group: "AI 出题 · 中国古代史 · 秦汉", idPrefix: "ai-h-cn-ancient-02")
        XCTAssertEqual(qs.count, 1)
        XCTAssertEqual(qs[0].options, ["推恩令", "刺史制度", "盐铁官营", "郡国并行"])
        XCTAssertEqual(qs[0].answers, [0])
        XCTAssertEqual(qs[0].subject, .history)
        XCTAssertTrue(qs[0].id.hasPrefix("ai-h-cn-ancient-02-"))
        XCTAssertEqual(qs[0].source, ChapterQuiz.source)
    }

    func testParseRejectsGarbage() {
        XCTAssertThrowsError(try ChapterQuiz.parse("好的，我来出题", group: "g", idPrefix: "p"))
        XCTAssertThrowsError(try ChapterQuiz.parse(#"{"questions":[{"stem":"x","options":[],"answer":"A"}]}"#, group: "g", idPrefix: "p"))
    }

    func testStripLetterLeavesNormalOptionsAlone() {
        XCTAssertEqual(ChapterQuiz.stripLetter("C、盐铁官营"), "盐铁官营")
        XCTAssertEqual(ChapterQuiz.stripLetter("Ab"), "Ab")
        XCTAssertEqual(ChapterQuiz.stripLetter("Athens 民主"), "Athens 民主")
    }

    func testUserMessageIncludesReferenceAndPrevious() {
        let text = ChapterQuiz.userMessage(.init(block: "中国古代史", title: "秦汉", reference: ["推恩令：分割王国"],
                                                  previousStems: ["旧题一"], weakPoints: ["郡国并行"]))
        XCTAssertTrue(text.contains("章节：中国古代史 · 秦汉"))
        XCTAssertTrue(text.contains("- 推恩令：分割王国"))
        XCTAssertTrue(text.contains("- 旧题一"))
        XCTAssertTrue(text.contains("- 郡国并行"))
    }
}
