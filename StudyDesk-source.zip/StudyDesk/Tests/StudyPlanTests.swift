import XCTest
@testable import DeepSeekCore

final class StudyPlanTests: XCTestCase {
    private var calendar: Calendar = {
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(identifier: "Asia/Shanghai")!; return c
    }()
    private func day(_ d: Int, _ h: Int = 10) -> Date { calendar.date(from: DateComponents(year: 2026, month: 10, day: d, hour: h))! }

    func testSeedHasUniqueIDsAndAllSubjects() {
        let nodes = SyllabusSeed.nodes()
        XCTAssertEqual(Set(nodes.map(\.id)).count, nodes.count)
        XCTAssertTrue(nodes.contains { $0.subject == .history && $0.block == "中国古代史" })
        XCTAssertTrue(nodes.contains { $0.subject == .politics && $0.block == "马原" })
        XCTAssertTrue(nodes.contains { $0.subject == .english })
    }

    func testMasterySchedulesReview() {
        var node = SyllabusSeed.nodes()[0]
        node.setMastery(2, at: day(4), calendar: calendar)
        XCTAssertEqual(node.nextReview, calendar.startOfDay(for: day(9)))
        node.setMastery(9, at: day(4), calendar: calendar)
        XCTAssertEqual(node.mastery, 4)
        node.setMastery(0, at: day(4), calendar: calendar)
        XCTAssertNil(node.nextReview)
    }

    func testParseToleratesFencesAndClamps() throws {
        let text = """
        好的，下面是汇总：
        ```json
        {"summary":"推进了秦汉。","progress":[{"nodeID":"h-cn-ancient-02","mastery":7},{"nodeID":"x"}],
         "tomorrow":["a","b","c","d"],"memories":{"add":[{"text":"郡国并行容易忘","category":"weakPoints"},{"text":" "}],"remove":["m1"]}}
        ```
        """
        let r = try StudyDigest.parse(text)
        XCTAssertEqual(r.summary, "推进了秦汉。")
        XCTAssertEqual(r.progress, [.init(nodeID: "h-cn-ancient-02", mastery: 4)])
        XCTAssertEqual(r.tomorrow.count, 3)
        XCTAssertEqual(r.addMemories, [.init(text: "郡国并行容易忘", category: .weakPoints)])
        XCTAssertEqual(r.removeMemories, ["m1"])
    }

    func testParseRejectsNonJSON() {
        XCTAssertThrowsError(try StudyDigest.parse("今天学得不错"))
        XCTAssertThrowsError(try StudyDigest.parse(#"{"summary":""}"#))
    }

    func testApplyUpdatesNodesMemoriesAndDigest() throws {
        var state = StudySnapshot()
        state.syllabus = SyllabusSeed.nodes()
        state.memories = [MemoryItem(id: "m1", text: "秦汉不牢", category: .weakPoints, source: "你写的"),
                          MemoryItem(id: "m2", text: "置顶的事", category: .goals, source: "你写的", pinned: true)]
        let result = StudyDigest.Result(summary: "好", progress: [.init(nodeID: "h-cn-ancient-02", mastery: 3), .init(nodeID: "nope", mastery: 2)],
                                        weakPoints: ["郡国并行"], tomorrow: ["默写"], addMemories: [.init(text: "新记忆", category: .habits)],
                                        removeMemories: ["m1", "m2"])
        let changed = StudyDigest.apply(result, to: &state, day: day(3), eventCount: 5, automatic: true, now: day(4), calendar: calendar)
        XCTAssertEqual(changed, 1)
        XCTAssertEqual(state.syllabus?.first { $0.id == "h-cn-ancient-02" }?.mastery, 3)
        XCTAssertEqual(state.memories?.map(\.id).contains("m1"), false)
        XCTAssertEqual(state.memories?.map(\.id).contains("m2"), true, "置顶记忆不能被 AI 删掉")
        XCTAssertEqual(state.memories?.last?.source, "10 月 3 日的汇总")
        XCTAssertEqual(state.digests?.first?.id, "2026-10-03")
        XCTAssertEqual(state.digests?.first?.seen, false)
    }

    func testPendingDaysSkipsTodayAndDigested() {
        let events = [day(1), day(2), day(4)].map { LearningEvent(subject: .history, kind: .note, title: "x", detail: "x", start: $0, end: $0) }
        let digests = [DailyDigest(id: "2026-10-01", day: day(1), summary: "", tomorrow: [], weakPoints: [], changes: [:], createdAt: day(2), eventCount: 1)]
        let days = StudyDigest.pendingDays(events: events, digests: digests, now: day(4), calendar: calendar)
        XCTAssertEqual(days, [calendar.startOfDay(for: day(2))])
    }

    func testUserMessageGroupsRepeatedEvents() {
        let e = (0..<5).map { i in LearningEvent(subject: .english, kind: .reviewWord, title: "w\(i)", detail: "", start: day(3, 9), end: day(3, 9)) }
            + [LearningEvent(subject: .history, kind: .note, title: "秦汉", detail: "秦汉第二节，郡国并行没写出来", start: day(3, 20), end: day(3, 20), manual: true)]
        let text = StudyDigest.userMessage(.init(day: day(3), events: e, nodes: SyllabusSeed.nodes(), memories: [], examDate: nil), calendar: calendar)
        XCTAssertTrue(text.contains("英语一·复习单词：5 个"))
        XCTAssertTrue(text.contains("郡国并行没写出来"))
        XCTAssertTrue(text.contains("h-cn-ancient-02｜313 历史学｜中国古代史｜秦汉｜0"))
    }

    func testOldSnapshotStillDecodes() throws {
        // 去掉本版新增的字段，模拟旧版本保存的记录
        var json = try XCTUnwrap(JSONSerialization.jsonObject(with: StudySnapshot().encoded()) as? [String: Any])
        for key in ["syllabus", "digests", "memories", "autoDigest"] { json.removeValue(forKey: key) }
        let old = try JSONSerialization.data(withJSONObject: json)
        let decoded = try StudySnapshot.decode(old)
        XCTAssertNil(decoded.syllabus)
        XCTAssertNil(decoded.memories)
    }

    func testMemoryMigrationAndContextLimit() {
        XCTAssertTrue(StudyMemory.migrate(profile: "目标：考研复习。可在学习设置中编辑个人学习档案。").isEmpty)
        let items = StudyMemory.migrate(profile: "初试 12 月 19 日\n\n用长孙博大纲解析")
        XCTAssertEqual(items.map(\.text), ["初试 12 月 19 日", "用长孙博大纲解析"])
        let many = (0..<100).map { MemoryItem(text: String(repeating: "记", count: 50) + "\($0)", category: .other, source: "你写的") }
        XCTAssertLessThanOrEqual(StudyMemory.context(items: many, limit: 300).count, 330)
    }
}
