import XCTest
@testable import DeepSeekCore

final class PracticeProgressTests: XCTestCase {
    private func attempt(_ id: String, _ correct: Bool, _ t: TimeInterval) -> QuestionAttempt {
        QuestionAttempt(questionID: id, selected: [0], correct: correct, date: Date(timeIntervalSince1970: t))
    }

    func testResumesAtFirstUnanswered() {
        let p = PracticeProgress(questionIDs: ["a", "b", "c", "d"], attempts: [attempt("a", true, 1), attempt("c", false, 2)])
        XCTAssertEqual(p.marks, [.correct, .unanswered, .wrong, .unanswered])
        XCTAssertEqual(p.resumeIndex, 1)
        XCTAssertEqual(p.summary, "已做 2 / 4 · 对 1")
        XCTAssertEqual(p.wrongIndices, [2])
    }

    func testLatestAttemptWinsRegardlessOfOrder() {
        let p = PracticeProgress(questionIDs: ["a"], attempts: [attempt("a", true, 5), attempt("a", false, 1)])
        XCTAssertEqual(p.marks, [.correct])
        XCTAssertNil(p.resumeIndex)
    }

    func testUntouchedGroupShowsCount() {
        XCTAssertEqual(PracticeProgress(questionIDs: ["a", "b"], attempts: []).summary, "2 题")
    }
}
