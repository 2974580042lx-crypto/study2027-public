import XCTest
@testable import DeepSeekCore

final class EssayAndReportTests: XCTestCase {
    private var calendar: Calendar = {
        var c = Calendar(identifier: .gregorian); c.timeZone = TimeZone(identifier: "Asia/Shanghai")!; return c
    }()
    private func day(_ d: Int, _ h: Int = 10) -> Date { calendar.date(from: DateComponents(year: 2026, month: 10, day: d, hour: h))! }

    // MARK: 大题

    func testParseTaskNeedsPrompt() throws {
        let task = try EssayPractice.parseTask(#"好的 {"title":"中央集权","prompt":"试论秦至清中央集权制度的演变及其影响。"}"#,
                                               kind: .historyEssay, scope: "古代中央集权", nodeID: nil, topicID: "t-centralization")
        XCTAssertEqual(task.title, "中央集权")
        XCTAssertEqual(task.topicID, "t-centralization")
        XCTAssertThrowsError(try EssayPractice.parseTask(#"{"title":"x","prompt":"太短"}"#, kind: .historyEssay, scope: "", nodeID: nil, topicID: nil))
    }

    func testParseGradeClampsAndFilters() throws {
        let text = """
        {"score":33.3,"points":[{"point":"郡县制取代分封制（6分）","hit":"full","comment":"到位"},{"point":"","hit":"full"},{"point":"军机处（4分）","hit":"maybe"}],
         "summary":"框架清楚。","improvements":["补充明清","  ","a","b","c"],"corrections":[{"original":"x","better":"y"}],"weakPoints":["军机处的作用说不清"]}
        """
        let a = try EssayPractice.parseGrade(text, kind: .historyEssay, answer: "答案")
        XCTAssertEqual(a.score, 33.5, "论述题满分 40，按半分取整")
        let early = try EssayPractice.parseGrade(text, kind: .historyEssay, fullScore: 30, answer: "答案")
        XCTAssertEqual(early.score, 30, "早年 30 分的简答题按自己的满分封顶")
        XCTAssertEqual(a.points.count, 2)
        XCTAssertEqual(a.points[1].hit, .miss, "不认识的判定按没答处理")
        XCTAssertEqual(a.improvements, ["补充明清", "a", "b", "c"])
        XCTAssertTrue(a.corrections.isEmpty, "历史题不保留改句")
        let e = try EssayPractice.parseGrade(#"{"score":12.26,"corrections":[{"original":"I very like","better":"I really like","reason":"语序"},{"original":"same","better":"same"}]}"#,
                                             kind: .englishLarge, answer: "x")
        XCTAssertEqual(e.score, 12.5)
        XCTAssertEqual(e.corrections.count, 1)
        XCTAssertThrowsError(try EssayPractice.parseGrade("不错", kind: .englishSmall, answer: "x"))
    }

    func testWeakPointsMergeWithoutDuplicates() {
        var memories = [MemoryItem(text: "军机处的作用 说不清", category: .weakPoints, source: "你写的")]
        let added = EssayPractice.mergeWeakPoints(["军机处的作用说不清", "明朝内阁与宰相的区别"], into: &memories, scope: "论述题")
        XCTAssertEqual(added, 1)
        XCTAssertEqual(memories.last?.source, "大题批改 · 论述题")
    }

    func testTopicsReferenceRealNodesAndEntries() throws {
        let nodes = Set(SyllabusSeed.nodes().map(\.id))
        let url = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
            .appendingPathComponent("StudyDesk/Resources/history-entries.json")
        let dict = try HistoryDictionary(data: Data(contentsOf: url))
        XCTAssertEqual(Set(HistoryTopics.all.map(\.id)).count, HistoryTopics.all.count)
        for t in HistoryTopics.all {
            XCTAssertTrue(t.nodeIDs.allSatisfy(nodes.contains), t.title)
            XCTAssertGreaterThanOrEqual(t.entries(in: dict).count, 3, "\(t.title) 关联的条目太少")
        }
    }

    // MARK: 今日计划

    func testPlanSeedsFromDigestAndCarriesUnfinished() {
        let digest = DailyDigest(id: "2026-10-04", day: day(4), summary: "", tomorrow: ["默写秦汉框架", "政治错题"], weakPoints: [],
                                 changes: [:], createdAt: day(5, 1), eventCount: 3)
        let old = DailyPlan(id: "2026-10-04", items: [PlanItem(text: "背 50 个词", done: false), PlanItem(text: "已完成", done: true),
                                                      PlanItem(text: "政治错题")])
        let plan = DailyPlanner.plan(for: day(5), plans: [old], digests: [digest], calendar: calendar)
        XCTAssertEqual(plan.id, "2026-10-05")
        XCTAssertEqual(plan.items.map(\.text), ["默写秦汉框架", "政治错题", "背 50 个词"])
        XCTAssertEqual(plan.items.last?.origin, .carried)
        var plans = [old]
        DailyPlanner.store(plan, in: &plans)
        XCTAssertEqual(DailyPlanner.plan(for: day(5), plans: plans, digests: [], calendar: calendar), plan)
    }

    // MARK: 周报

    func testWeeklyReportCountsWeekOnly() {
        let monday = WeeklyReport.weekStart(for: day(7), calendar: calendar)   // 2026-10-07 是周三
        XCTAssertEqual(StudyDigest.id(for: monday, calendar: calendar), "2026-10-05")
        let q1 = StudyQuestion(id: "q1", subject: .history, group: "秦汉", stem: "推恩令", options: ["a", "b"], answers: [0], explanation: "", source: "s")
        let q2 = StudyQuestion(id: "q2", subject: .politics, group: "马原", stem: "矛盾", options: ["a", "b"], answers: [1], explanation: "", source: "s")
        let attempts = [QuestionAttempt(questionID: "q1", selected: [1], correct: false, date: day(6)),
                        QuestionAttempt(questionID: "q1", selected: [0], correct: true, date: day(7)),
                        QuestionAttempt(questionID: "q2", selected: [0], correct: false, date: day(8)),
                        QuestionAttempt(questionID: "q2", selected: [1], correct: true, date: day(1))]
        let events = [LearningEvent(subject: .history, kind: .focus, title: "秦汉", detail: "", start: day(6, 9), end: day(6, 11)),
                      LearningEvent(subject: .history, kind: .focus, title: "旧", detail: "", start: day(1, 9), end: day(1, 10))]
        var essay = EssayTask(kind: .historyEssay, scope: "s", title: "t", prompt: "p")
        essay.attempts = [EssayAttempt(text: "x", date: day(9), score: 20, points: [], summary: "", improvements: [], corrections: [], weakPoints: ["内阁"])]
        let r = WeeklyReport.compute(weekStart: monday, events: events, attempts: attempts, questions: [q1, q2], essays: [essay], digests: [], calendar: calendar)
        XCTAssertEqual(r.seconds, 7200)
        XCTAssertEqual(r.previousSeconds, 3600)
        XCTAssertEqual(r.studyDays, 1)
        XCTAssertEqual(r.answered, 3)
        XCTAssertEqual(r.correct, 1)
        XCTAssertEqual(r.previousAnswered, 1)
        XCTAssertEqual(r.weakGroups.map(\.group).sorted(), ["秦汉", "马原"])
        XCTAssertEqual(r.wrongSamples.count, 2)
        XCTAssertEqual(r.essayRatio, 0.5)
        XCTAssertEqual(r.essayWeakPoints, ["内阁"])
        let text = WeeklyReview.userMessage(r, examDays: 70, calendar: calendar)
        XCTAssertTrue(text.contains("正确率 33%"))
        XCTAssertTrue(text.contains("距初试 70 天"))
    }

    func testImportedEssaysBecomeRealTasks() throws {
        let json = #"{"essays":[{"id":"zt313-2010-e1","kind":"historyEssay","title":"西汉诸侯王国问题","prompt":"论述西汉时期的诸侯王国问题。","source":"2010 年 313","year":2010,"score":30}]}"#
        let pack = try JSONDecoder().decode(ImportedStudyPack.self, from: Data(json.utf8))
        let task = try XCTUnwrap(pack.essays?.first).task
        XCTAssertTrue(task.isReal)
        XCTAssertEqual(task.year, 2010)
        XCTAssertEqual(task.fullScore, 30)
        XCTAssertEqual(EssayTask(kind: .historyEssay, scope: "", title: "", prompt: "").fullScore, 40)
    }

    func testPickExamplesPrefersOverlapAndSkipsIncomplete() {
        func real(_ id: String, _ prompt: String, _ year: Int, note: String? = nil) -> EssayTask {
            EssayTask(id: id, kind: .historyEssay, scope: "", title: id, prompt: prompt, real: true, year: year, note: note)
        }
        let tasks = [real("a", "论述西汉时期的诸侯王国问题。", 2010), real("b", "论述唐玄宗时期军事制度的主要变化。", 2022),
                     real("c", "论述西汉到唐代的赋税制度。", 2012), real("d", "论述西汉郡国并行。", 2015, note: "材料缺"),
                     EssayTask(kind: .historyEssay, scope: "", title: "AI", prompt: "西汉推恩令")]
        let picked = EssayPractice.pickExamples(from: tasks, kind: .historyEssay, scope: "中国古代史 · 秦汉", terms: ["西汉", "诸侯王国"])
        XCTAssertEqual(picked.map(\.id), ["a", "c", "b"])
        let text = EssayPractice.generateUserMessage(kind: .historyEssay, scope: "秦汉", reference: [], weakPoints: [], previousTitles: [], examples: Array(picked.prefix(1)))
        XCTAssertTrue(text.contains("真题样例"))
        XCTAssertTrue(text.contains("2010 年：论述西汉时期的诸侯王国问题。"))
    }

    func testWeeklyDiagnosisParse() throws {
        let d = try WeeklyReview.parse(#"{"diagnosis":"选择题稳定。","errorTypes":[{"type":"概念混淆","detail":"内阁与宰相"},{"type":"","detail":""}],"focus":["a","b","c","d"]}"#, id: "W2026-10-05")
        XCTAssertEqual(d.errorTypes.count, 1)
        XCTAssertEqual(d.focus.count, 3)
        XCTAssertThrowsError(try WeeklyReview.parse("{}", id: "x"))
    }
}
